package main

import (
	"gin_base/apps/matching"
	"gin_base/apps/users"
	"gin_base/core"
	"log"

	"github.com/gin-gonic/gin"
)

func main() {
	// 初始化配置
	config, err := core.LoadConfig()
	if err != nil {
		log.Fatalf("Failed to load config: %v", err)
	}

	// 设置配置到路由模块
	core.SetConfig(config)

	// 初始化日志
	core.InitLogger()

	// 初始化数据库
	core.InitDB(config)

	// 自动迁移数据库表
	core.AutoMigrate(&users.User{}, &matching.Volunteer{}, &matching.ServiceTask{}, &matching.MatchRecord{})
	if err := matching.SeedDemoData(); err != nil {
		log.Fatalf("Failed to seed demo data: %v", err)
	}

	// 初始化路由
	router := core.SetupRouter()

	// 将 config 注入到上下文中
	router.Use(func(c *gin.Context) {
		c.Set("config", config)
		c.Next()
	})

	// 注册用户路由
	users.RegisterRoutes(router)
	matching.RegisterRoutes(router)

	// 启动服务器
	port := config.Server.Port
	log.Printf("Server starting on port %s", port)
	if err := router.Run(":" + port); err != nil {
		log.Fatalf("Failed to start server: %v", err)
	}
}
