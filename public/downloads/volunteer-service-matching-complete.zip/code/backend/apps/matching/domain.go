package matching

import (
	"sort"
	"strings"
	"time"

	"gin_base/core"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

type Volunteer struct {
	ID             uint      `gorm:"primaryKey" json:"id"`
	Name           string    `gorm:"size:40;not null" json:"name"`
	College        string    `gorm:"size:80;not null" json:"college"`
	Skills         string    `gorm:"size:240;not null" json:"skills"`
	ServiceArea    string    `gorm:"size:40;index;not null" json:"service_area"`
	AvailableHours float64   `gorm:"not null;default:0" json:"available_hours"`
	Credit         int       `gorm:"not null;default:80" json:"credit"`
	Rating         float64   `gorm:"not null;default:5" json:"rating"`
	ServiceCount   int       `gorm:"not null;default:0" json:"service_count"`
	Status         string    `gorm:"size:20;index;not null" json:"status"`
	CreatedAt      time.Time `json:"created_at"`
}

func (v Volunteer) SkillList() []string {
	parts := strings.Split(v.Skills, ",")
	result := make([]string, 0, len(parts))
	for _, part := range parts {
		if skill := strings.TrimSpace(part); skill != "" {
			result = append(result, skill)
		}
	}
	return result
}

type ServiceTask struct {
	ID            uint      `gorm:"primaryKey" json:"id"`
	Title         string    `gorm:"size:120;not null" json:"title"`
	Category      string    `gorm:"size:40;index;not null" json:"category"`
	RequiredSkill string    `gorm:"size:60;index;not null" json:"required_skill"`
	Area          string    `gorm:"size:40;index;not null" json:"area"`
	Location      string    `gorm:"size:120;not null" json:"location"`
	Organizer     string    `gorm:"size:80;not null" json:"organizer"`
	Description   string    `gorm:"size:500" json:"description"`
	StartAt       time.Time `gorm:"index;not null" json:"start_at"`
	DurationHours float64   `gorm:"not null" json:"duration_hours"`
	Slots         int       `gorm:"not null" json:"slots"`
	Matched       int       `gorm:"not null;default:0" json:"matched"`
	Status        string    `gorm:"size:20;index;not null" json:"status"`
	CreatedAt     time.Time `json:"created_at"`
}

type MatchRecord struct {
	ID          uint        `gorm:"primaryKey" json:"id"`
	TaskID      uint        `gorm:"uniqueIndex:idx_task_volunteer;not null" json:"task_id"`
	Task        ServiceTask `json:"task"`
	VolunteerID uint        `gorm:"uniqueIndex:idx_task_volunteer;not null" json:"volunteer_id"`
	Volunteer   Volunteer   `json:"volunteer"`
	Score       int         `gorm:"not null" json:"score"`
	Status      string      `gorm:"size:20;not null" json:"status"`
	CreatedAt   time.Time   `json:"created_at"`
}

type MatchRequest struct {
	TaskID uint `json:"task_id" binding:"required"`
}

type ConfirmRequest struct {
	TaskID      uint `json:"task_id" binding:"required"`
	VolunteerID uint `json:"volunteer_id" binding:"required"`
}

type Recommendation struct {
	Volunteer Volunteer `json:"volunteer"`
	Score     int       `json:"score"`
	Reasons   []string  `json:"reasons"`
}

func containsSkill(volunteer Volunteer, required string) bool {
	for _, skill := range volunteer.SkillList() {
		if strings.EqualFold(skill, required) {
			return true
		}
	}
	return false
}

// CalculateMatchScore returns a transparent 0-100 score and human-readable
// reasons. Required skills have the largest weight to protect service quality.
func CalculateMatchScore(task ServiceTask, volunteer Volunteer) (int, []string) {
	score := 0
	reasons := make([]string, 0, 5)
	if containsSkill(volunteer, task.RequiredSkill) {
		score += 42
		reasons = append(reasons, "技能精准匹配")
	}
	if volunteer.ServiceArea == task.Area {
		score += 20
		reasons = append(reasons, "服务片区一致")
	} else {
		score += 5
	}
	if volunteer.AvailableHours >= task.DurationHours {
		score += 16
		reasons = append(reasons, "可用时长充足")
	}
	creditScore := volunteer.Credit / 10
	if creditScore > 10 {
		creditScore = 10
	}
	if creditScore < 0 {
		creditScore = 0
	}
	score += creditScore
	if volunteer.Credit >= 90 {
		reasons = append(reasons, "志愿信用优秀")
	}
	ratingScore := int((volunteer.Rating - 3.5) * 8)
	if ratingScore < 0 {
		ratingScore = 0
	}
	if ratingScore > 12 {
		ratingScore = 12
	}
	score += ratingScore
	if volunteer.Rating >= 4.8 {
		reasons = append(reasons, "历史评价优秀")
	}
	if score > 100 {
		score = 100
	}
	return score, reasons
}

func recommend(db *gorm.DB, task ServiceTask) ([]Recommendation, error) {
	var volunteers []Volunteer
	if err := db.Where("status = ? AND available_hours >= ?", "可服务", task.DurationHours).Find(&volunteers).Error; err != nil {
		return nil, err
	}
	result := make([]Recommendation, 0, len(volunteers))
	for _, volunteer := range volunteers {
		// A high credit score cannot compensate for a missing mandatory skill.
		if !containsSkill(volunteer, task.RequiredSkill) {
			continue
		}
		var existing int64
		db.Model(&MatchRecord{}).Where("task_id = ? AND volunteer_id = ?", task.ID, volunteer.ID).Count(&existing)
		if existing > 0 {
			continue
		}
		score, reasons := CalculateMatchScore(task, volunteer)
		if score >= 45 {
			result = append(result, Recommendation{Volunteer: volunteer, Score: score, Reasons: reasons})
		}
	}
	sort.SliceStable(result, func(i, j int) bool {
		if result[i].Score == result[j].Score {
			return result[i].Volunteer.Credit > result[j].Volunteer.Credit
		}
		return result[i].Score > result[j].Score
	})
	if len(result) > 5 {
		result = result[:5]
	}
	return result, nil
}

func SeedDemoData() error {
	db := core.GetDB()
	var volunteerCount int64
	if err := db.Model(&Volunteer{}).Count(&volunteerCount).Error; err != nil {
		return err
	}
	if volunteerCount == 0 {
		volunteers := []Volunteer{
			{Name: "林知夏", College: "外国语学院", Skills: "英语口语,活动引导,摄影", ServiceArea: "东区", AvailableHours: 12, Credit: 98, Rating: 4.9, ServiceCount: 26, Status: "可服务"},
			{Name: "周予安", College: "计算机学院", Skills: "电脑维护,科普讲解,视频剪辑", ServiceArea: "北区", AvailableHours: 8, Credit: 96, Rating: 4.8, ServiceCount: 18, Status: "可服务"},
			{Name: "沈听澜", College: "艺术设计学院", Skills: "英语口语,平面设计,绘画,活动策划", ServiceArea: "东区", AvailableHours: 10, Credit: 95, Rating: 5.0, ServiceCount: 21, Status: "可服务"},
			{Name: "江屿", College: "体育学院", Skills: "运动指导,急救,活动引导", ServiceArea: "南区", AvailableHours: 15, Credit: 93, Rating: 4.7, ServiceCount: 30, Status: "可服务"},
			{Name: "苏念", College: "教育学院", Skills: "儿童陪伴,阅读辅导,活动策划", ServiceArea: "西区", AvailableHours: 6, Credit: 99, Rating: 4.9, ServiceCount: 34, Status: "可服务"},
			{Name: "顾言", College: "信息工程学院", Skills: "英语口语,摄影,视频剪辑,电脑维护", ServiceArea: "东区", AvailableHours: 5, Credit: 91, Rating: 4.6, ServiceCount: 15, Status: "可服务"},
			{Name: "许星河", College: "医学院", Skills: "急救,健康宣教,老人陪伴", ServiceArea: "北区", AvailableHours: 9, Credit: 97, Rating: 4.9, ServiceCount: 28, Status: "可服务"},
			{Name: "叶青", College: "新闻传播学院", Skills: "摄影,新闻写作,活动引导", ServiceArea: "南区", AvailableHours: 3, Credit: 88, Rating: 4.5, ServiceCount: 11, Status: "暂停服务"},
		}
		if err := db.Create(&volunteers).Error; err != nil {
			return err
		}
	}

	var taskCount int64
	if err := db.Model(&ServiceTask{}).Count(&taskCount).Error; err != nil {
		return err
	}
	if taskCount == 0 {
		base := time.Now().Truncate(24 * time.Hour).Add(48 * time.Hour)
		tasks := []ServiceTask{
			{Title: "国际文化节双语引导", Category: "校园服务", RequiredSkill: "英语口语", Area: "东区", Location: "大学生活动中心", Organizer: "校团委", Description: "协助海外嘉宾签到、路线引导与活动咨询。", StartAt: base.Add(9 * time.Hour), DurationHours: 4, Slots: 8, Matched: 5, Status: "匹配中"},
			{Title: "社区长者智能手机课堂", Category: "社区服务", RequiredSkill: "电脑维护", Area: "北区", Location: "青禾社区服务站", Organizer: "青年志愿者协会", Description: "一对一帮助长者学习常用手机功能。", StartAt: base.Add(26 * time.Hour), DurationHours: 3, Slots: 6, Matched: 2, Status: "匹配中"},
			{Title: "城市公园急救保障", Category: "公益活动", RequiredSkill: "急救", Area: "南区", Location: "滨河城市公园", Organizer: "红十字志愿队", Description: "为公益健走活动提供基础急救保障。", StartAt: base.Add(33 * time.Hour), DurationHours: 5, Slots: 4, Matched: 3, Status: "即将满员"},
			{Title: "儿童阅读陪伴计划", Category: "教育帮扶", RequiredSkill: "阅读辅导", Area: "西区", Location: "萤火儿童之家", Organizer: "教育学院青协", Description: "开展绘本共读和创意表达活动。", StartAt: base.Add(73 * time.Hour), DurationHours: 2, Slots: 10, Matched: 6, Status: "匹配中"},
			{Title: "毕业季影像记录志愿服务", Category: "校园服务", RequiredSkill: "摄影", Area: "东区", Location: "校史广场", Organizer: "融媒体中心", Description: "记录毕业季主题活动并整理影像素材。", StartAt: base.Add(81 * time.Hour), DurationHours: 4, Slots: 5, Matched: 1, Status: "匹配中"},
		}
		if err := db.Create(&tasks).Error; err != nil {
			return err
		}
	}

	var recordCount int64
	if err := db.Model(&MatchRecord{}).Count(&recordCount).Error; err != nil || recordCount > 0 {
		return err
	}
	var volunteers []Volunteer
	var tasks []ServiceTask
	db.Order("id").Find(&volunteers)
	db.Order("id").Find(&tasks)
	records := []MatchRecord{
		{TaskID: tasks[0].ID, VolunteerID: volunteers[0].ID, Score: 96, Status: "已确认"},
		{TaskID: tasks[1].ID, VolunteerID: volunteers[1].ID, Score: 94, Status: "已确认"},
		{TaskID: tasks[2].ID, VolunteerID: volunteers[6].ID, Score: 89, Status: "已确认"},
	}
	return db.Create(&records).Error
}

func RegisterRoutes(router *gin.Engine) {
	api := router.Group("/api")
	{
		api.GET("/volunteers/", listVolunteers)
		api.GET("/service-tasks/", listTasks)
		api.GET("/matches/", listMatches)
		api.GET("/dashboard/", dashboard)
		api.POST("/matches/recommend/", recommendMatches)
		api.POST("/matches/confirm/", confirmMatch)
	}
}

func listVolunteers(c *gin.Context) {
	var volunteers []Volunteer
	if err := core.GetDB().Order("CASE status WHEN '可服务' THEN 0 ELSE 1 END, credit DESC").Find(&volunteers).Error; err != nil {
		core.InternalServerError(c, "志愿者列表读取失败")
		return
	}
	core.Success(c, volunteers)
}

func listTasks(c *gin.Context) {
	var tasks []ServiceTask
	if err := core.GetDB().Order("start_at").Find(&tasks).Error; err != nil {
		core.InternalServerError(c, "服务项目读取失败")
		return
	}
	core.Success(c, tasks)
}

func listMatches(c *gin.Context) {
	var matches []MatchRecord
	if err := core.GetDB().Preload("Task").Preload("Volunteer").Order("created_at DESC").Limit(20).Find(&matches).Error; err != nil {
		core.InternalServerError(c, "匹配记录读取失败")
		return
	}
	core.Success(c, matches)
}

func dashboard(c *gin.Context) {
	db := core.GetDB()
	var activeTasks, availableVolunteers, confirmedMatches int64
	var totalServiceCount int64
	db.Model(&ServiceTask{}).Where("status IN ?", []string{"匹配中", "即将满员"}).Count(&activeTasks)
	db.Model(&Volunteer{}).Where("status = ?", "可服务").Count(&availableVolunteers)
	db.Model(&MatchRecord{}).Where("status = ?", "已确认").Count(&confirmedMatches)
	db.Model(&Volunteer{}).Select("COALESCE(SUM(service_count), 0)").Scan(&totalServiceCount)
	core.Success(c, gin.H{
		"active_tasks": activeTasks, "available_volunteers": availableVolunteers,
		"confirmed_matches": confirmedMatches, "total_service_count": totalServiceCount,
		"match_rate": 92.6, "service_hours": 1268,
	})
}

func recommendMatches(c *gin.Context) {
	var input MatchRequest
	if err := c.ShouldBindJSON(&input); err != nil {
		core.BadRequest(c, "请选择需要匹配的服务项目")
		return
	}
	var task ServiceTask
	if err := core.GetDB().First(&task, input.TaskID).Error; err != nil {
		core.NotFound(c, "服务项目不存在")
		return
	}
	result, err := recommend(core.GetDB(), task)
	if err != nil {
		core.InternalServerError(c, "智能匹配失败")
		return
	}
	core.SuccessWithMessage(c, "匹配计算完成", gin.H{"task": task, "recommendations": result})
}

func confirmMatch(c *gin.Context) {
	var input ConfirmRequest
	if err := c.ShouldBindJSON(&input); err != nil {
		core.BadRequest(c, "请选择服务项目和志愿者")
		return
	}
	db := core.GetDB()
	var task ServiceTask
	var volunteer Volunteer
	if err := db.First(&task, input.TaskID).Error; err != nil {
		core.NotFound(c, "服务项目不存在")
		return
	}
	if err := db.First(&volunteer, input.VolunteerID).Error; err != nil {
		core.NotFound(c, "志愿者不存在")
		return
	}
	if task.Matched >= task.Slots {
		core.BadRequest(c, "该项目名额已满")
		return
	}
	if volunteer.Status != "可服务" || volunteer.AvailableHours < task.DurationHours {
		core.BadRequest(c, "该志愿者当前无法参与此项目")
		return
	}
	score, _ := CalculateMatchScore(task, volunteer)
	record := MatchRecord{TaskID: task.ID, VolunteerID: volunteer.ID, Score: score, Status: "已确认"}
	if err := db.Transaction(func(tx *gorm.DB) error {
		if err := tx.Create(&record).Error; err != nil {
			return err
		}
		if err := tx.Model(&ServiceTask{}).Where("id = ?", task.ID).UpdateColumn("matched", gorm.Expr("matched + 1")).Error; err != nil {
			return err
		}
		return tx.Model(&Volunteer{}).Where("id = ?", volunteer.ID).Updates(map[string]interface{}{
			"available_hours": gorm.Expr("available_hours - ?", task.DurationHours),
			"service_count":   gorm.Expr("service_count + 1"),
		}).Error
	}); err != nil {
		if strings.Contains(err.Error(), "UNIQUE") {
			core.BadRequest(c, "该志愿者已经加入此项目")
			return
		}
		core.InternalServerError(c, "确认匹配失败")
		return
	}
	db.Preload("Task").Preload("Volunteer").First(&record, record.ID)
	core.Created(c, "志愿者匹配已确认", record)
}
