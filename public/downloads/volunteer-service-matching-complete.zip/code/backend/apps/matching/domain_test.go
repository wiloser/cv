package matching

import "testing"

func TestSkillListNormalizesValues(t *testing.T) {
	volunteer := Volunteer{Skills: "摄影, 视频剪辑 ,活动引导"}
	items := volunteer.SkillList()
	if len(items) != 3 || items[1] != "视频剪辑" {
		t.Fatalf("unexpected skill list: %v", items)
	}
}

func TestCalculateMatchScorePrefersRequiredSkill(t *testing.T) {
	task := ServiceTask{RequiredSkill: "急救", Area: "南区", DurationHours: 4}
	matched := Volunteer{Skills: "急救,健康宣教", ServiceArea: "南区", AvailableHours: 8, Credit: 95, Rating: 4.9}
	unmatched := Volunteer{Skills: "摄影", ServiceArea: "南区", AvailableHours: 8, Credit: 100, Rating: 5.0}
	matchedScore, reasons := CalculateMatchScore(task, matched)
	unmatchedScore, _ := CalculateMatchScore(task, unmatched)
	if matchedScore <= unmatchedScore {
		t.Fatalf("skill-matched score %d should exceed unmatched score %d", matchedScore, unmatchedScore)
	}
	if len(reasons) < 3 {
		t.Fatalf("expected explainable reasons, got %v", reasons)
	}
}

func TestCalculateMatchScoreRequiresEnoughHoursForBonus(t *testing.T) {
	task := ServiceTask{RequiredSkill: "摄影", Area: "东区", DurationHours: 5}
	enough := Volunteer{Skills: "摄影", ServiceArea: "东区", AvailableHours: 6, Credit: 90, Rating: 4.8}
	short := enough
	short.AvailableHours = 2
	enoughScore, _ := CalculateMatchScore(task, enough)
	shortScore, _ := CalculateMatchScore(task, short)
	if enoughScore-shortScore != 16 {
		t.Fatalf("availability bonus should be 16, got %d", enoughScore-shortScore)
	}
}

func TestContainsSkillIsMandatoryAndExact(t *testing.T) {
	volunteer := Volunteer{Skills: "英语口语,活动引导"}
	if !containsSkill(volunteer, "英语口语") {
		t.Fatal("required skill should be recognized")
	}
	if containsSkill(volunteer, "英语") {
		t.Fatal("partial skill names must not satisfy a mandatory requirement")
	}
}
