import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { useUserStore } from '../stores/userStore'

// 公共页面
import Login from '../views/auth/Login'
import Register from '../views/auth/Register'
import Home from '../views/Home'

// 用户页面
import Profile from '../views/user/Profile'
import ChangePassword from '../views/user/ChangePassword'

// 管理页面
import UserList from '../views/admin/UserList'

// 404
import NotFound from '../views/NotFound'

// 受保护的路由
function ProtectedRoute({ children, adminOnly = false }) {
  const isAuthenticated = useUserStore((state) => state.isAuthenticated)
  const isAdmin = useUserStore((state) => state.user?.role === 'admin')

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />
  }

  if (adminOnly && !isAdmin) {
    return <Navigate to="/" replace />
  }

  return children
}

export default function AppRouter() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />

        <Route
          path="/profile"
          element={
            <ProtectedRoute>
              <Profile />
            </ProtectedRoute>
          }
        />
        <Route
          path="/change-password"
          element={
            <ProtectedRoute>
              <ChangePassword />
            </ProtectedRoute>
          }
        />
        <Route
          path="/admin/users"
          element={
            <ProtectedRoute adminOnly>
              <UserList />
            </ProtectedRoute>
          }
        />

        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  )
}
