import { useEffect, useState } from 'react'
import { Link, useLocation } from 'react-router-dom'

const API = import.meta.env.VITE_API_BASE_URL || ''
const call = async (path, options) => {
  const response = await fetch(`${API}${path}`, { headers: { 'Content-Type': 'application/json' }, ...options })
  if (!response.headers.get('content-type')?.includes('application/json')) {
    throw new Error(`API 代理返回了非 JSON 响应（HTTP ${response.status}），请检查 ${API || '当前站点'}/api/ 代理`)
  }
  const payload = await response.json()
  if (!response.ok) throw new Error(payload.msg || '请求失败')
  return payload.data
}

const formatDate = (value) => new Intl.DateTimeFormat('zh-CN', { month: 'short', day: 'numeric', weekday: 'short' }).format(new Date(value))
const formatHour = (value) => new Intl.DateTimeFormat('zh-CN', { hour: '2-digit', minute: '2-digit', hour12: false }).format(new Date(value))
const categoryStyle = (category) => ({ 校园服务: 'mint', 社区服务: 'blue', 公益活动: 'orange', 教育帮扶: 'purple' }[category] || 'mint')

function App() {
  const location = useLocation()
  const [tasks, setTasks] = useState([])
  const [volunteers, setVolunteers] = useState([])
  const [matches, setMatches] = useState([])
  const [dashboard, setDashboard] = useState({})
  const [selectedTask, setSelectedTask] = useState(null)
  const [recommendations, setRecommendations] = useState([])
  const [matching, setMatching] = useState(false)
  const [message, setMessage] = useState('')

  const load = async () => {
    try {
      const [taskData, volunteerData, matchData, dashboardData] = await Promise.all([
        call('/api/service-tasks/'), call('/api/volunteers/'), call('/api/matches/'), call('/api/dashboard/'),
      ])
      setTasks(taskData)
      setVolunteers(volunteerData)
      setMatches(matchData)
      setDashboard(dashboardData)
      setMessage('')
    } catch (error) {
      setMessage(`${error.message}，请检查 API 代理与 Go 服务状态`)
    }
  }

  useEffect(() => {
    const timer = window.setTimeout(load, 0)
    return () => window.clearTimeout(timer)
  }, [])

  useEffect(() => {
    const section = location.pathname.split('/').filter(Boolean).at(-1) || 'home'
    const timer = window.requestAnimationFrame(() => {
      document.getElementById(section)?.scrollIntoView({ behavior: 'smooth', block: 'start' })
    })
    return () => window.cancelAnimationFrame(timer)
  }, [location.pathname])

  const runMatch = async (task) => {
    setSelectedTask(task)
    setRecommendations([])
    setMatching(true)
    try {
      const data = await call('/api/matches/recommend/', { method: 'POST', body: JSON.stringify({ task_id: task.id }) })
      setRecommendations(data.recommendations)
    } catch (error) {
      setMessage(error.message)
    } finally {
      setMatching(false)
    }
  }

  const confirm = async (volunteer) => {
    try {
      await call('/api/matches/confirm/', { method: 'POST', body: JSON.stringify({ task_id: selectedTask.id, volunteer_id: volunteer.id }) })
      setMessage(`已邀请 ${volunteer.name} 加入「${selectedTask.title}」`)
      setSelectedTask(null)
      await load()
    } catch (error) {
      setMessage(error.message)
    }
  }

  return (
    <div className="page">
      <header className="topnav"><Link className="logo" to="/home"><span>✦</span><div><b>星愿</b><small>VOLUNTEER HUB</small></div></Link><nav><Link className={location.pathname.endsWith('/home') || location.pathname === '/' ? 'active' : ''} to="/home">服务大厅</Link><Link className={location.pathname.endsWith('/tasks') ? 'active' : ''} to="/tasks">项目管理</Link><Link className={location.pathname.endsWith('/volunteers') ? 'active' : ''} to="/volunteers">志愿者库</Link><Link className={location.pathname.endsWith('/data') ? 'active' : ''} to="/data">数据洞察</Link></nav><div className="nav-actions"><button className="search">⌕ 搜索服务</button><button className="notification">♧<i /></button><div className="account"><span>校</span><div><b>校青协</b><small>项目管理员</small></div><em>⌄</em></div></div></header>

      <main>
        <section className="hero" id="home"><div className="hero-copy"><span className="hero-label">SMART VOLUNTEER MATCHING</span><h1>让每一份热心，<br />遇见<span>恰好的需要。</span></h1><p>基于技能、时间、服务半径与志愿信用，为公益项目快速找到更合适的同行者。</p><div className="hero-actions"><button onClick={() => tasks[0] && runMatch(tasks[0])}>✦ 开始智能匹配</button><Link to="/tasks">浏览服务项目 →</Link></div><div className="trust"><div className="faces"><i>林</i><i>周</i><i>沈</i><i>江</i><i>+8</i></div><span><b>12,680+</b><small>人次共同参与志愿服务</small></span></div></div><div className="hero-art"><div className="orbit orbit-one" /><div className="orbit orbit-two" /><div className="heart-card"><div className="heart">♥</div><span>累计服务时长</span><strong>{dashboard.service_hours ?? '—'}<small>小时</small></strong><div className="mini-chart"><i /><i /><i /><i /><i /><i /></div><em>本月增长 18.6% ↗</em></div><div className="floating-tag tag-one"><span>✓</span><div><b>匹配成功</b><small>刚刚 · 国际文化节</small></div></div><div className="floating-tag tag-two"><span>98</span><div><b>志愿信用分</b><small>表现非常优秀</small></div></div></div></section>

        {message && <div className="message">{message}<button onClick={() => setMessage('')}>×</button></div>}

        <section className="summary" id="data"><article><span className="summary-icon green">◇</span><div><strong>{dashboard.active_tasks ?? '—'}</strong><p>正在招募的项目</p></div><em>查看项目 →</em></article><article><span className="summary-icon blue">♙</span><div><strong>{dashboard.available_volunteers ?? '—'}</strong><p>当前可服务志愿者</p></div><em>人才库 →</em></article><article><span className="summary-icon purple">✦</span><div><strong>{dashboard.match_rate ?? '—'}%</strong><p>智能匹配成功率</p></div><em>较上月 +4.2%</em></article><article><span className="summary-icon orange">◷</span><div><strong>{dashboard.service_hours ?? '—'}</strong><p>累计志愿服务小时</p></div><em>服务足迹 →</em></article></section>

        <section className="task-section" id="tasks"><div className="section-head"><div><span>OPPORTUNITIES</span><h2>值得参与的服务项目</h2><p>系统根据招募进度和服务时间，为你呈现近期重点项目。</p></div><button>查看全部项目 <span>→</span></button></div><div className="task-grid">{tasks.slice(0, 4).map((task) => <article className="task-card" key={task.id}><div className={`task-cover ${categoryStyle(task.category)}`}><span className="category">{task.category}</span><i>{task.required_skill.slice(0, 1)}</i><div className="cover-pattern" /></div><div className="task-body"><div className="task-top"><span>{task.status}</span><small>{task.matched}/{task.slots} 人已匹配</small></div><h3>{task.title}</h3><p>{task.description}</p><div className="task-info"><span>▣ {formatDate(task.start_at)} · {formatHour(task.start_at)}</span><span>⌖ {task.location}</span></div><div className="progress"><i style={{ width: `${Math.round(task.matched / task.slots * 100)}%` }} /></div><footer><div><span className="org">{task.organizer.slice(0, 1)}</span><small>{task.organizer}</small></div><button onClick={() => runMatch(task)}>✦ 智能匹配</button></footer></div></article>)}</div></section>

        <div className="lower-grid"><section className="volunteer-card" id="volunteers"><div className="section-head compact"><div><span>VOLUNTEER TALENTS</span><h2>活跃志愿者</h2></div><button>进入志愿者库 →</button></div><div className="volunteer-list">{volunteers.slice(0, 5).map((volunteer, index) => <article key={volunteer.id}><div className={`volunteer-avatar avatar-${index}`}>{volunteer.name.slice(-1)}</div><div><b>{volunteer.name}</b><small>{volunteer.college}</small><p>{volunteer.skills.split(',').slice(0, 2).map((skill) => <span key={skill}>{skill}</span>)}</p></div><strong>{volunteer.credit}<small>信用分</small></strong><em>{volunteer.available_hours}h 可用</em></article>)}</div></section><section className="match-feed"><div className="section-head compact"><div><span>RECENT MATCHES</span><h2>最近匹配动态</h2></div><i className="live-dot">LIVE</i></div><div className="feed-list">{matches.slice(0, 3).map((match) => <article key={match.id}><div className="feed-icon">✓</div><div><p><b>{match.volunteer.name}</b> 已加入</p><strong>{match.task.title}</strong><small>匹配度 {match.score}% · {match.status}</small></div></article>)}</div><div className="algorithm-note"><span>✦</span><p><b>可解释匹配算法</b><small>技能 42% · 片区 20% · 时间 16% · 信用与评价 22%</small></p></div></section></div>
      </main>

      {selectedTask && <div className="drawer-backdrop" onClick={() => setSelectedTask(null)}><aside className="drawer" onClick={(event) => event.stopPropagation()}><button className="drawer-close" onClick={() => setSelectedTask(null)}>×</button><span className="drawer-label">SMART MATCHING</span><h2>智能推荐志愿者</h2><p className="drawer-task">正在为「{selectedTask.title}」寻找合适人选</p><div className="matching-summary"><span>所需技能 <b>{selectedTask.required_skill}</b></span><span>服务片区 <b>{selectedTask.area}</b></span><span>服务时长 <b>{selectedTask.duration_hours}h</b></span></div>{matching ? <div className="matching-loader"><i /><b>正在计算多维匹配分</b><small>技能 · 片区 · 时间 · 信用 · 评价</small></div> : <div className="recommend-list">{recommendations.map((item, index) => <article key={item.volunteer.id}><em>0{index + 1}</em><div className={`recommend-avatar avatar-${index}`}>{item.volunteer.name.slice(-1)}</div><div className="recommend-copy"><h3>{item.volunteer.name}<small>{item.volunteer.college}</small></h3><div className="reason-list">{item.reasons.map((reason) => <span key={reason}>✓ {reason}</span>)}</div><p>{item.volunteer.skills.replaceAll(',', ' · ')}</p></div><strong>{item.score}<small>匹配分</small></strong><button onClick={() => confirm(item.volunteer)}>确认邀请</button></article>)}</div>}<div className="drawer-foot"><span>i</span><p>推荐结果仅用于辅助决策，确认前可联系志愿者核实实际时间安排。</p></div></aside></div>}
    </div>
  )
}

export default App
