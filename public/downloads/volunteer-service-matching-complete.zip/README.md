# 星愿志愿服务供需智能匹配平台

针对志愿服务招募中信息分散、人工筛选效率低、供需匹配依据不透明的问题，构建服务项目、
志愿者画像、可解释推荐与确认邀请一体化平台。源码采用 React + Go/Gin + SQLite，
无需额外中间件即可在资源受限的云环境运行。

本项目采用统一的本科毕业设计交付结构：

```text
volunteer-service-matching/
├── code/    # 可独立运行、测试和复现的完整源码
├── docs/    # 只保存最终毕业论文（DOCX，或 DOCX + PDF）
└── ppt/     # 只保存最终答辩 PPT（PPTX，可附 PDF 导出稿）
```

开发和运行请进入 `code/`，首次配置执行 `./manage.sh setup`。回到项目根目录后，最终交付前执行：

```bash
./code/manage.sh delivery-check --complete
```

`docs/` 不得放入开题报告、任务书、初稿、查重稿、设计说明、截图、Draw.io 图源或其他过程材料；
这些内容属于开发过程，不属于最终论文目录。`ppt/` 只保留最终答辩演示文稿及其 PDF 导出稿。
