# 知径：基于混合推荐算法的个性化学习路径规划系统

计算机科学与技术本科毕业设计。系统将课程拆分为带前置依赖的知识点图谱，并结合用户掌握度、
前置知识就绪度、难度匹配和群体反馈，动态推荐下一步学习内容，同时给出可解释的评分依据。

## 当前进度

- 已完成用户注册、JWT 登录和权限基础能力；
- 已完成课程、知识点、前置关系、选课和学习记录数据模型；
- 已实现可解释的混合推荐算法与冷启动策略；
- 已打通“浏览课程 → 加入课程 → 获取路径 → 记录学习 → 重算路径”核心闭环；
- 已完成课程首页和个人学习驾驶舱第一版；
- 已覆盖推荐算法和核心接口自动化测试。

## 技术栈

- 前端：React 19、React Router、Zustand、Tailwind CSS、Axios
- 后端：Django 4.2、Django REST Framework、Simple JWT
- 开发数据库：SQLite（生产环境可切换 MySQL）

## 本地运行

启动后端：

```bash
cd backend
./init.sh
python3 manage.py seed_learning_demo
./start.sh
```

启动前端：

```bash
cd frontend
npm ci
npm run dev
```

前端默认地址为 `http://127.0.0.1:5174`，后端默认地址为 `http://127.0.0.1:8181`。

## 验证

```bash
cd backend
python3 manage.py check
python3 manage.py test apps.learning

cd ../frontend
npm run lint
npm run build
```

接口契约见 [API_CONTRACT.md](./API_CONTRACT.md)，课题边界和模块登记见
[docs/PROJECT_PROFILE.md](./docs/PROJECT_PROFILE.md)。
