"""
URL configuration for mysite project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from rest_framework.decorators import api_view
from core.response import APIResponse


@api_view(['GET'])
def health_check(request):
    """健康检查接口"""
    return APIResponse(msg='OK')


urlpatterns = [
    path('admin/', admin.site.urls),
    
    # API 路由
    path('api/users/', include('apps.users.urls')),
    path('api/learning/', include('apps.learning.urls')),
    
    # 健康检查
    path('api/health/', health_check, name='health_check'),
]
