import os

from .development import *  # noqa: F403

DEBUG = False
ALLOWED_HOSTS = [host for host in os.environ.get('DJANGO_ALLOWED_HOSTS', 'bishe.codes123.cn').split(',') if host]
CSRF_TRUSTED_ORIGINS = [origin for origin in os.environ.get('DJANGO_CSRF_TRUSTED_ORIGINS', 'https://bishe.codes123.cn').split(',') if origin]

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': os.environ.get('SQLITE_PATH', BASE_DIR / 'db.sqlite3'),  # noqa: F405
    }
}

STATIC_URL = '/learning/static/'
STATIC_ROOT = os.environ.get('STATIC_ROOT', BASE_DIR / 'staticfiles')  # noqa: F405
SESSION_COOKIE_PATH = '/learning/'
CSRF_COOKIE_PATH = '/learning/'
SECURE_PROXY_SSL_HEADER = ('HTTP_X_FORWARDED_PROTO', 'https')
