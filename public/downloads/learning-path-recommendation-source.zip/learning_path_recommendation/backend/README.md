# 知径后端

Django REST Framework 后端，负责用户鉴权、课程知识图谱、学习记录和混合推荐。

```bash
./init.sh
python3 manage.py seed_learning_demo
./start.sh
```

开发服务默认监听 `http://127.0.0.1:8181`，使用 SQLite。验证命令：

```bash
python3 manage.py check
python3 manage.py makemigrations --check --dry-run
python3 manage.py test
```
