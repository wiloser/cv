#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "启动知径后端：http://127.0.0.1:8181"
echo "健康检查：http://127.0.0.1:8181/api/health/"

PYTHON="python3"
if [ -x .venv/bin/python ]; then
  PYTHON=".venv/bin/python"
fi
exec "$PYTHON" manage.py runserver 8181
