from rest_framework import serializers

from .models import Course, CourseKnowledgePoint, Enrollment, KnowledgePoint, LearningRecord


class KnowledgePointSerializer(serializers.ModelSerializer):
    prerequisites = serializers.PrimaryKeyRelatedField(many=True, read_only=True)

    class Meta:
        model = KnowledgePoint
        fields = ('id', 'title', 'description', 'difficulty', 'estimated_minutes', 'prerequisites')


class CoursePointSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(source='knowledge_point.id', read_only=True)
    title = serializers.CharField(source='knowledge_point.title', read_only=True)
    difficulty = serializers.IntegerField(source='knowledge_point.difficulty', read_only=True)
    estimated_minutes = serializers.IntegerField(source='knowledge_point.estimated_minutes', read_only=True)

    class Meta:
        model = CourseKnowledgePoint
        fields = ('id', 'title', 'difficulty', 'estimated_minutes', 'sequence', 'weight')


class CourseSerializer(serializers.ModelSerializer):
    knowledge_points = CoursePointSerializer(source='course_points', many=True, read_only=True)
    learner_count = serializers.IntegerField(read_only=True, default=0)

    class Meta:
        model = Course
        fields = (
            'id', 'title', 'summary', 'difficulty', 'estimated_minutes', 'tags',
            'learner_count', 'knowledge_points',
        )


class EnrollmentSerializer(serializers.ModelSerializer):
    course_title = serializers.CharField(source='course.title', read_only=True)

    class Meta:
        model = Enrollment
        fields = ('id', 'course', 'course_title', 'weekly_minutes', 'target_date', 'created_at')
        read_only_fields = ('id', 'created_at')

    def validate_course(self, value):
        if not value.is_published:
            raise serializers.ValidationError('该课程尚未发布')
        return value


class LearningRecordSerializer(serializers.ModelSerializer):
    knowledge_point_title = serializers.CharField(source='knowledge_point.title', read_only=True)

    class Meta:
        model = LearningRecord
        fields = (
            'id', 'knowledge_point', 'knowledge_point_title', 'mastery_score',
            'duration_minutes', 'is_completed', 'updated_at',
        )
        read_only_fields = ('id', 'updated_at')

    def validate_knowledge_point(self, value):
        user = self.context['request'].user
        is_enrolled = value.course_points.filter(course__enrollments__user=user).exists()
        if not is_enrolled:
            raise serializers.ValidationError('请先加入知识点所属课程')
        return value
