from django.db.models import Count
from rest_framework import status
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.views import APIView

from core.response import APIResponse

from .models import Course, Enrollment, LearningRecord
from .recommendation import recommend_for_user
from .serializers import CourseSerializer, EnrollmentSerializer, LearningRecordSerializer


class CatalogView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        courses = Course.objects.filter(is_published=True).annotate(
            learner_count=Count('enrollments', distinct=True),
        ).prefetch_related('course_points__knowledge_point')
        return APIResponse(data=CourseSerializer(courses, many=True).data)


class EnrollmentView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        serializer = EnrollmentSerializer(data=request.data, context={'request': request})
        serializer.is_valid(raise_exception=True)
        enrollment, created = Enrollment.objects.update_or_create(
            user=request.user,
            course=serializer.validated_data['course'],
            defaults={
                'weekly_minutes': serializer.validated_data.get('weekly_minutes', 180),
                'target_date': serializer.validated_data.get('target_date'),
            },
        )
        return APIResponse(
            code=status.HTTP_201_CREATED if created else status.HTTP_200_OK,
            msg='课程加入成功' if created else '学习计划已更新',
            data=EnrollmentSerializer(enrollment).data,
        )


class ProgressView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        serializer = LearningRecordSerializer(data=request.data, context={'request': request})
        serializer.is_valid(raise_exception=True)
        values = serializer.validated_data
        record, created = LearningRecord.objects.update_or_create(
            user=request.user,
            knowledge_point=values['knowledge_point'],
            defaults={
                'mastery_score': values.get('mastery_score', 0),
                'duration_minutes': values.get('duration_minutes', 0),
                'is_completed': values.get('is_completed', False),
            },
        )
        return APIResponse(
            code=status.HTTP_201_CREATED if created else status.HTTP_200_OK,
            msg='学习进度已记录',
            data=LearningRecordSerializer(record).data,
        )


class DashboardView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        enrollments = Enrollment.objects.filter(user=request.user).select_related('course')
        records = LearningRecord.objects.filter(user=request.user).select_related('knowledge_point')
        total_minutes = sum(record.duration_minutes for record in records)
        completed_count = sum(record.is_completed for record in records)
        mastery = round(
            sum(record.mastery_score for record in records) / records.count(), 1,
        ) if records.exists() else 0

        return APIResponse(data={
            'stats': {
                'course_count': enrollments.count(),
                'completed_count': completed_count,
                'total_minutes': total_minutes,
                'average_mastery': mastery,
            },
            'enrollments': EnrollmentSerializer(enrollments, many=True).data,
            'recent_records': LearningRecordSerializer(records[:8], many=True).data,
            'recommendations': [item.to_dict() for item in recommend_for_user(request.user)],
        })
