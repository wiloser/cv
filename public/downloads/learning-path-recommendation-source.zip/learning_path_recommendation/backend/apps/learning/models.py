from django.conf import settings
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models


class Course(models.Model):
    DIFFICULTY_CHOICES = (
        (1, '入门'),
        (2, '基础'),
        (3, '进阶'),
        (4, '高级'),
        (5, '挑战'),
    )

    title = models.CharField(max_length=120, unique=True, verbose_name='课程名称')
    summary = models.TextField(verbose_name='课程简介')
    difficulty = models.PositiveSmallIntegerField(
        choices=DIFFICULTY_CHOICES,
        validators=[MinValueValidator(1), MaxValueValidator(5)],
        default=2,
        verbose_name='难度',
    )
    estimated_minutes = models.PositiveIntegerField(default=120, verbose_name='预计学时（分钟）')
    tags = models.JSONField(default=list, blank=True, verbose_name='标签')
    is_published = models.BooleanField(default=True, verbose_name='是否发布')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'learning_courses'
        ordering = ['difficulty', 'id']

    def __str__(self):
        return self.title


class KnowledgePoint(models.Model):
    title = models.CharField(max_length=120, unique=True, verbose_name='知识点名称')
    description = models.TextField(blank=True, verbose_name='说明')
    difficulty = models.PositiveSmallIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(5)],
        default=2,
        verbose_name='难度',
    )
    estimated_minutes = models.PositiveIntegerField(default=30, verbose_name='预计学习时长')
    prerequisites = models.ManyToManyField(
        'self',
        symmetrical=False,
        related_name='unlocks',
        blank=True,
        verbose_name='前置知识点',
    )

    class Meta:
        db_table = 'learning_knowledge_points'
        ordering = ['difficulty', 'id']

    def __str__(self):
        return self.title


class CourseKnowledgePoint(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='course_points')
    knowledge_point = models.ForeignKey(
        KnowledgePoint,
        on_delete=models.CASCADE,
        related_name='course_points',
    )
    sequence = models.PositiveIntegerField(default=1, verbose_name='建议顺序')
    weight = models.DecimalField(max_digits=3, decimal_places=2, default=1, verbose_name='课程内权重')

    class Meta:
        db_table = 'learning_course_knowledge_points'
        ordering = ['sequence', 'id']
        constraints = [
            models.UniqueConstraint(
                fields=['course', 'knowledge_point'],
                name='unique_course_knowledge_point',
            ),
        ]


class Enrollment(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='enrollments')
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='enrollments')
    weekly_minutes = models.PositiveIntegerField(default=180, verbose_name='每周学习时间')
    target_date = models.DateField(null=True, blank=True, verbose_name='目标完成日期')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'learning_enrollments'
        constraints = [
            models.UniqueConstraint(fields=['user', 'course'], name='unique_user_course_enrollment'),
        ]


class LearningRecord(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='learning_records')
    knowledge_point = models.ForeignKey(
        KnowledgePoint,
        on_delete=models.CASCADE,
        related_name='learning_records',
    )
    mastery_score = models.PositiveSmallIntegerField(
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        default=0,
        verbose_name='掌握度',
    )
    duration_minutes = models.PositiveIntegerField(default=0, verbose_name='累计学习时长')
    is_completed = models.BooleanField(default=False, verbose_name='是否完成')
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'learning_records'
        ordering = ['-updated_at']
        constraints = [
            models.UniqueConstraint(fields=['user', 'knowledge_point'], name='unique_user_learning_record'),
        ]
