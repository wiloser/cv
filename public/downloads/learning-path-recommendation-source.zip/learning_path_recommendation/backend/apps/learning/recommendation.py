"""可解释的学习路径混合推荐算法。"""

from dataclasses import asdict, dataclass

from django.db.models import Avg, Count

from .models import KnowledgePoint, LearningRecord


@dataclass
class Recommendation:
    knowledge_point_id: int
    title: str
    score: float
    reason: str
    estimated_minutes: int
    difficulty: int
    components: dict[str, float]

    def to_dict(self):
        return asdict(self)


def _clamp(value: float) -> float:
    return max(0.0, min(1.0, value))


def recommend_for_user(user, limit=6):
    """按知识缺口、前置就绪度、难度匹配和群体反馈生成下一步建议。

    权重均显式保留，便于论文中做消融实验。冷启动用户主要依赖课程顺序与
    难度匹配；产生学习记录后，知识缺口和前置依赖会逐步成为主要信号。
    """

    enrolled_points = KnowledgePoint.objects.filter(
        course_points__course__enrollments__user=user,
        course_points__course__is_published=True,
    ).distinct()
    records = {
        record.knowledge_point_id: record
        for record in LearningRecord.objects.filter(user=user)
    }
    completed_scores = [record.mastery_score for record in records.values() if record.is_completed]
    ability = sum(completed_scores) / len(completed_scores) if completed_scores else 25.0
    target_difficulty = _clamp((ability / 25.0 + 1.0) / 5.0)

    points = enrolled_points.prefetch_related('prerequisites').annotate(
        learner_count=Count('learning_records', distinct=True),
        average_mastery=Avg('learning_records__mastery_score'),
    )
    recommendations = []

    for point in points:
        record = records.get(point.id)
        if record and record.is_completed and record.mastery_score >= 80:
            continue

        prerequisites = list(point.prerequisites.all())
        if prerequisites:
            readiness = sum(
                records.get(item.id).mastery_score if records.get(item.id) else 0
                for item in prerequisites
            ) / (100 * len(prerequisites))
        else:
            readiness = 1.0

        current_mastery = record.mastery_score if record else 0
        knowledge_gap = 1.0 - current_mastery / 100
        normalized_difficulty = point.difficulty / 5
        difficulty_fit = 1.0 - abs(normalized_difficulty - target_difficulty)
        popularity = (point.average_mastery or 50) / 100 if point.learner_count else 0.5

        components = {
            'knowledge_gap': round(knowledge_gap, 4),
            'prerequisite_readiness': round(readiness, 4),
            'difficulty_fit': round(difficulty_fit, 4),
            'peer_feedback': round(popularity, 4),
        }
        score = (
            knowledge_gap * 0.35
            + readiness * 0.35
            + difficulty_fit * 0.20
            + popularity * 0.10
        )

        if readiness < 0.6:
            reason = '建议先巩固前置知识，本项已降低优先级'
        elif record and record.mastery_score < 60:
            reason = f'当前掌握度 {record.mastery_score}%，适合优先补强'
        elif prerequisites:
            reason = '前置知识已基本就绪，可以继续进阶'
        else:
            reason = '无前置要求，适合作为当前起点'

        recommendations.append(Recommendation(
            knowledge_point_id=point.id,
            title=point.title,
            score=round(score, 4),
            reason=reason,
            estimated_minutes=point.estimated_minutes,
            difficulty=point.difficulty,
            components=components,
        ))

    recommendations.sort(key=lambda item: (-item.score, item.difficulty, item.knowledge_point_id))
    return recommendations[:limit]
