from django.contrib import admin

from .models import Course, CourseKnowledgePoint, Enrollment, KnowledgePoint, LearningRecord


class CourseKnowledgePointInline(admin.TabularInline):
    model = CourseKnowledgePoint
    extra = 1


@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ('title', 'difficulty', 'estimated_minutes', 'is_published')
    list_filter = ('difficulty', 'is_published')
    inlines = [CourseKnowledgePointInline]


@admin.register(KnowledgePoint)
class KnowledgePointAdmin(admin.ModelAdmin):
    list_display = ('title', 'difficulty', 'estimated_minutes')
    filter_horizontal = ('prerequisites',)


admin.site.register(Enrollment)
admin.site.register(LearningRecord)
