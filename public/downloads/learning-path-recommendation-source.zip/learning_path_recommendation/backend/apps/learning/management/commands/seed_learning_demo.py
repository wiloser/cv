from django.core.management.base import BaseCommand
from django.db import transaction

from apps.learning.models import Course, CourseKnowledgePoint, KnowledgePoint


COURSES = [
    {
        'title': 'Python 数据分析入门',
        'summary': '从 Python 基础出发，完成数据清洗、统计分析和可视化的完整学习路径。',
        'difficulty': 2,
        'estimated_minutes': 480,
        'tags': ['Python', '数据分析', '可视化'],
        'points': [
            ('Python 基础语法', 1, 80, []),
            ('NumPy 数组计算', 2, 90, ['Python 基础语法']),
            ('Pandas 数据清洗', 2, 120, ['Python 基础语法', 'NumPy 数组计算']),
            ('描述性统计', 2, 80, ['Pandas 数据清洗']),
            ('Matplotlib 可视化', 2, 110, ['Pandas 数据清洗']),
        ],
    },
    {
        'title': 'Web 前端开发基础',
        'summary': '掌握页面结构、响应式样式和 React 组件化开发，完成交互式网页。',
        'difficulty': 2,
        'estimated_minutes': 520,
        'tags': ['HTML', 'CSS', 'React'],
        'points': [
            ('HTML 语义化结构', 1, 60, []),
            ('CSS 布局与响应式', 2, 100, ['HTML 语义化结构']),
            ('JavaScript 核心语法', 2, 120, []),
            ('React 组件与状态', 3, 140, ['JavaScript 核心语法']),
            ('前端接口联调', 3, 100, ['React 组件与状态']),
        ],
    },
    {
        'title': '机器学习实践',
        'summary': '以真实数据集为线索，理解特征工程、模型训练、评估与调优。',
        'difficulty': 4,
        'estimated_minutes': 720,
        'tags': ['机器学习', '特征工程', '模型评估'],
        'points': [
            ('机器学习问题定义', 2, 70, []),
            ('数据预处理与特征工程', 3, 150, ['机器学习问题定义']),
            ('监督学习模型', 4, 180, ['数据预处理与特征工程']),
            ('模型评估与交叉验证', 4, 150, ['监督学习模型']),
            ('超参数优化', 5, 170, ['模型评估与交叉验证']),
        ],
    },
]


class Command(BaseCommand):
    help = '幂等写入学习路径演示课程、知识点和前置关系'

    @transaction.atomic
    def handle(self, *args, **options):
        point_cache = {}
        for course_data in COURSES:
            course, _ = Course.objects.update_or_create(
                title=course_data['title'],
                defaults={key: course_data[key] for key in ('summary', 'difficulty', 'estimated_minutes', 'tags')},
            )
            for sequence, (title, difficulty, minutes, prerequisite_titles) in enumerate(course_data['points'], 1):
                point, _ = KnowledgePoint.objects.update_or_create(
                    title=title,
                    defaults={'difficulty': difficulty, 'estimated_minutes': minutes},
                )
                point_cache[title] = point
                CourseKnowledgePoint.objects.update_or_create(
                    course=course,
                    knowledge_point=point,
                    defaults={'sequence': sequence},
                )
                prerequisites = []
                for prerequisite_title in prerequisite_titles:
                    prerequisite = point_cache.get(prerequisite_title)
                    if prerequisite is None:
                        prerequisite = KnowledgePoint.objects.get(title=prerequisite_title)
                    prerequisites.append(prerequisite)
                point.prerequisites.set(prerequisites)

        self.stdout.write(self.style.SUCCESS(f'演示数据已就绪：{len(COURSES)} 门课程'))
