from django.urls import path

from .views import CatalogView, DashboardView, EnrollmentView, ProgressView


urlpatterns = [
    path('catalog/', CatalogView.as_view(), name='learning-catalog'),
    path('dashboard/', DashboardView.as_view(), name='learning-dashboard'),
    path('enrollments/', EnrollmentView.as_view(), name='learning-enrollment'),
    path('progress/', ProgressView.as_view(), name='learning-progress'),
]
