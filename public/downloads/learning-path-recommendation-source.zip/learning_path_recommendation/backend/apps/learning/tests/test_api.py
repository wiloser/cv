from django.contrib.auth import get_user_model
from django.urls import reverse
from rest_framework.test import APITestCase

from apps.learning.models import Course, CourseKnowledgePoint, KnowledgePoint


class LearningApiTests(APITestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user('learner', password='Test-pass-123')
        self.course = Course.objects.create(title='Python 入门', summary='测试课程', difficulty=1)
        self.point = KnowledgePoint.objects.create(title='变量与类型', difficulty=1)
        CourseKnowledgePoint.objects.create(course=self.course, knowledge_point=self.point)

    def test_catalog_is_public(self):
        response = self.client.get(reverse('learning-catalog'))

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data['data'][0]['title'], 'Python 入门')

    def test_enroll_progress_and_dashboard_form_a_closed_loop(self):
        self.client.force_authenticate(self.user)
        enrollment = self.client.post(
            reverse('learning-enrollment'),
            {'course': self.course.id, 'weekly_minutes': 240},
            format='json',
        )
        progress = self.client.post(
            reverse('learning-progress'),
            {
                'knowledge_point': self.point.id,
                'mastery_score': 72,
                'duration_minutes': 45,
                'is_completed': False,
            },
            format='json',
        )
        dashboard = self.client.get(reverse('learning-dashboard'))

        self.assertEqual(enrollment.status_code, 201)
        self.assertEqual(progress.status_code, 201)
        self.assertEqual(dashboard.status_code, 200)
        self.assertEqual(dashboard.data['data']['stats']['course_count'], 1)
        self.assertEqual(dashboard.data['data']['stats']['total_minutes'], 45)
        self.assertEqual(dashboard.data['data']['recommendations'][0]['knowledge_point_id'], self.point.id)

    def test_progress_requires_enrollment(self):
        self.client.force_authenticate(self.user)

        response = self.client.post(
            reverse('learning-progress'),
            {'knowledge_point': self.point.id, 'mastery_score': 30},
            format='json',
        )

        self.assertEqual(response.status_code, 400)
