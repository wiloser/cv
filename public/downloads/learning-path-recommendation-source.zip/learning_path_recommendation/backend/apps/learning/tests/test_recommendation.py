from django.contrib.auth import get_user_model
from django.test import TestCase

from apps.learning.models import Course, CourseKnowledgePoint, Enrollment, KnowledgePoint, LearningRecord
from apps.learning.recommendation import recommend_for_user


class RecommendationTests(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user('learner', password='Test-pass-123')
        self.course = Course.objects.create(title='算法基础', summary='测试课程', difficulty=2)
        self.basic = KnowledgePoint.objects.create(title='数据结构', difficulty=1)
        self.advanced = KnowledgePoint.objects.create(title='图搜索', difficulty=3)
        self.advanced.prerequisites.add(self.basic)
        CourseKnowledgePoint.objects.create(course=self.course, knowledge_point=self.basic, sequence=1)
        CourseKnowledgePoint.objects.create(course=self.course, knowledge_point=self.advanced, sequence=2)
        Enrollment.objects.create(user=self.user, course=self.course)

    def test_prerequisite_not_ready_lowers_advanced_point_score(self):
        recommendations = recommend_for_user(self.user)

        self.assertEqual(recommendations[0].knowledge_point_id, self.basic.id)
        advanced = next(item for item in recommendations if item.knowledge_point_id == self.advanced.id)
        self.assertEqual(advanced.components['prerequisite_readiness'], 0)

    def test_completed_point_is_removed_and_unlocks_next_point(self):
        LearningRecord.objects.create(
            user=self.user,
            knowledge_point=self.basic,
            mastery_score=90,
            is_completed=True,
        )

        recommendations = recommend_for_user(self.user)

        self.assertEqual([item.knowledge_point_id for item in recommendations], [self.advanced.id])
        self.assertEqual(recommendations[0].components['prerequisite_readiness'], 0.9)
