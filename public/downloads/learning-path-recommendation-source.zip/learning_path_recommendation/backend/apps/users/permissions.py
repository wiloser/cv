from rest_framework.permissions import BasePermission


class IsAdminUser(BasePermission):
    """
    自定义管理员权限
    
    只有 role='admin' 的用户才能访问
    """
    
    def has_permission(self, request, view):
        return request.user and request.user.is_authenticated and request.user.is_admin
