import logging
from django.contrib.auth import authenticate
from rest_framework import status, generics
from rest_framework import serializers as rf_serializers
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework_simplejwt.serializers import TokenRefreshSerializer
from rest_framework_simplejwt.tokens import RefreshToken
from core.response import APIResponse
from apps.users.serializers import (
    UserSerializer,
    RegisterSerializer,
    LoginSerializer,
    ChangePasswordSerializer,
)
from apps.users.permissions import IsAdminUser

logger = logging.getLogger('apps')


class RegisterView(generics.CreateAPIView):
    """用户注册"""
    
    permission_classes = [AllowAny]
    serializer_class = RegisterSerializer
    
    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        
        logger.info(f'用户注册成功: {user.username}')
        
        return APIResponse(
            code=status.HTTP_201_CREATED,
            msg='注册成功',
            data=UserSerializer(user).data
        )


class LoginView(generics.GenericAPIView):
    """用户登录"""
    
    permission_classes = [AllowAny]
    serializer_class = LoginSerializer
    
    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        
        username = serializer.validated_data['username']
        password = serializer.validated_data['password']
        
        user = authenticate(username=username, password=password)
        
        if user is None:
            logger.warning(f'登录失败: 用户名或密码错误 - {username}')
            return APIResponse(
                code=status.HTTP_401_UNAUTHORIZED,
                msg='用户名或密码错误',
                data=None
            )
        
        # 生成 JWT tokens
        refresh = RefreshToken.for_user(user)
        
        logger.info(f'用户登录成功: {user.username}')
        
        return APIResponse(
            code=status.HTTP_200_OK,
            msg='登录成功',
            data={
                'access': str(refresh.access_token),
                'refresh': str(refresh),
                'user': UserSerializer(user).data,
            }
        )


class RefreshTokenView(generics.GenericAPIView):
    """刷新 access token，并保持统一响应格式。"""

    permission_classes = [AllowAny]
    serializer_class = TokenRefreshSerializer

    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        return APIResponse(msg='Token 刷新成功', data=serializer.validated_data)


class LogoutView(generics.GenericAPIView):
    """用户退出登录"""
    
    permission_classes = [IsAuthenticated]
    
    def post(self, request):
        logger.info(f'用户退出登录: {request.user.username}')
        return APIResponse(msg='退出成功')


class UserProfileView(generics.RetrieveUpdateAPIView):
    """用户个人信息"""
    
    permission_classes = [IsAuthenticated]
    serializer_class = UserSerializer
    
    def get_object(self):
        return self.request.user
    
    def retrieve(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = self.get_serializer(instance)
        return APIResponse(data=serializer.data)
    
    def update(self, request, *args, **kwargs):
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        
        try:
            serializer.is_valid(raise_exception=True)
        except rf_serializers.ValidationError as e:
            # 提取第一个错误信息作为 msg
            error_data = e.detail
            first_error = None
            if isinstance(error_data, dict):
                # 获取第一个字段的错误
                for field, errors in error_data.items():
                    if errors:
                        first_error = errors[0] if isinstance(errors, list) else str(errors)
                        break
            elif isinstance(error_data, list):
                first_error = error_data[0]
            
            return APIResponse(
                code=status.HTTP_400_BAD_REQUEST,
                msg=first_error or '验证失败',
                data=None
            )
        
        self.perform_update(serializer)
        return APIResponse(msg='更新成功', data=serializer.data)


class ChangePasswordView(generics.GenericAPIView):
    """修改密码"""
    
    permission_classes = [IsAuthenticated]
    serializer_class = ChangePasswordSerializer
    
    def post(self, request):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        
        user = request.user
        
        # 验证旧密码
        if not user.check_password(serializer.validated_data['old_password']):
            return APIResponse(
                code=status.HTTP_400_BAD_REQUEST,
                msg='旧密码错误',
                data={'old_password': '旧密码不正确'}
            )
        
        # 设置新密码
        user.set_password(serializer.validated_data['new_password'])
        user.save()
        
        logger.info(f'用户修改密码成功: {user.username}')
        
        return APIResponse(msg='密码修改成功')


class UserListView(generics.ListAPIView):
    """用户列表（仅管理员）"""
    
    permission_classes = [IsAuthenticated, IsAdminUser]
    serializer_class = UserSerializer
    
    def get_queryset(self):
        from django.contrib.auth import get_user_model
        User = get_user_model()
        return User.objects.all().order_by('-date_joined')
    
    def list(self, request, *args, **kwargs):
        queryset = self.get_queryset()
        
        # 分页处理
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)
        
        serializer = self.get_serializer(queryset, many=True)
        return APIResponse(data=serializer.data)
