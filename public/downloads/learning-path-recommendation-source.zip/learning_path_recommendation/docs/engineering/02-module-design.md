# 模块设计

## 1. 后端模块

| 模块 | 代码位置 | 职责 |
| --- | --- | --- |
| 用户与鉴权 | `backend/apps/users/` | 注册、登录、刷新、资料、改密和管理员用户列表 |
| 学习领域模型 | `backend/apps/learning/models.py` | 课程、知识点、前置关系、选课和学习记录 |
| 推荐服务 | `backend/apps/learning/recommendation.py` | 计算可解释的下一步学习建议 |
| 学习接口 | `backend/apps/learning/views.py` | 目录、选课、进度和驾驶舱接口 |
| 统一响应 | `backend/core/` | 响应格式、分页和异常处理 |

推荐服务保持为无 HTTP 状态的领域函数，便于独立测试和后续算法替换。

## 2. 前端模块

| 模块 | 代码位置 | 职责 |
| --- | --- | --- |
| 路由与权限 | `frontend/src/router/` | 公开路由、登录保护和管理员保护 |
| API 客户端 | `frontend/src/api/` | 请求拦截、Token 刷新及业务接口封装 |
| 用户状态 | `frontend/src/stores/userStore.js` | 登录态和资料状态 |
| 课程首页 | `frontend/src/views/Home.jsx` | 课程目录和加入课程入口 |
| 学习驾驶舱 | `frontend/src/views/learning/` | 统计、推荐解释和进度录入 |

## 3. 核心业务流程

1. 游客浏览公开课程目录并注册或登录。
2. 学习者加入课程，设置每周可投入时间。
3. 后端根据知识点依赖和历史记录生成排序建议。
4. 学习者填写掌握度、学习时长和完成状态。
5. 后端更新记录并在下一次驾驶舱请求中重新计算路径。
