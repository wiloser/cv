# 数据库与数据字典

开发环境使用 SQLite，表结构由 Django 迁移文件管理。生产环境可通过
`backend/mysite/settings/production.py` 切换 MySQL。

## 1. 核心实体

| 表 | 主键 | 关键字段 | 约束与关系 |
| --- | --- | --- | --- |
| `users` | `id` | `username`、`email`、`phone`、`role` | 用户名唯一，邮箱和手机号可空且唯一 |
| `learning_courses` | `id` | `title`、`difficulty`、`tags`、`is_published` | 课程名唯一，难度 1～5 |
| `learning_knowledge_points` | `id` | `title`、`difficulty`、`estimated_minutes` | 知识点名称唯一，自关联前置关系 |
| `learning_course_knowledge_points` | `id` | `course_id`、`knowledge_point_id`、`sequence` | 课程与知识点组合唯一 |
| `learning_enrollments` | `id` | `user_id`、`course_id`、`weekly_minutes` | 用户与课程组合唯一 |
| `learning_records` | `id` | `user_id`、`knowledge_point_id`、`mastery_score` | 用户与知识点组合唯一，掌握度 0～100 |

## 2. 关系

- 用户与课程通过 `learning_enrollments` 构成多对多关系。
- 课程与知识点通过 `learning_course_knowledge_points` 构成有序多对多关系。
- 知识点通过 `prerequisites` 自关联形成有向依赖图。
- 用户与知识点通过 `learning_records` 保存最新掌握状态。

## 3. 迁移规范

模型变更后执行：

```bash
cd backend
python3 manage.py makemigrations
python3 manage.py migrate
python3 manage.py makemigrations --check --dry-run
```

已提交并在共享环境执行的历史迁移不直接修改，后续变化使用新迁移表达。
