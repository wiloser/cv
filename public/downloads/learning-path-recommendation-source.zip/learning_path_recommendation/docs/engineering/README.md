# 工程文档

本目录只描述“知径”当前实际实现，不记录已删除的脚手架方案。接口事实以
[API_CONTRACT.md](../../API_CONTRACT.md) 和代码为准。

| 文档 | 内容 |
| --- | --- |
| [01-system-architecture.md](./01-system-architecture.md) | 系统架构和技术边界 |
| [02-module-design.md](./02-module-design.md) | 前后端模块职责 |
| [03-database-and-data-dictionary.md](./03-database-and-data-dictionary.md) | 实体、关系和约束 |
| [04-api-and-integration.md](./04-api-and-integration.md) | REST 接口与联调约定 |
| [05-development-standards.md](./05-development-standards.md) | 开发规范 |
| [06-testing-and-acceptance.md](./06-testing-and-acceptance.md) | 测试和验收 |
| [07-deployment-and-operations.md](./07-deployment-and-operations.md) | 本地运行和部署 |
| [08-security-design.md](./08-security-design.md) | 安全设计 |

实际工程目录：

```text
backend/        Django API、模型、迁移和测试
frontend/       React 页面、状态管理和 API 客户端
docs/           工程与论文材料
```
