# 部署与运行

## 1. 开发环境

要求 Python 3.10+、Node.js 22+。后端初始化：

```bash
cd backend
./init.sh
python3 manage.py seed_learning_demo
./start.sh
```

前端启动：

```bash
cd frontend
npm ci
npm run dev
```

前端监听 `5174`，后端监听 `8181`。SQLite、日志、依赖和构建产物均被 Git 忽略。

## 2. 生产部署建议

- 前端执行 `npm ci && npm run build`，由 Nginx 等静态服务器托管 `frontend/dist/`。
- 后端使用 Gunicorn 启动 WSGI 应用，并通过反向代理提供 `/api`。
- 设置 `DJANGO_SETTINGS_MODULE=mysite.settings.production`、强随机密钥和 MySQL 连接信息。
- 生产环境关闭 `DEBUG`，限制 `ALLOWED_HOSTS` 和 CORS 来源，启用 HTTPS。

当前仓库不包含云平台、域名、证书或生产数据库凭据。
