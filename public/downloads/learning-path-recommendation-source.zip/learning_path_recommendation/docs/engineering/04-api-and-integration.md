# API 与前后端联调

完整路径和字段见 [API_CONTRACT.md](../../API_CONTRACT.md)。

## 1. 基础约定

- API 前缀为 `/api`，JSON 字段使用 `snake_case`。
- 鉴权头为 `Authorization: Bearer <access_token>`。
- 响应固定包含 `code`、`msg` 和 `data`，HTTP 状态与 `code` 一致。
- 列表分页使用 `page` 和 `page_size`。

## 2. 学习领域接口

| 方法 | 路径 | 权限 | 作用 |
| --- | --- | --- | --- |
| GET | `/api/learning/catalog/` | 公开 | 课程和知识点目录 |
| POST | `/api/learning/enrollments/` | 登录 | 加入课程或更新计划 |
| POST | `/api/learning/progress/` | 登录 | 写入知识点学习状态 |
| GET | `/api/learning/dashboard/` | 登录 | 返回统计、记录和推荐 |

前端业务页面只通过 `frontend/src/api/` 中的封装访问接口。401 时 Axios 拦截器合并并发刷新请求；
刷新失败则清理本地登录态并跳转登录页。

## 3. 错误处理

参数无效返回 400，未登录返回 401，无权限返回 403，资源不存在返回 404。领域校验必须由后端执行，
前端隐藏按钮不能替代权限控制。
