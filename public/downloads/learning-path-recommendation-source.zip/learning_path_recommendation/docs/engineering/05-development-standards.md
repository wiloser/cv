# 开发规范

## 1. 通用规则

- 提交中不包含 `.env`、数据库、日志、依赖目录和构建产物。
- API 字段、数据库表名使用 `snake_case`；React 组件使用 `PascalCase`。
- 业务规则放在后端领域模块，页面不复制推荐或权限逻辑。
- 数据模型、接口和页面变化应同步更新文档与测试。

## 2. 后端

- 模型放在对应 Django app，数据库变化必须生成迁移。
- 写接口先通过 Serializer 校验输入，再执行领域操作。
- 所有登录用户数据查询都显式绑定 `request.user`。
- 推荐算法权重和分项得分保持可追踪，便于实验复现。

## 3. 前端

- 页面放在 `frontend/src/views/`，共享组件放在 `frontend/src/components/`。
- HTTP 请求统一经 `frontend/src/api/index.js`，不新增散落的 Axios 实例。
- 异步操作包含加载、成功和失败反馈；受保护页面由路由统一拦截。

## 4. 提交前检查

```bash
cd backend && python3 manage.py check && python3 manage.py test
cd ../frontend && npm run lint && npm run build
```
