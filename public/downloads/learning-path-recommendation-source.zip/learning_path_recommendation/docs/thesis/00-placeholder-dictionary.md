# 统一占位符字典

派生项目的论文、draw.io 图、PPT 和过程材料统一使用下列约定占位符。不得自行增加其他双花括号占位符；其他待填内容使用 `【项目必填：说明】`、`【实测必填：说明】` 或 `【来源必填：说明】`。

## 占位符清单

| 占位符 | 含义 | 填写/替换责任 |
|---|---|---|
| `{{PROJECT_NAME}}` | 项目/系统简称 | 派生器自动替换 |
| `{{PROJECT_TITLE_ZH}}` | 中文论文题目 | 具体毕设填写；与任务书、封面一致 |
| `{{PROJECT_TITLE_EN}}` | 英文论文题目 | 具体毕设填写；与中文题目语义一致 |
| `{{BUSINESS_DOMAIN}}` | 业务领域 | 具体毕设填写 |
| `{{FRONTEND_STACK}}` | 实际前端技术栈 | 派生器自动替换 |
| `{{BACKEND_STACK}}` | 实际后端技术栈 | 派生器自动替换 |
| `{{LOCAL_DATABASE}}` | 本地开发数据库 | 派生器自动替换 |
| `{{STUDENT_NAME}}` | 学生姓名 | 具体毕设填写 |
| `{{STUDENT_ID}}` | 学号 | 具体毕设填写 |
| `{{MAJOR}}` | 专业全称 | 具体毕设填写 |
| `{{COLLEGE}}` | 学院全称 | 具体毕设填写 |
| `{{UNIVERSITY}}` | 学校全称 | 具体毕设填写 |
| `{{ADVISOR}}` | 指导教师姓名/职称（按学校模板） | 具体毕设填写 |
| `{{DATE}}` | 文档要求的日期 | 具体毕设填写；按学校格式 |

> `{{DATE}}` 用于封面或材料基准日期；实验、访谈、提交等实际发生时间仍应在对应记录中逐项填写，不能批量替换成同一天。

## 派生后项目元信息表

具体项目可复制并填写下表。派生器自动替换的字段仍应人工核对实际依赖版本。

```yaml
project_name: "{{PROJECT_NAME}}"
project_title_zh: "{{PROJECT_TITLE_ZH}}"
project_title_en: "{{PROJECT_TITLE_EN}}"
business_domain: "{{BUSINESS_DOMAIN}}"

frontend_stack: "{{FRONTEND_STACK}}"
backend_stack: "{{BACKEND_STACK}}"
local_database: "{{LOCAL_DATABASE}}"

student_name: "{{STUDENT_NAME}}"
student_id: "{{STUDENT_ID}}"
major: "{{MAJOR}}"
college: "{{COLLEGE}}"
university: "{{UNIVERSITY}}"
advisor: "{{ADVISOR}}"
date: "{{DATE}}"

project_scope: "【项目必填：系统包含和不包含的范围】"
target_users: "【项目必填：实际用户角色】"
data_source: "【项目必填：真实授权、公开、模拟或合成数据】"
deployment_scenario: "【项目必填：最终演示/部署环境】"
repository_revision: "【项目必填：论文对应 Git 标签或提交哈希】"
```

## 命名一致性检查

- `{{PROJECT_TITLE_ZH}}` 在任务书、开题报告、论文、PPT 中完全一致。
- `{{PROJECT_TITLE_EN}}` 经人工校对，不直接保留未经核验的机器翻译。
- `{{PROJECT_NAME}}` 作为系统简称在正文、界面和图表中统一。
- 角色名与用例、权限矩阵、菜单、接口校验和测试账号一致。
- 实体名与 ER 图、数据库模型、迁移文件和数据字典一致。
- API 名与接口文档、前端调用、后端路由和测试脚本一致。
- 技术栈描述与实际锁文件、依赖文件和运行环境一致。
- 本地数据库与最终部署数据库不同的，必须明确说明兼容验证和迁移方式。
- 论文对应代码必须记录不可变 Git 标签或提交哈希。

## 遗留项检查

在派生项目根目录执行：

```bash
rg -n '\{\{[A-Z0-9_]+\}\}|TBD|【项目必填|【实测必填|【来源必填' docs
```

论文定稿前，正文和交付材料中的占位符与待填标记必须清零；作为空白模板保留的文件应与正式论文分开。
