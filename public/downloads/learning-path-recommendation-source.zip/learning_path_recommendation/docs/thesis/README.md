# 本科计算机毕业设计论文原材料

本目录是从基础架构派生具体毕业设计项目时使用的论文原材料库。它提供写作框架、取证清单、图表规划和过程记录模板，不代表任何具体项目已经完成相应工作。

## 使用原则

1. 先复制基础项目并确定题目，再统一替换 [`00-placeholder-dictionary.md`](./00-placeholder-dictionary.md) 中的占位符。
2. 需求、设计、实现、测试应以实际代码和过程证据为准，不能先编造论文结论再补代码。
3. 所有性能数据、测试通过率、用户数量、响应时间等必须实测并保留原始记录。
4. 所有参考文献必须真实存在、可检索且确实阅读过；本目录不提供虚构示例文献。
5. 学校格式要求优先于本模板。获得学校论文模板后，应逐项调整封面、目录、字号、行距、图表编号及参考文献格式。
6. 项目中的密钥、密码、真实个人信息和生产数据不得进入论文、截图或答辩材料。

## 标记约定

- `【项目必填】`：必须根据派生项目补充，不能保留在最终论文中。
- `【实测必填】`：必须通过实际实验或测试采集，不得估算或虚构。
- `【来源必填】`：必须给出可核验来源，并纳入参考文献记录。
- `【可复用】`：可作为通用写作思路，但仍需结合项目改写。
- `TBD`：尚未完成。提交前必须全部清零。

可使用以下命令检查遗留标记：

```bash
rg -n 'TBD|【项目必填】|【实测必填】|【来源必填】' docs/thesis
```

## 材料导航

| 材料 | 用途 | 主要产出 |
|---|---|---|
| [`00-placeholder-dictionary.md`](./00-placeholder-dictionary.md) | 统一学校、题目、业务和技术占位符 | 项目元信息表 |
| [`01-writing-outline.md`](./01-writing-outline.md) | 规划全文论证主线与篇幅 | 论文写作总纲 |
| [`chapters/`](./chapters/) | 按章节沉淀可写入论文的内容 | 七章论文初稿素材 |
| [`02-requirements-and-use-cases.md`](./02-requirements-and-use-cases.md) | 定义角色、需求、用例和验收条件 | 需求矩阵与用例表 |
| [`03-innovation-and-workload-evidence.md`](./03-innovation-and-workload-evidence.md) | 证明个人贡献、创新性和完成度 | 证据索引 |
| [`04-figures-and-tables-inventory.md`](./04-figures-and-tables-inventory.md) | 提前规划 draw.io 图、截图和表格 | 图表台账 |
| [`05-experiment-and-test-data.md`](./05-experiment-and-test-data.md) | 规范实验设计和数据留存 | 原始数据与测试结论 |
| [`06-reference-recording-guide.md`](./06-reference-recording-guide.md) | 记录检索、阅读和引用信息 | 可核验参考文献台账 |
| [`07-defense-materials-checklist.md`](./07-defense-materials-checklist.md) | 准备答辩 PPT、演示和问答 | 答辩材料包 |
| [`08-weekly-progress-and-change-log.md`](./08-weekly-progress-and-change-log.md) | 留存周进度、决策和变更依据 | 开发过程证据 |

## 推荐工作流

```text
选题与元信息
  -> 需求访谈/资料调研
  -> 用例与验收标准
  -> 架构、流程和数据设计
  -> 迭代实现并保留 Git 证据
  -> 功能/接口/性能/安全测试
  -> 整理图表与原始实验数据
  -> 按章节撰写
  -> 引文核验、格式审查、答辩准备
```

## 派生项目建议保留的证据

- 需求来源、访谈纪要或调研问卷的脱敏版本。
- 每周 Git 提交、Issue、变更记录和里程碑版本号。
- API 契约、数据库迁移、自动化测试报告和构建日志。
- draw.io 源文件、导出图片以及图与代码版本的对应关系。
- 测试环境信息、原始数据、复现实验命令和异常说明。
- 论文中每个结论对应的代码、测试或文献来源。

最终论文不得直接照抄模板句式。模板的作用是保证论证完整、证据可追溯，而不是替代具体项目分析。
