# 项目档案

> 本文件是毕设项目元数据的唯一入口；学校与人员信息应在立项后第一周内补齐。

## 基本信息

| 字段 | 内容 |
| --- | --- |
| 项目代号 | `learning-path-recommendation` |
| 中文题目 | 基于混合推荐算法的个性化学习路径规划系统设计与实现 |
| 英文题目 | Design and Implementation of a Personalized Learning Path Planning System Based on Hybrid Recommendation |
| 业务领域 | 在线教育、个性化学习、推荐系统 |
| 学校 | {{UNIVERSITY}} |
| 学院 | {{COLLEGE}} |
| 专业 | {{MAJOR}} |
| 学生 | {{STUDENT_NAME}}（{{STUDENT_ID}}） |
| 指导教师 | {{ADVISOR}} |
| 文档日期 | {{DATE}} |

## 技术基线

| 层次 | 选择 | 事实来源 |
| --- | --- | --- |
| 前端 | React 19、React Router、Zustand、Tailwind CSS | `frontend/package.json` |
| 后端 | Django 4.2、Django REST Framework | `backend/requirements.txt` |
| 本地数据库 | SQLite | `backend/mysite/settings/development.py` |
| 接口风格 | REST、JSON、`snake_case` | `API_CONTRACT.md` |
| 鉴权 | JWT access/refresh | 用户模块实现 |
| 本地运行 | Django `8181`、React `5174` | 根目录 `README.md` |

## 课题边界

### 问题陈述

面向需要自主规划学习内容的高校学生和初级技术学习者。常见在线课程以固定章节顺序组织，难以根据
学习者已有基础、掌握薄弱点和可投入时间调整学习次序；学习者面对大量课程时也难以判断下一步应学
什么。系统以课程知识点及其前置依赖构建轻量知识图谱，持续记录个人掌握度和学习时长，通过混合
评分动态生成下一步路径并解释推荐原因，帮助用户减少无效重复学习并保持合理的难度梯度。

### 建设目标

1. 实现从课程浏览、学习计划建立、知识点学习记录到路径动态更新的业务闭环。
2. 实现融合知识缺口、前置就绪度、难度匹配和群体反馈的可解释推荐算法。
3. 核心接口具备权限、参数校验和自动化测试，推荐结果可用于消融实验和指标对比。

### 不在范围内

- 不自研视频播放、直播授课、在线考试和支付能力，课程内容以知识点元数据和外部资源链接为主。
- 第一阶段使用可复现实验数据和管理员录入数据，不依赖商业教育平台的私有数据接口。

## 模块登记

| 模块编号 | 模块名称 | 用户角色 | 主要能力 | 代码位置 | 状态 |
| --- | --- | --- | --- | --- | --- |
| M-BASE-01 | 用户与鉴权 | 游客、用户、管理员 | 注册、登录、刷新、资料、改密、用户列表 | `frontend/src`、`backend/apps/users` | 已有基线 |
| M-BIZ-01 | 课程知识图谱 | 游客、管理员 | 课程目录、知识点、前置关系 | `backend/apps/learning` | 第一版完成 |
| M-BIZ-02 | 学习计划与进度 | 学习者 | 加入课程、掌握度和时长记录 | `backend/apps/learning` | 第一版完成 |
| M-BIZ-03 | 混合推荐 | 学习者 | 动态路径、可解释分项评分 | `recommendation.py` | 第一版完成 |
| M-BIZ-04 | 学习驾驶舱 | 学习者 | 统计、推荐列表、进度录入 | `frontend/src/views/learning` | 第一版完成 |

## 业务实体登记

| 实体编号 | 实体名称 | 用途 | 所有者/关联 | ER 图状态 | 迁移状态 |
| --- | --- | --- | --- | --- | --- |
| E-BASE-01 | users | 账户、角色与认证信息 | 系统核心实体 | 已有基线 | 已有基线 |
| E-BIZ-01 | learning_courses | 课程元数据 | 关联知识点、选课记录 | 待更新 | 已完成 |
| E-BIZ-02 | learning_knowledge_points | 知识点与前置依赖 | 自关联、关联课程 | 待更新 | 已完成 |
| E-BIZ-03 | learning_enrollments | 用户学习计划 | 用户、课程 | 待更新 | 已完成 |
| E-BIZ-04 | learning_records | 掌握度与时长 | 用户、知识点 | 待更新 | 已完成 |

## 可追溯证据

| 证据类型 | 存放位置 | 更新时机 |
| --- | --- | --- |
| 需求与用例 | `docs/engineering/` | 需求确认、范围变更时 |
| 架构与 ER 图 | `docs/diagrams/` | 模块、数据结构变化时 |
| 接口契约 | `API_CONTRACT.md` | 接口新增或修改时 |
| 自动化测试 | `backend/apps/*/tests/`、前端 lint 与构建 | 每次实现/修复时 |
| 测试结果与实验数据 | `docs/thesis/` 对应记录模板 | 测试执行后立即填写 |
| 代码演进 | Git commit/tag | 每个可验证里程碑 |
| 系统截图 | 【项目必填：约定目录】 | 页面稳定且脱敏后 |

## 里程碑状态

- [x] 题目、业务边界和目标确认
- [ ] 需求、角色、用例和非功能指标确认
- [ ] 系统架构、模块和数据库设计确认
- [x] 核心业务闭环实现
- [x] 自动化测试与接口契约测试通过
- [ ] 真实实验/测试数据采集完成
- [ ] 论文初稿、查重稿和终稿完成
- [ ] 答辩 PPT、演示脚本和应急材料完成
