# 前后端统一接口契约

本文是“知径”React 前端与 Django 后端之间的接口约定，字段和状态码以实际实现为准。

## 基础约定

- 开发环境后端端口：`8181`
- API 前缀：`/api`
- JSON 字段：`snake_case`
- 鉴权头：`Authorization: Bearer <access_token>`
- 分页参数：`page`（从 1 开始）、`page_size`
- HTTP 状态码与响应体 `code` 保持一致

## 统一响应

```json
{
  "code": 200,
  "msg": "success",
  "data": null
}
```

分页数据固定为：

```json
{
  "count": 1,
  "next": null,
  "previous": null,
  "results": []
}
```

## 用户接口

| 方法 | 路径 | 鉴权 | 说明 |
| --- | --- | --- | --- |
| POST | `/api/users/register/` | 否 | 注册，成功返回 201 |
| POST | `/api/users/login/` | 否 | 登录 |
| POST | `/api/users/token/refresh/` | 否 | 刷新 access token |
| POST | `/api/users/logout/` | 是 | 登出 |
| GET | `/api/users/profile/` | 是 | 获取个人信息 |
| PUT | `/api/users/profile/` | 是 | 更新邮箱、手机号 |
| POST | `/api/users/password/change/` | 是 | 修改密码 |
| GET | `/api/users/list/` | 管理员 | 分页用户列表 |

注册字段为 `username`、`email`、`phone`、`password`、`password_confirm`；修改密码字段为
`old_password`、`new_password`、`new_password_confirm`；刷新和登出请求字段为 `refresh`。

## 学习路径接口

| 方法 | 路径 | 鉴权 | 说明 |
| --- | --- | --- | --- |
| GET | `/api/learning/catalog/` | 否 | 获取已发布课程及知识点目录 |
| POST | `/api/learning/enrollments/` | 是 | 加入课程或更新每周学习计划 |
| POST | `/api/learning/progress/` | 是 | 新增或更新知识点掌握记录 |
| GET | `/api/learning/dashboard/` | 是 | 获取学习统计、记录和动态推荐路径 |

加入课程字段为 `course`、`weekly_minutes`、可选的 `target_date`；学习进度字段为
`knowledge_point`、`mastery_score`（0～100）、`duration_minutes` 和 `is_completed`。

推荐项包含 `score`、`reason` 及以下可解释分量：

- `knowledge_gap`：当前知识缺口；
- `prerequisite_readiness`：前置知识就绪度；
- `difficulty_fit`：用户能力与知识点难度匹配度；
- `peer_feedback`：其他学习者的平均掌握反馈。
