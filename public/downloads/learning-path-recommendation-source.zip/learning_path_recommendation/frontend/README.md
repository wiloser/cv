# 知径前端

React 前端，包含课程目录、用户认证和个人学习驾驶舱。

```bash
npm ci
npm run dev
```

开发地址为 `http://127.0.0.1:5174`，`/api` 默认代理到 Django 的 `8181` 端口。

```bash
npm run lint
npm run build
```
