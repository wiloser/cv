/**
 * 错误处理工具函数
 */

export function getErrorMessage(error, defaultMsg = '操作失败') {
  const errorData = error.response?.data
  
  // 1. 字段级错误（Django DRF 格式）
  if (errorData?.data && typeof errorData.data === 'object' && !Array.isArray(errorData.data)) {
    const firstField = Object.keys(errorData.data)[0]
    if (firstField) {
      const fieldErrors = errorData.data[firstField]
      if (Array.isArray(fieldErrors)) {
        return fieldErrors[0]
      }
      if (typeof fieldErrors === 'string') {
        return fieldErrors
      }
    }
  }
  
  // 2. Django 统一响应格式中的 msg
  if (errorData?.msg) {
    return errorData.msg
  }
  
  // 3. Detail 格式（用于非统一的网络层错误）
  if (errorData?.detail) {
    return errorData.detail
  }
  
  // 4. Network error
  if (error.message === 'Network Error') {
    return '网络连接失败，请检查网络'
  }
  
  // 5. Timeout
  if (error.code === 'ECONNABORTED') {
    return '请求超时，请稍后重试'
  }
  
  // 6. 默认消息
  return defaultMsg
}
