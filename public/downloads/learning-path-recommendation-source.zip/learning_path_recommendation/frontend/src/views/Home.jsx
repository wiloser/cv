import { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'
import Navbar from '../components/Navbar'
import { learningApi } from '../api/learning'
import { useUserStore } from '../stores/userStore'
import { getErrorMessage } from '../utils/errorHandler'

const difficultyNames = ['零基础', '入门', '基础', '进阶', '高级', '挑战']

export default function Home() {
  const navigate = useNavigate()
  const isAuthenticated = useUserStore((state) => state.isAuthenticated)
  const [courses, setCourses] = useState([])
  const [loading, setLoading] = useState(true)
  const [joiningId, setJoiningId] = useState(null)

  useEffect(() => {
    learningApi.getCatalog()
      .then((response) => setCourses(response.data || []))
      .catch((error) => toast.error(getErrorMessage(error, '课程目录加载失败')))
      .finally(() => setLoading(false))
  }, [])

  const joinCourse = async (courseId) => {
    if (!isAuthenticated) {
      navigate('/login')
      return
    }
    setJoiningId(courseId)
    try {
      const response = await learningApi.enroll({ course: courseId, weekly_minutes: 180 })
      toast.success(response.msg)
      navigate('/learning')
    } catch (error) {
      toast.error(getErrorMessage(error, '加入课程失败'))
    } finally {
      setJoiningId(null)
    }
  }

  return (
    <div className="min-h-screen bg-slate-50 text-ink">
      <Navbar />

      <header className="relative overflow-hidden bg-slate-950 text-white">
        <div className="absolute inset-0 opacity-30" style={{ backgroundImage: 'radial-gradient(circle at 75% 20%, #2563eb 0, transparent 35%), radial-gradient(circle at 20% 80%, #f59e0b 0, transparent 25%)' }} />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-28 grid md:grid-cols-2 gap-12 items-center">
          <div>
            <p className="text-amber-400 font-semibold tracking-widest text-sm mb-4">让每一步学习都有依据</p>
            <h1 className="text-4xl md:text-6xl font-black leading-tight mb-6">
              不是更多课程，<br />是更适合你的<span className="text-blue-400">下一步</span>
            </h1>
            <p className="text-lg text-slate-300 leading-relaxed max-w-xl mb-8">
              依据掌握度、前置知识、学习难度与群体反馈，动态生成可解释的个性化学习路径。
            </p>
            <div className="flex flex-wrap gap-4">
              <a href="#courses" className="bg-blue-600 hover:bg-blue-500 px-6 py-3 rounded-lg font-semibold transition-colors">浏览学习方向</a>
              {isAuthenticated ? (
                <Link to="/learning" className="border border-slate-600 hover:border-slate-400 px-6 py-3 rounded-lg font-semibold transition-colors">查看我的路径</Link>
              ) : (
                <Link to="/register" className="border border-slate-600 hover:border-slate-400 px-6 py-3 rounded-lg font-semibold transition-colors">免费开始</Link>
              )}
            </div>
          </div>
          <div className="bg-white/10 backdrop-blur border border-white/10 rounded-2xl p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-6">
              <div>
                <p className="text-xs text-slate-400 mb-1">推荐学习路径 · 示例</p>
                <h2 className="text-xl font-bold">数据分析能力进阶</h2>
              </div>
              <span className="bg-emerald-400/20 text-emerald-300 text-xs px-3 py-1 rounded-full">动态更新</span>
            </div>
            {['Python 基础语法', 'NumPy 数组计算', 'Pandas 数据清洗', '描述性统计'].map((item, index) => (
              <div key={item} className="flex gap-4">
                <div className="flex flex-col items-center">
                  <span className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${index === 0 ? 'bg-blue-500' : 'bg-slate-700'}`}>{index + 1}</span>
                  {index < 3 && <span className="w-px h-8 bg-slate-600" />}
                </div>
                <div className="pt-1">
                  <p className="font-medium">{item}</p>
                  <p className="text-xs text-slate-400">预计 {60 + index * 20} 分钟</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </header>

      <main id="courses" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-9">
          <div>
            <p className="text-blue-600 font-semibold text-sm mb-2">精选学习方向</p>
            <h2 className="text-3xl font-black text-slate-900">选择你想抵达的地方</h2>
          </div>
          <p className="text-gray-500 max-w-lg">加入课程后，系统会从固定目录转为基于个人学习行为的动态推荐。</p>
        </div>

        {loading ? (
          <div className="py-16 text-center text-gray-500">正在加载课程目录…</div>
        ) : courses.length === 0 ? (
          <div className="bg-white border border-dashed border-gray-300 rounded-xl p-10 text-center">
            <p className="font-semibold text-gray-700 mb-2">课程目录还没有数据</p>
            <p className="text-sm text-gray-500">后端执行 python manage.py seed_learning_demo 即可载入演示课程。</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {courses.map((course) => (
              <article key={course.id} className="bg-white border border-slate-200 rounded-2xl p-6 hover:-translate-y-1 hover:shadow-xl transition-all">
                <div className="flex items-start justify-between gap-3 mb-5">
                  <span className="text-xs font-semibold text-blue-700 bg-blue-50 px-3 py-1 rounded-full">{difficultyNames[course.difficulty]}</span>
                  <span className="text-sm text-gray-400">{Math.round(course.estimated_minutes / 60)} 小时</span>
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-3">{course.title}</h3>
                <p className="text-gray-600 text-sm leading-6 min-h-12 mb-5">{course.summary}</p>
                <div className="flex flex-wrap gap-2 mb-6">
                  {course.tags.map((tag) => <span key={tag} className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded">{tag}</span>)}
                </div>
                <div className="flex items-center justify-between pt-5 border-t border-slate-100">
                  <span className="text-sm text-gray-500">{course.knowledge_points.length} 个知识点</span>
                  <button
                    type="button"
                    onClick={() => joinCourse(course.id)}
                    disabled={joiningId === course.id}
                    className="text-blue-600 font-semibold hover:text-blue-800 disabled:opacity-50"
                  >
                    {joiningId === course.id ? '正在加入…' : '制定路径 →'}
                  </button>
                </div>
              </article>
            ))}
          </div>
        )}
      </main>
    </div>
  )
}
