import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { toast } from 'react-toastify'
import Navbar from '../../components/Navbar'
import { learningApi } from '../../api/learning'
import { getErrorMessage } from '../../utils/errorHandler'

const statCards = [
  ['course_count', '进行中课程', '门'],
  ['completed_count', '已掌握知识点', '个'],
  ['total_minutes', '累计学习', '分钟'],
  ['average_mastery', '平均掌握度', '%'],
]

export default function LearningDashboard() {
  const [dashboard, setDashboard] = useState(null)
  const [loading, setLoading] = useState(true)
  const [editing, setEditing] = useState(null)
  const [form, setForm] = useState({ mastery_score: 60, duration_minutes: 30, is_completed: false })

  const loadDashboard = async () => {
    try {
      const response = await learningApi.getDashboard()
      setDashboard(response.data)
    } catch (error) {
      toast.error(getErrorMessage(error, '学习数据加载失败'))
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    learningApi.getDashboard()
      .then((response) => setDashboard(response.data))
      .catch((error) => toast.error(getErrorMessage(error, '学习数据加载失败')))
      .finally(() => setLoading(false))
  }, [])

  const openProgress = (item) => {
    setEditing(item)
    setForm({ mastery_score: 60, duration_minutes: item.estimated_minutes, is_completed: false })
  }

  const saveProgress = async (event) => {
    event.preventDefault()
    try {
      await learningApi.updateProgress({ knowledge_point: editing.knowledge_point_id, ...form })
      toast.success('学习进度已保存，推荐路径已重新计算')
      setEditing(null)
      await loadDashboard()
    } catch (error) {
      toast.error(getErrorMessage(error, '保存学习进度失败'))
    }
  }

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900">
      <Navbar />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex flex-col md:flex-row justify-between md:items-end gap-4 mb-8">
          <div>
            <p className="text-blue-600 font-semibold text-sm mb-1">个人学习驾驶舱</p>
            <h1 className="text-3xl font-black">今天，从最合适的一步开始</h1>
          </div>
          <Link to="/#courses" className="text-sm font-semibold text-blue-600 hover:text-blue-800">+ 加入更多课程</Link>
        </div>

        {loading ? (
          <div className="py-24 text-center text-gray-500">正在计算你的学习路径…</div>
        ) : !dashboard ? (
          <div className="bg-white rounded-xl p-10 text-center text-gray-500">学习数据暂时不可用</div>
        ) : (
          <>
            <section className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              {statCards.map(([key, label, unit]) => (
                <div key={key} className="bg-white rounded-xl border border-slate-200 p-5">
                  <p className="text-sm text-gray-500 mb-2">{label}</p>
                  <p><span className="text-3xl font-black text-slate-900">{dashboard.stats[key]}</span> <span className="text-sm text-gray-400">{unit}</span></p>
                </div>
              ))}
            </section>

            {dashboard.enrollments.length === 0 ? (
              <section className="bg-white rounded-2xl border border-slate-200 p-12 text-center">
                <h2 className="text-2xl font-bold mb-3">先选择一个学习方向</h2>
                <p className="text-gray-500 mb-6">加入课程后，系统才能根据课程知识图谱生成推荐路径。</p>
                <Link to="/#courses" className="inline-block bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold">浏览课程</Link>
              </section>
            ) : (
              <div className="grid lg:grid-cols-3 gap-8">
                <section className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 overflow-hidden">
                  <div className="p-6 border-b border-slate-100 flex justify-between items-center">
                    <div>
                      <h2 className="text-xl font-bold">推荐下一步</h2>
                      <p className="text-sm text-gray-500 mt-1">混合评分已综合知识缺口、前置就绪度、难度与群体反馈</p>
                    </div>
                    <span className="text-xs text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full">可解释推荐</span>
                  </div>
                  <div className="divide-y divide-slate-100">
                    {dashboard.recommendations.map((item, index) => (
                      <div key={item.knowledge_point_id} className="p-6 flex gap-4">
                        <span className={`shrink-0 w-10 h-10 rounded-xl flex items-center justify-center font-black ${index === 0 ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-500'}`}>{index + 1}</span>
                        <div className="min-w-0 flex-1">
                          <div className="flex flex-wrap items-center gap-3 mb-1">
                            <h3 className="font-bold text-lg">{item.title}</h3>
                            <span className="text-xs text-gray-400">推荐度 {Math.round(item.score * 100)}</span>
                          </div>
                          <p className="text-sm text-gray-500 mb-3">{item.reason} · 预计 {item.estimated_minutes} 分钟</p>
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
                            {Object.entries(item.components).map(([name, value]) => (
                              <div key={name} className="bg-slate-50 px-2 py-1.5 rounded text-gray-500">
                                {({ knowledge_gap: '知识缺口', prerequisite_readiness: '前置就绪', difficulty_fit: '难度匹配', peer_feedback: '群体反馈' })[name]} {Math.round(value * 100)}
                              </div>
                            ))}
                          </div>
                        </div>
                        <button type="button" onClick={() => openProgress(item)} className="shrink-0 self-center bg-blue-50 text-blue-700 hover:bg-blue-100 px-4 py-2 rounded-lg text-sm font-semibold">记录学习</button>
                      </div>
                    ))}
                    {dashboard.recommendations.length === 0 && <p className="p-10 text-center text-gray-500">当前路径已完成，做得很好。</p>}
                  </div>
                </section>

                <aside className="space-y-6">
                  <section className="bg-slate-950 text-white rounded-2xl p-6">
                    <p className="text-xs text-blue-300 mb-2">本周计划</p>
                    <h2 className="text-xl font-bold mb-5">保持稳定节奏</h2>
                    {dashboard.enrollments.map((item) => (
                      <div key={item.id} className="border-t border-slate-800 py-4 first:border-0 first:pt-0">
                        <p className="font-medium mb-1">{item.course_title}</p>
                        <p className="text-sm text-slate-400">每周 {item.weekly_minutes} 分钟</p>
                      </div>
                    ))}
                  </section>
                  <section className="bg-white rounded-2xl border border-slate-200 p-6">
                    <h2 className="font-bold mb-4">最近学习记录</h2>
                    <div className="space-y-4">
                      {dashboard.recent_records.map((record) => (
                        <div key={record.id}>
                          <div className="flex justify-between text-sm mb-1">
                            <span className="truncate mr-3">{record.knowledge_point_title}</span>
                            <span className="font-semibold">{record.mastery_score}%</span>
                          </div>
                          <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden"><div className="h-full bg-blue-500" style={{ width: `${record.mastery_score}%` }} /></div>
                        </div>
                      ))}
                      {dashboard.recent_records.length === 0 && <p className="text-sm text-gray-500">完成一次学习后会在这里形成成长记录。</p>}
                    </div>
                  </section>
                </aside>
              </div>
            )}
          </>
        )}
      </main>

      {editing && (
        <div className="fixed inset-0 bg-slate-950/60 flex items-center justify-center p-4 z-50" onMouseDown={() => setEditing(null)}>
          <form onSubmit={saveProgress} onMouseDown={(event) => event.stopPropagation()} className="w-full max-w-md bg-white rounded-2xl p-6 shadow-2xl">
            <p className="text-sm text-blue-600 font-semibold mb-1">记录学习成果</p>
            <h2 className="text-2xl font-bold mb-6">{editing.title}</h2>
            <label className="block text-sm font-medium mb-2" htmlFor="mastery">自评掌握度：{form.mastery_score}%</label>
            <input id="mastery" type="range" min="0" max="100" step="5" value={form.mastery_score} onChange={(event) => setForm({ ...form, mastery_score: Number(event.target.value) })} className="w-full accent-blue-600 mb-5" />
            <label className="block text-sm font-medium mb-2" htmlFor="duration">本次学习时长（分钟）</label>
            <input id="duration" type="number" min="0" max="1440" value={form.duration_minutes} onChange={(event) => setForm({ ...form, duration_minutes: Number(event.target.value) })} className="w-full border border-slate-300 rounded-lg px-3 py-2 mb-5 focus:outline-none focus:ring-2 focus:ring-blue-500" />
            <label className="flex gap-2 items-center text-sm mb-6">
              <input type="checkbox" checked={form.is_completed} onChange={(event) => setForm({ ...form, is_completed: event.target.checked })} className="accent-blue-600" />
              已完成该知识点
            </label>
            <div className="flex gap-3 justify-end">
              <button type="button" onClick={() => setEditing(null)} className="px-4 py-2 text-gray-600">取消</button>
              <button type="submit" className="bg-blue-600 text-white px-5 py-2 rounded-lg font-semibold">保存并重算路径</button>
            </div>
          </form>
        </div>
      )}
    </div>
  )
}
