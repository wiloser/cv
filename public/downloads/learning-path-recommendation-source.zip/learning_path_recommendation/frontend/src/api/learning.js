import api from './index'

export const learningApi = {
  getCatalog: () => api.get('/api/learning/catalog/'),
  getDashboard: () => api.get('/api/learning/dashboard/'),
  enroll: (data) => api.post('/api/learning/enrollments/', data),
  updateProgress: (data) => api.post('/api/learning/progress/', data),
}
