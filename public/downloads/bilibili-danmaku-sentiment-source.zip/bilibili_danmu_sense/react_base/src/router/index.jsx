import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom'
import { useUserStore } from '../stores/userStore'

// 公共页面
import Login from '../views/auth/Login'
import Register from '../views/auth/Register'
import Home from '../views/Home'

// 用户页面
import Profile from '../views/user/Profile'
import ChangePassword from '../views/user/ChangePassword'

// 管理页面
import UserList from '../views/admin/UserList'

// B站弹幕分析页面
import AnalysisSubmit from '../views/bilibili/AnalysisSubmit'
import AnalysisDetail from '../views/bilibili/AnalysisDetail'
import AnalysisHistory from '../views/bilibili/AnalysisHistory'
import HotVideos from '../views/bilibili/HotVideos'
import SentimentCompare from '../views/bilibili/SentimentCompare'

// 404
import NotFound from '../views/NotFound'

// 受保护的路由
function ProtectedRoute({ children, adminOnly = false }) {
  const location = useLocation()
  const isAuthenticated = useUserStore((state) => state.isAuthenticated)
  const isAdmin = useUserStore((state) => state.user?.role === 'admin')
  
  if (!isAuthenticated) {
    const redirect = encodeURIComponent(location.pathname + location.search)
    return <Navigate to={`/login?redirect=${redirect}`} replace />
  }
  
  if (adminOnly && !isAdmin) {
    return <Navigate to="/" replace />
  }
  
  return children
}

export default function AppRouter() {
  return (
    <BrowserRouter basename={import.meta.env.BASE_URL}>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        
        <Route
          path="/profile"
          element={
            <ProtectedRoute>
              <Profile />
            </ProtectedRoute>
          }
        />
        <Route
          path="/change-password"
          element={
            <ProtectedRoute>
              <ChangePassword />
            </ProtectedRoute>
          }
        />
        <Route
          path="/admin/users"
          element={
            <ProtectedRoute adminOnly>
              <UserList />
            </ProtectedRoute>
          }
        />
        
        {/* B站弹幕分析路由 */}
        <Route
          path="/bilibili/analyze"
          element={
            <ProtectedRoute>
              <AnalysisSubmit />
            </ProtectedRoute>
          }
        />
        <Route
          path="/bilibili/analysis/:id"
          element={
            <ProtectedRoute>
              <AnalysisDetail />
            </ProtectedRoute>
          }
        />
        <Route
          path="/bilibili/history"
          element={
            <ProtectedRoute>
              <AnalysisHistory />
            </ProtectedRoute>
          }
        />
        <Route
          path="/bilibili/hot"
          element={<HotVideos />}
        />
        <Route
          path="/bilibili/compare"
          element={
            <ProtectedRoute>
              <SentimentCompare />
            </ProtectedRoute>
          }
        />
        
        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  )
}
