import { Link } from 'react-router-dom'
import { useUserStore } from '../stores/userStore'
import Navbar from '../components/Navbar'

export default function Home() {
  const { isAuthenticated } = useUserStore()

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-white to-blue-50">
      <Navbar />

      {/* Hero 区域 */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-12">
        <div className="text-center">
          <div className="flex justify-center mb-6">
            <span className="text-6xl">📺</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            B站弹幕情感分析系统
          </h1>
          <p className="text-xl text-gray-500 mb-10 max-w-2xl mx-auto">
            输入任意 B站视频链接，自动爬取弹幕内容，结合 AI 情感分析引擎，
            生成直观的情感分布、关键词云、时间轴等可视化报告。
          </p>

          <div className="flex justify-center gap-4 flex-wrap">
            {isAuthenticated ? (
              <Link
                to="/bilibili/analyze"
                className="bg-pink-500 text-white px-8 py-3 rounded-lg text-lg font-semibold hover:bg-pink-600 transition-colors shadow-md"
              >
                开始分析
              </Link>
            ) : (
              <>
                <Link
                  to="/register"
                  className="bg-pink-500 text-white px-8 py-3 rounded-lg text-lg font-semibold hover:bg-pink-600 transition-colors shadow-md"
                >
                  免费注册
                </Link>
                <Link
                  to="/login"
                  className="bg-white text-pink-500 px-8 py-3 rounded-lg text-lg font-semibold border-2 border-pink-400 hover:bg-pink-50 transition-colors"
                >
                  立即登录
                </Link>
              </>
            )}
            <Link
              to="/bilibili/hot"
              className="bg-white text-gray-700 px-8 py-3 rounded-lg text-lg font-semibold border border-gray-300 hover:bg-gray-50 transition-colors"
            >
              热门视频榜
            </Link>
          </div>
        </div>
      </div>

      {/* 核心功能卡片 */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h2 className="text-2xl font-bold text-center text-gray-800 mb-10">核心功能</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Link to="/bilibili/analyze" className="block group">
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-lg hover:border-pink-200 transition-all h-full">
              <div className="text-4xl mb-4">🔍</div>
              <h3 className="text-lg font-semibold text-gray-800 mb-2">弹幕爬取分析</h3>
              <p className="text-gray-500 text-sm">
                粘贴视频链接，一键自动爬取全量弹幕，支持最多 3000 条数据处理
              </p>
            </div>
          </Link>

          <Link to={isAuthenticated ? "/bilibili/analyze" : "/login"} className="block group">
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-lg hover:border-blue-200 transition-all h-full">
              <div className="text-4xl mb-4">🤖</div>
              <h3 className="text-lg font-semibold text-gray-800 mb-2">双引擎情感分析</h3>
              <p className="text-gray-500 text-sm">
                支持百度 AI 云端接口与 SnowNLP 本地模型双引擎，自动降级切换
              </p>
            </div>
          </Link>

          <Link to="/bilibili/history" className="block group">
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-lg hover:border-green-200 transition-all h-full">
              <div className="text-4xl mb-4">📊</div>
              <h3 className="text-lg font-semibold text-gray-800 mb-2">可视化报告</h3>
              <p className="text-gray-500 text-sm">
                生成情感分布饼图、关键词热力榜、弹幕时间轴等多维可视化图表
              </p>
            </div>
          </Link>

          <Link to="/bilibili/compare" className="block group">
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-lg hover:border-purple-200 transition-all h-full">
              <div className="text-4xl mb-4">⚡</div>
              <h3 className="text-lg font-semibold text-gray-800 mb-2">多视频对比</h3>
              <p className="text-gray-500 text-sm">
                选择多个视频分析结果横向对比，洞察不同视频的观众情绪差异
              </p>
            </div>
          </Link>
        </div>
      </div>

      {/* 使用流程 */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h2 className="text-2xl font-bold text-center text-gray-800 mb-10">三步完成分析</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="w-12 h-12 bg-pink-100 text-pink-600 rounded-full flex items-center justify-center text-xl font-bold mx-auto mb-4">1</div>
            <h3 className="font-semibold text-gray-800 mb-2">粘贴视频链接</h3>
            <p className="text-gray-500 text-sm">将 B站视频 URL 粘贴到输入框，支持标准链接和短链格式</p>
          </div>
          <div className="text-center">
            <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-xl font-bold mx-auto mb-4">2</div>
            <h3 className="font-semibold text-gray-800 mb-2">选择分析引擎</h3>
            <p className="text-gray-500 text-sm">选择百度云 API 或本地 SnowNLP 模型，提交后台异步处理</p>
          </div>
          <div className="text-center">
            <div className="w-12 h-12 bg-green-100 text-green-600 rounded-full flex items-center justify-center text-xl font-bold mx-auto mb-4">3</div>
            <h3 className="font-semibold text-gray-800 mb-2">查看分析报告</h3>
            <p className="text-gray-500 text-sm">分析完成后自动跳转报告页，查看情感分布、关键词、时间轴数据</p>
          </div>
        </div>
      </div>

      {/* 快捷入口（已登录） */}
      {isAuthenticated && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="bg-gradient-to-r from-pink-500 to-indigo-500 rounded-2xl p-8 text-white text-center">
            <h3 className="text-2xl font-bold mb-2">准备好了吗？</h3>
            <p className="text-pink-100 mb-6">立即提交一个 B站视频，体验 AI 弹幕情感分析</p>
            <div className="flex justify-center gap-4 flex-wrap">
              <Link
                to="/bilibili/analyze"
                className="bg-white text-pink-600 px-6 py-3 rounded-lg font-semibold hover:bg-pink-50 transition-colors"
              >
                提交分析任务
              </Link>
              <Link
                to="/bilibili/history"
                className="bg-white/20 text-white px-6 py-3 rounded-lg font-semibold hover:bg-white/30 transition-colors border border-white/40"
              >
                我的分析历史
              </Link>
              <Link
                to="/bilibili/compare"
                className="bg-white/20 text-white px-6 py-3 rounded-lg font-semibold hover:bg-white/30 transition-colors border border-white/40"
              >
                情感对比分析
              </Link>
            </div>
          </div>
        </div>
      )}

      {/* 底部 */}
      <footer className="text-center text-gray-400 text-sm py-10 mt-4">
        B站弹幕情感分析系统 · 基于 React + Django REST Framework 构建
      </footer>
    </div>
  )
}
