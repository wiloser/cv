import { useState } from 'react'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import { toast } from 'react-toastify'
import { useUserStore } from '../../stores/userStore'
import { getErrorMessage } from '../../utils/errorHandler'

export default function Login() {
  const navigate = useNavigate()
  const location = useLocation()
  const login = useUserStore((state) => state.login)

  const [form, setForm] = useState({ username: '', password: '' })
  const [errors, setErrors] = useState({})
  const [loading, setLoading] = useState(false)

  const redirect = new URLSearchParams(location.search).get('redirect') || '/'

  const handleSubmit = async (e) => {
    e.preventDefault()
    setErrors({})

    if (!form.username) {
      setErrors({ username: '请输入用户名' })
      return
    }
    if (!form.password) {
      setErrors({ password: '请输入密码' })
      return
    }

    setLoading(true)
    try {
      const result = await login(form)
      if (result.success) {
        toast.success('登录成功！')
        setTimeout(() => navigate(redirect), 500)
      } else {
        toast.error(result.message || '登录失败')
      }
    } catch (error) {
      toast.error(getErrorMessage(error, '登录失败，请稍后重试'))
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900">登录账号</h2>
          <p className="mt-2 text-sm text-gray-600">
            还没有账号？
            <Link to="/register" className="text-pink-500 hover:text-pink-600 hover:underline cursor-pointer">
              立即注册
            </Link>
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="username" className="block text-sm font-medium text-gray-700 mb-2">
                用户名
              </label>
              <input
                id="username"
                type="text"
                value={form.username}
                onChange={(e) => setForm({ ...form, username: e.target.value })}
                disabled={loading}
                placeholder="请输入用户名"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-300 focus:border-pink-400 transition-all"
              />
              {errors.username && <p className="text-red-600 text-sm mt-1">{errors.username}</p>}
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-2">
                密码
              </label>
              <input
                id="password"
                type="password"
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
                disabled={loading}
                placeholder="请输入密码"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-300 focus:border-pink-400 transition-all"
              />
              {errors.password && <p className="text-red-600 text-sm mt-1">{errors.password}</p>}
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-pink-500 text-white py-2 px-4 rounded-lg hover:bg-pink-600 focus:outline-none focus:ring-2 focus:ring-pink-300 focus:ring-offset-2 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? '登录中...' : '登录'}
            </button>
          </form>
        </div>
      </div>
    </div>
  )
}
