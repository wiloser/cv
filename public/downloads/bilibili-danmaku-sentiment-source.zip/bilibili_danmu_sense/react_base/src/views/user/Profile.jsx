import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { toast } from 'react-toastify'
import { useUserStore } from '../../stores/userStore'
import { validateEmail, validatePhone, formatDateTime } from '../../utils/helpers'
import { getErrorMessage } from '../../utils/errorHandler'
import Navbar from '../../components/Navbar'

export default function Profile() {
  const { fetchProfile, updateProfile } = useUserStore()

  const [profileForm, setProfileForm] = useState({
    username: '',
    email: '',
    phone: '',
    role: '',
    created_at: '',
  })
  const [errors, setErrors] = useState({})
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    const loadProfile = async () => {
      const result = await fetchProfile()
      
      if (result.success && result.data) {
        const user = result.data
        setProfileForm({
          username: user.username,
          email: user.email || '',
          phone: user.phone || '',
          role: user.role === 'admin' ? '管理员' : '普通用户',
          created_at: formatDateTime(user.created_at || user.date_joined),
        })
      }
    }
    
    loadProfile()
  }, [fetchProfile])

  const handleSubmit = async (e) => {
    e.preventDefault()
    setErrors({})

    if (profileForm.email && !validateEmail(profileForm.email)) {
      setErrors({ email: '邮箱格式不正确' })
      return
    }

    if (profileForm.phone && !validatePhone(profileForm.phone)) {
      setErrors({ phone: '手机号格式不正确' })
      return
    }

    setLoading(true)
    try {
      const result = await updateProfile({
        email: profileForm.email,
        phone: profileForm.phone,
      })

      if (result.success) {
        toast.success(result.message || '个人信息更新成功')
      } else {
        toast.error(result.message || '更新失败')
      }
    } catch (error) {
      toast.error(getErrorMessage(error, '更新失败，请稍后重试'))
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="max-w-2xl mx-auto">
          <h1 className="text-3xl font-bold text-gray-900 mb-8">个人信息</h1>

          <div className="bg-white rounded-lg shadow-md p-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  用户名
                </label>
                <input
                  value={profileForm.username}
                  type="text"
                  disabled
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-100"
                />
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                  邮箱
                </label>
                <input
                  id="email"
                  value={profileForm.email}
                  onChange={(e) => setProfileForm({ ...profileForm, email: e.target.value })}
                  disabled={loading}
                  placeholder="请输入邮箱"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-300 focus:border-pink-400 transition-all"
                />
                {errors.email && <p className="text-red-600 text-sm mt-1">{errors.email}</p>}
              </div>

              <div>
                <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-2">
                  手机号
                </label>
                <input
                  id="phone"
                  value={profileForm.phone}
                  onChange={(e) => setProfileForm({ ...profileForm, phone: e.target.value })}
                  disabled={loading}
                  placeholder="请输入手机号"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-300 focus:border-pink-400 transition-all"
                />
                {errors.phone && <p className="text-red-600 text-sm mt-1">{errors.phone}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  角色
                </label>
                <input
                  value={profileForm.role}
                  type="text"
                  disabled
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-100"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  注册时间
                </label>
                <input
                  value={profileForm.created_at}
                  type="text"
                  disabled
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-100"
                />
              </div>

              <div className="flex space-x-4">
                <button
                  type="submit"
                  disabled={loading}
                  className="flex-1 bg-pink-500 text-white py-2 px-4 rounded-lg hover:bg-pink-600 focus:outline-none focus:ring-2 focus:ring-pink-300 focus:ring-offset-2 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {loading ? '保存中...' : '保存修改'}
                </button>
                <Link
                  to="/change-password"
                  className="flex-1 bg-gray-600 text-white py-2 px-4 rounded-lg hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors text-center"
                >
                  修改密码
                </Link>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  )
}
