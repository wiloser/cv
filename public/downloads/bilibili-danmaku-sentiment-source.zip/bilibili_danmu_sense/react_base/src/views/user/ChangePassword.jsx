import { useState } from 'react'
import { Link } from 'react-router-dom'
import { toast } from 'react-toastify'
import { useUserStore } from '../../stores/userStore'
import { validatePassword } from '../../utils/helpers'
import { getErrorMessage } from '../../utils/errorHandler'
import Navbar from '../../components/Navbar'

export default function ChangePassword() {
  const { changePassword } = useUserStore()

  const [form, setForm] = useState({
    old_password: '',
    new_password: '',
    new_password_confirm: '',
  })
  const [errors, setErrors] = useState({})
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    setErrors({})

    if (!form.old_password) {
      setErrors({ old_password: '请输入旧密码' })
      return
    }

    const passwordValidation = validatePassword(form.new_password)
    if (!passwordValidation.valid) {
      setErrors({ new_password: passwordValidation.message })
      return
    }

    if (form.new_password !== form.new_password_confirm) {
      setErrors({ new_password_confirm: '两次输入的密码不一致' })
      return
    }

    setLoading(true)
    try {
      const result = await changePassword(form)

      if (result.success) {
        toast.success(result.message || '密码修改成功')
        setForm({
          old_password: '',
          new_password: '',
          new_password_confirm: '',
        })
      } else {
        toast.error(result.message || '密码修改失败')
      }
    } catch (error) {
      toast.error(getErrorMessage(error, '修改失败，请稍后重试'))
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="max-w-2xl mx-auto">
          <h1 className="text-3xl font-bold text-gray-900 mb-8">修改密码</h1>

          <div className="bg-white rounded-lg shadow-md p-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="oldPassword" className="block text-sm font-medium text-gray-700 mb-2">
                  旧密码
                </label>
                <input
                  id="oldPassword"
                  type="password"
                  value={form.old_password}
                  onChange={(e) => setForm({ ...form, old_password: e.target.value })}
                  disabled={loading}
                  placeholder="请输入旧密码"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-300 focus:border-pink-400 transition-all"
                />
                {errors.old_password && <p className="text-red-600 text-sm mt-1">{errors.old_password}</p>}
              </div>

              <div>
                <label htmlFor="newPassword" className="block text-sm font-medium text-gray-700 mb-2">
                  新密码
                </label>
                <input
                  id="newPassword"
                  type="password"
                  value={form.new_password}
                  onChange={(e) => setForm({ ...form, new_password: e.target.value })}
                  disabled={loading}
                  placeholder="请输入新密码（至少8位，包含大小写字母和数字）"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-300 focus:border-pink-400 transition-all"
                />
                {errors.new_password && <p className="text-red-600 text-sm mt-1">{errors.new_password}</p>}
              </div>

              <div>
                <label htmlFor="newPasswordConfirm" className="block text-sm font-medium text-gray-700 mb-2">
                  确认新密码
                </label>
                <input
                  id="newPasswordConfirm"
                  type="password"
                  value={form.new_password_confirm}
                  onChange={(e) => setForm({ ...form, new_password_confirm: e.target.value })}
                  disabled={loading}
                  placeholder="请再次输入新密码"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-300 focus:border-pink-400 transition-all"
                />
                {errors.new_password_confirm && <p className="text-red-600 text-sm mt-1">{errors.new_password_confirm}</p>}
              </div>

              <div className="flex space-x-4">
                <button
                  type="submit"
                  disabled={loading}
                  className="flex-1 bg-pink-500 text-white py-2 px-4 rounded-lg hover:bg-pink-600 focus:outline-none focus:ring-2 focus:ring-pink-300 focus:ring-offset-2 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {loading ? '修改中...' : '修改密码'}
                </button>
                <Link
                  to="/profile"
                  className="flex-1 bg-gray-600 text-white py-2 px-4 rounded-lg hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors text-center"
                >
                  返回个人信息
                </Link>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  )
}
