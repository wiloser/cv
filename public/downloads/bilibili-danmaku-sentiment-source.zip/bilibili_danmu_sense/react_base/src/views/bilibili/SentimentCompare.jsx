import { useCallback, useEffect, useState } from 'react'
import { toast } from 'react-toastify'
import ReactECharts from 'echarts-for-react'
import { bilibiliApi } from '../../api/bilibili'
import Navbar from '../../components/Navbar'

export default function SentimentCompare() {
  const [analyses, setAnalyses] = useState([])
  const [selected, setSelected] = useState([])
  const [compareData, setCompareData] = useState([])
  const [loading, setLoading] = useState(false)

  const fetchAnalyses = useCallback(async () => {
    try {
      const response = await bilibiliApi.getAnalysisList({ page: 1 })
      if (response.code === 200) {
        setAnalyses(response.data.results || response.data || [])
      }
    } catch (error) {
      console.error('获取分析列表失败:', error)
      toast.error('获取分析列表失败')
    }
  }, [])

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect -- initial remote data load
    void fetchAnalyses()
  }, [fetchAnalyses])

  const handleSelect = (id) => {
    if (selected.includes(id)) {
      setSelected(selected.filter(i => i !== id))
    } else {
      if (selected.length >= 5) {
        toast.warning('最多选择5个视频进行对比')
        return
      }
      setSelected([...selected, id])
    }
  }

  const handleCompare = async () => {
    if (selected.length < 2) {
      toast.warning('请至少选择2个视频进行对比')
      return
    }

    setLoading(true)
    try {
      const data = await Promise.all(
        selected.map(id => bilibiliApi.getAnalysisDetail(id))
      )
      
      setCompareData(data.map(res => res.data))
    } catch {
      toast.error('获取对比数据失败')
    } finally {
      setLoading(false)
    }
  }

  const getCompareChartOption = () => {
    if (compareData.length === 0) return {}

    return {
      title: {
        text: '情感对比分析',
        left: 'center',
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow',
        },
      },
      legend: {
        data: ['正面', '负面', '中性'],
        top: 30,
      },
      xAxis: {
        type: 'category',
        data: compareData.map(d => d.video_title?.substring(0, 15) + '...'),
        axisLabel: {
          rotate: 30,
        },
      },
      yAxis: {
        type: 'value',
        name: '弹幕数',
      },
      series: [
        {
          name: '正面',
          type: 'bar',
          stack: 'total',
          data: compareData.map(d => d.positive_count),
          itemStyle: { color: '#52c41a' },
        },
        {
          name: '负面',
          type: 'bar',
          stack: 'total',
          data: compareData.map(d => d.negative_count),
          itemStyle: { color: '#ff4d4f' },
        },
        {
          name: '中性',
          type: 'bar',
          stack: 'total',
          data: compareData.map(d => d.neutral_count),
          itemStyle: { color: '#faad14' },
        },
      ],
    }
  }

  const getScoreChartOption = () => {
    if (compareData.length === 0) return {}

    return {
      title: {
        text: '平均情感得分对比',
        left: 'center',
      },
      tooltip: {
        trigger: 'axis',
      },
      xAxis: {
        type: 'category',
        data: compareData.map(d => d.video_title?.substring(0, 15) + '...'),
        axisLabel: {
          rotate: 30,
        },
      },
      yAxis: {
        type: 'value',
        min: -1,
        max: 1,
      },
      series: [
        {
          name: '平均情感得分',
          type: 'bar',
          data: compareData.map(d => ({
            value: d.avg_sentiment_score,
            itemStyle: {
              color: d.avg_sentiment_score > 0.1 ? '#52c41a' :
                     d.avg_sentiment_score < -0.1 ? '#ff4d4f' : '#faad14',
            },
          })),
        },
      ],
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="max-w-5xl mx-auto px-4 py-10">
        <div className="flex items-center gap-3 mb-8">
          <span className="text-3xl">📊</span>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">情感对比分析</h1>
            <p className="text-sm text-gray-500 mt-1">选择多个视频进行情感对比</p>
          </div>
        </div>

        {/* 选择区域 */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 mb-6">
          <h3 className="font-semibold text-gray-800 mb-4">
            选择要对比的视频
            <span className="text-sm text-gray-400 font-normal ml-2">（最多5个，已选{selected.length}个）</span>
          </h3>

          {analyses.length === 0 ? (
            <p className="text-gray-400 py-4">暂无分析记录，请先进行视频分析</p>
          ) : (
            <div className="flex flex-col gap-2 mb-5">
              {analyses.slice(0, 10).map(analysis => (
                <div
                  key={analysis.id}
                  onClick={() => handleSelect(analysis.id)}
                  className={`p-3 rounded-lg border-2 cursor-pointer transition-all ${
                    selected.includes(analysis.id)
                      ? 'border-pink-400 bg-pink-50'
                      : 'border-transparent bg-gray-50 hover:bg-gray-100'
                  }`}
                >
                  <div className="font-medium text-gray-800 truncate">{analysis.video_title}</div>
                  <div className="text-xs text-gray-400 mt-1">
                    弹幕：{analysis.total_danmaku} | 情感：{analysis.avg_sentiment_score.toFixed(2)}
                  </div>
                </div>
              ))}
            </div>
          )}

          <button
            onClick={handleCompare}
            disabled={loading || selected.length < 2}
            className="px-6 py-2 bg-pink-500 text-white rounded-lg hover:bg-pink-600 transition-colors disabled:opacity-40 disabled:cursor-not-allowed text-sm font-medium"
          >
            {loading ? '加载中...' : '开始对比'}
          </button>
        </div>

        {/* 对比结果 */}
        {compareData.length > 0 && (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
                <ReactECharts option={getCompareChartOption()} style={{ height: '380px' }} />
              </div>
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
                <ReactECharts option={getScoreChartOption()} style={{ height: '380px' }} />
              </div>
            </div>

            {/* 详细数据表格 */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
              <h3 className="font-semibold text-gray-800 mb-4">详细数据对比</h3>
              <div className="overflow-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-gray-50">
                      <th className="px-4 py-3 text-left text-gray-500 font-medium border-b border-gray-200">视频标题</th>
                      <th className="px-4 py-3 text-center text-gray-500 font-medium border-b border-gray-200">弹幕总数</th>
                      <th className="px-4 py-3 text-center text-gray-500 font-medium border-b border-gray-200">正面</th>
                      <th className="px-4 py-3 text-center text-gray-500 font-medium border-b border-gray-200">负面</th>
                      <th className="px-4 py-3 text-center text-gray-500 font-medium border-b border-gray-200">中性</th>
                      <th className="px-4 py-3 text-center text-gray-500 font-medium border-b border-gray-200">平均情感</th>
                    </tr>
                  </thead>
                  <tbody>
                    {compareData.map(d => (
                      <tr key={d.id} className="hover:bg-gray-50 transition-colors">
                        <td className="px-4 py-3 border-b border-gray-100 text-gray-700">{d.video_title}</td>
                        <td className="px-4 py-3 border-b border-gray-100 text-center text-gray-700">{d.total_danmaku}</td>
                        <td className="px-4 py-3 border-b border-gray-100 text-center text-green-500 font-medium">{d.positive_count}</td>
                        <td className="px-4 py-3 border-b border-gray-100 text-center text-red-500 font-medium">{d.negative_count}</td>
                        <td className="px-4 py-3 border-b border-gray-100 text-center text-yellow-500 font-medium">{d.neutral_count}</td>
                        <td className={`px-4 py-3 border-b border-gray-100 text-center font-bold ${
                          d.avg_sentiment_score > 0.1 ? 'text-green-500' :
                          d.avg_sentiment_score < -0.1 ? 'text-red-500' : 'text-yellow-500'
                        }`}>
                          {d.avg_sentiment_score.toFixed(2)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  )
}
