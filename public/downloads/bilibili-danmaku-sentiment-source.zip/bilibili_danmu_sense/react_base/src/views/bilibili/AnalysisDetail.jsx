import { useCallback, useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'
import ReactECharts from 'echarts-for-react'
import 'echarts-wordcloud'
import { bilibiliApi } from '../../api/bilibili'
import Navbar from '../../components/Navbar'

export default function AnalysisDetail() {
  const { id } = useParams()
  const navigate = useNavigate()
  const [loading, setLoading] = useState(true)
  const [detail, setDetail] = useState(null)
  const [keywords, setKeywords] = useState([])
  const [timeline, setTimeline] = useState([])

  const fetchData = useCallback(async () => {
    try {
      const [detailRes, keywordsRes, timelineRes] = await Promise.all([
        bilibiliApi.getAnalysisDetail(id),
        bilibiliApi.getKeywords(id),
        bilibiliApi.getTimeline(id),
      ])

      if (detailRes.code === 200) {
        setDetail(detailRes.data)
      }
      if (keywordsRes.code === 200) {
        setKeywords(keywordsRes.data || [])
      }
      if (timelineRes.code === 200) {
        setTimeline(timelineRes.data || [])
      }
    } catch (error) {
      console.error('获取数据失败:', error)
      toast.error('获取数据失败')
    } finally {
      setLoading(false)
    }
  }, [id])

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect -- reload remote analysis when the route id changes
    void fetchData()
  }, [fetchData])

  const formatDate = (dateStr) => {
    return new Date(dateStr).toLocaleString('zh-CN')
  }

  // 情感分布饼图配置
  const getPieOption = () => {
    if (!detail) return {}
    
    return {
      title: {
        text: '情感分布',
        left: 'center',
      },
      tooltip: {
        trigger: 'item',
        formatter: '{b}: {c} ({d}%)',
      },
      legend: {
        orient: 'vertical',
        left: 'left',
      },
      series: [
        {
          name: '情感分布',
          type: 'pie',
          radius: '50%',
          data: [
            { value: detail.positive_count, name: '正面', itemStyle: { color: '#52c41a' } },
            { value: detail.negative_count, name: '负面', itemStyle: { color: '#ff4d4f' } },
            { value: detail.neutral_count, name: '中性', itemStyle: { color: '#faad14' } },
          ],
          emphasis: {
            itemStyle: {
              shadowBlur: 10,
              shadowOffsetX: 0,
              shadowColor: 'rgba(0, 0, 0, 0.5)',
            },
          },
        },
      ],
    }
  }

  // 词云配置
  const getWordCloudOption = () => {
    if (keywords.length === 0) return {}

    return {
      title: {
        text: '关键词词云',
        left: 'center',
      },
      tooltip: {
        show: true,
        formatter: (params) => {
          return `${params.name}<br/>频次: ${params.value}<br/>情感: ${params.data.sentiment?.toFixed(2)}`
        },
      },
      series: [
        {
          type: 'wordCloud',
          gridSize: 10,
          sizeRange: [12, 50],
          rotationRange: [-90, 90],
          shape: 'circle',
          width: '100%',
          height: '100%',
          textStyle: {
            color: function () {
              const colors = ['#00a1d6', '#52c41a', '#ff4d4f', '#faad14', '#722ed1']
              return colors[Math.floor(Math.random() * colors.length)]
            },
          },
          data: keywords.slice(0, 30).map(k => ({
            name: k.keyword,
            value: k.frequency,
            sentiment: k.avg_sentiment,
          })),
        },
      ],
    }
  }

  // 时间趋势图配置
  const getTimelineOption = () => {
    if (timeline.length === 0) return {}

    const times = timeline.map(t => `${Math.floor(t.start_time / 60)}:${String(Math.floor(t.start_time % 60)).padStart(2, '0')}`)
    const counts = timeline.map(t => t.danmaku_count)
    const sentiments = timeline.map(t => t.avg_sentiment)

    return {
      title: {
        text: '时间趋势分析',
        left: 'center',
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'cross',
        },
      },
      legend: {
        data: ['弹幕密度', '情感得分'],
        top: 30,
      },
      xAxis: {
        type: 'category',
        data: times,
        axisLabel: {
          rotate: 45,
        },
      },
      yAxis: [
        {
          type: 'value',
          name: '弹幕数',
          position: 'left',
        },
        {
          type: 'value',
          name: '情感得分',
          min: -1,
          max: 1,
          position: 'right',
        },
      ],
      series: [
        {
          name: '弹幕密度',
          type: 'bar',
          data: counts,
          itemStyle: { color: '#00a1d6' },
        },
        {
          name: '情感得分',
          type: 'line',
          yAxisIndex: 1,
          data: sentiments,
          smooth: true,
          itemStyle: { color: '#ff4d4f' },
        },
      ],
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="flex items-center justify-center py-32">
          <div className="text-gray-400 text-lg">加载中...</div>
        </div>
      </div>
    )
  }

  if (!detail) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="flex items-center justify-center py-32">
          <div className="text-gray-400 text-lg">数据加载失败</div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="max-w-6xl mx-auto px-4 py-10">
        {/* 返回按钮 */}
        <button
          onClick={() => navigate('/bilibili/history')}
          className="flex items-center gap-1 text-sm text-gray-500 hover:text-pink-500 transition-colors mb-6"
        >
          ← 返回列表
        </button>

        {/* 视频信息卡片 */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 mb-6">
          <h2 className="text-xl font-bold text-gray-800 mb-3">{detail.video_title}</h2>
          <div className="flex flex-wrap gap-4 text-sm text-gray-500">
            <span>UP主：{detail.uploader}</span>
            <span>弹幕数：{detail.total_danmaku}</span>
            <span>分析引擎：{detail.analysis_engine === 'api' ? '百度AI' : '本地模型'}</span>
            <span>分析时间：{formatDate(detail.created_at)}</span>
          </div>
          <a
            href={detail.video_url}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block mt-3 text-sm text-pink-500 hover:text-pink-600 hover:underline"
          >
            查看原视频 →
          </a>
        </div>

        {/* 图表区域 */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
            <ReactECharts option={getPieOption()} style={{ height: '380px' }} />
          </div>
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
            <ReactECharts option={getWordCloudOption()} style={{ height: '380px' }} />
          </div>
        </div>

        {/* 时间趋势图 */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5 mb-6">
          <ReactECharts option={getTimelineOption()} style={{ height: '380px' }} />
        </div>

        {/* 弹幕列表 */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
          <h3 className="font-semibold text-gray-800 mb-4">弹幕数据（前100条）</h3>
          <div className="overflow-auto max-h-96">
            <table className="w-full text-sm">
              <thead className="sticky top-0 bg-gray-50">
                <tr>
                  <th className="px-3 py-2 text-left text-gray-500 font-medium border-b border-gray-200">时间</th>
                  <th className="px-3 py-2 text-left text-gray-500 font-medium border-b border-gray-200">弹幕内容</th>
                  <th className="px-3 py-2 text-center text-gray-500 font-medium border-b border-gray-200">情感得分</th>
                  <th className="px-3 py-2 text-center text-gray-500 font-medium border-b border-gray-200">情感标签</th>
                </tr>
              </thead>
              <tbody>
                {detail.danmakus?.slice(0, 100).map(d => (
                  <tr key={d.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-3 py-2 border-b border-gray-100 text-gray-500 whitespace-nowrap">
                      {Math.floor(d.timestamp / 60)}:{String(Math.floor(d.timestamp % 60)).padStart(2, '0')}
                    </td>
                    <td className="px-3 py-2 border-b border-gray-100 text-gray-700">{d.content}</td>
                    <td className="px-3 py-2 border-b border-gray-100 text-center text-gray-700">
                      {d.sentiment_score.toFixed(2)}
                    </td>
                    <td className="px-3 py-2 border-b border-gray-100 text-center">
                      <span className={`px-2 py-0.5 rounded text-xs font-medium ${
                        d.sentiment_label === 'positive' ? 'bg-green-50 text-green-600' :
                        d.sentiment_label === 'negative' ? 'bg-red-50 text-red-500' :
                        'bg-yellow-50 text-yellow-600'
                      }`}>
                        {d.sentiment_label === 'positive' ? '正面' :
                         d.sentiment_label === 'negative' ? '负面' : '中性'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  )
}
