import { useCallback, useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'
import { bilibiliApi } from '../../api/bilibili'
import Navbar from '../../components/Navbar'

export default function HotVideos() {
  const navigate = useNavigate()
  const [videos, setVideos] = useState([])
  const [loading, setLoading] = useState(true)

  const fetchHotVideos = useCallback(async () => {
    try {
      const response = await bilibiliApi.getHotVideos()
      if (response.code === 200) {
        setVideos(response.data || [])
      }
    } catch (error) {
      console.error('获取热门视频失败:', error)
      toast.error('获取热门视频失败')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect -- initial remote data load
    void fetchHotVideos()
  }, [fetchHotVideos])

  const handleAnalyze = (video) => {
    // 将视频 URL 作为 query param 传入分析页，自动预填写
    const params = new URLSearchParams({ url: video.video_url })
    navigate(`/bilibili/analyze?${params.toString()}`)
  }

  const getSentimentColor = (score) => {
    if (score > 0.1) return '#52c41a'
    if (score < -0.1) return '#ff4d4f'
    return '#faad14'
  }

  const getSentimentText = (score) => {
    if (score > 0.1) return '正面'
    if (score < -0.1) return '负面'
    return '中性'
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="flex items-center justify-center py-32">
          <div className="text-gray-500 text-lg">加载中...</div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="max-w-4xl mx-auto px-4 py-10">
        <div className="flex items-center gap-3 mb-8">
          <span className="text-3xl">🔥</span>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">热门视频排行</h1>
            <p className="text-sm text-gray-500 mt-1">按被分析次数排序，点击可即刻重新分析该视频</p>
          </div>
        </div>

        {videos.length === 0 ? (
          <div className="bg-white rounded-xl p-16 text-center shadow-sm">
            <div className="text-4xl mb-4">📺</div>
            <p className="text-gray-400 text-lg">暂无热门数据，尝试分析一个视频后再查看</p>
            <button
              onClick={() => navigate('/bilibili/analyze')}
              className="mt-6 px-6 py-2 bg-pink-500 text-white rounded-lg hover:bg-pink-600 transition-colors"
            >
              去分析
            </button>
          </div>
        ) : (
          <div className="flex flex-col gap-4">
            {videos.map((video, index) => (
              <div
                key={video.video_id}
                className="bg-white rounded-xl shadow-sm border border-gray-100 p-5 hover:shadow-md hover:-translate-y-0.5 transition-all"
              >
                <div className="flex items-center gap-4">
                  {/* 排名 */}
                  <div className={`text-2xl font-bold min-w-[2.5rem] text-center ${
                    index < 3 ? 'text-red-500' : 'text-gray-300'
                  }`}>
                    #{index + 1}
                  </div>

                  {/* 视频信息 */}
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-gray-800 truncate" title={video.video_title}>
                      {video.video_title}
                    </h3>
                    <p className="text-sm text-gray-500 mt-1">UP主：{video.uploader}</p>
                  </div>

                  {/* 分析次数 */}
                  <div className="text-center px-4">
                    <div className="text-xl font-bold text-pink-500">{video.analysis_count}</div>
                    <div className="text-xs text-gray-400">分析次数</div>
                  </div>

                  {/* 平均情感 */}
                  <div className="text-center px-4">
                    <div
                      className="text-xl font-bold"
                      style={{ color: getSentimentColor(video.avg_sentiment) }}
                    >
                      {video.avg_sentiment?.toFixed(2)}
                    </div>
                    <div className="text-xs text-gray-400">
                      {getSentimentText(video.avg_sentiment)}
                    </div>
                  </div>

                  {/* 操作按鈕 */}
                  <div className="flex flex-col gap-2 ml-2">
                    <button
                      onClick={() => handleAnalyze(video)}
                      className="px-4 py-2 bg-pink-500 text-white text-sm rounded-lg hover:bg-pink-600 transition-colors whitespace-nowrap"
                    >
                      🔍 重新分析
                    </button>
                    <a
                      href={video.video_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-4 py-2 bg-gray-100 text-gray-600 text-sm rounded-lg hover:bg-gray-200 transition-colors text-center whitespace-nowrap"
                    >
                      查看原视频
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
