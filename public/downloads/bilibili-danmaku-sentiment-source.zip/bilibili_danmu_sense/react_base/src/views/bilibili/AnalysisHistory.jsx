import { useCallback, useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'
import { bilibiliApi } from '../../api/bilibili'
import Navbar from '../../components/Navbar'

export default function AnalysisHistory() {
  const navigate = useNavigate()
  const [analyses, setAnalyses] = useState([])
  const [loading, setLoading] = useState(true)
  const [page, setPage] = useState(1)
  const [hasMore, setHasMore] = useState(true)

  const fetchAnalyses = useCallback(async () => {
    try {
      const response = await bilibiliApi.getAnalysisList({ page })
      if (response.code === 200) {
        const newData = response.data.results || response.data || []
        setAnalyses(prev => page === 1 ? newData : [...prev, ...newData])
        setHasMore(!!response.data.next)
      }
    } catch (error) {
      console.error('获取历史失败:', error)
      toast.error('获取历史记录失败')
    } finally {
      setLoading(false)
    }
  }, [page])

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect -- reload the requested remote page
    void fetchAnalyses()
  }, [fetchAnalyses])

  const handleDelete = async (id, e) => {
    e.stopPropagation()
    if (!confirm('确定要删除这条分析记录吗?')) return
    try {
      const response = await bilibiliApi.deleteAnalysis(id)
      if (response.code === 200) {
        toast.success('删除成功')
        setAnalyses(prev => prev.filter(a => a.id !== id))
      }
    } catch {
      toast.error('删除失败')
    }
  }

  const formatDate = (dateStr) => new Date(dateStr).toLocaleString('zh-CN')

  const sentimentInfo = (score) => {
    if (score > 0.1) return { text: '正面', color: 'text-green-500' }
    if (score < -0.1) return { text: '负面', color: 'text-red-500' }
    return { text: '中性', color: 'text-yellow-500' }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="flex items-center justify-center py-32">
          <div className="text-gray-400 text-lg">加载中...</div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="max-w-4xl mx-auto px-4 py-10">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <span className="text-3xl">📝</span>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">分析历史</h1>
              <p className="text-sm text-gray-500 mt-1">点击卡片查看详细分析报告</p>
            </div>
          </div>
          <button
            onClick={() => navigate('/bilibili/analyze')}
            className="px-4 py-2 bg-pink-500 text-white rounded-lg hover:bg-pink-600 transition-colors text-sm font-medium"
          >
            + 新建分析
          </button>
        </div>

        {analyses.length === 0 ? (
          <div className="bg-white rounded-xl p-16 text-center shadow-sm">
            <div className="text-4xl mb-4">📊</div>
            <p className="text-gray-400 text-lg">暂无分析记录</p>
            <button
              onClick={() => navigate('/bilibili/analyze')}
              className="mt-6 px-6 py-2 bg-pink-500 text-white rounded-lg hover:bg-pink-600 transition-colors"
            >
              开始分析
            </button>
          </div>
        ) : (
          <div className="flex flex-col gap-4">
            {analyses.map(analysis => {
              const si = sentimentInfo(analysis.avg_sentiment_score)
              return (
                <div
                  key={analysis.id}
                  onClick={() => navigate(`/bilibili/analysis/${analysis.id}`)}
                  className="bg-white rounded-xl shadow-sm border border-gray-100 p-5 cursor-pointer hover:shadow-md hover:-translate-y-0.5 transition-all"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-gray-800 truncate" title={analysis.video_title}>
                        {analysis.video_title}
                      </h3>
                      <p className="text-sm text-gray-500 mt-1">UP主：{analysis.uploader}</p>
                      <p className="text-xs text-gray-400 mt-1">{formatDate(analysis.created_at)}</p>
                    </div>
                    <div className="text-right shrink-0">
                      <div className={`text-2xl font-bold ${si.color}`}>
                        {analysis.avg_sentiment_score.toFixed(2)}
                      </div>
                      <div className={`text-xs font-medium ${si.color}`}>{si.text}</div>
                    </div>
                  </div>

                  <div className="mt-4 pt-4 border-t border-gray-100 flex items-center justify-between text-sm text-gray-500">
                    <span>弹幕数：<span className="font-medium text-gray-700">{analysis.total_danmaku}</span></span>
                    <span>引擎：{analysis.analysis_engine === 'api' ? '百度AI' : '本地模型'}</span>
                    <div className="flex gap-2">
                      <button
                        onClick={(e) => { e.stopPropagation(); navigate(`/bilibili/analysis/${analysis.id}`) }}
                        className="px-3 py-1 bg-gray-100 text-gray-600 rounded-md hover:bg-gray-200 transition-colors text-xs"
                      >
                        查看详情
                      </button>
                      <button
                        onClick={(e) => handleDelete(analysis.id, e)}
                        className="px-3 py-1 bg-red-50 text-red-500 rounded-md hover:bg-red-100 transition-colors text-xs"
                      >
                        删除
                      </button>
                    </div>
                  </div>
                </div>
              )
            })}

            {hasMore && (
              <div className="text-center mt-4">
                <button
                  onClick={() => setPage(p => p + 1)}
                  className="px-8 py-2 bg-white border border-gray-200 text-gray-600 rounded-lg hover:bg-gray-50 transition-colors text-sm"
                >
                  加载更多
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
