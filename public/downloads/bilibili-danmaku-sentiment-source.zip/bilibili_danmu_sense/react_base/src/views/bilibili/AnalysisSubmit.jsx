import { useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { toast } from 'react-toastify'
import { bilibiliApi } from '../../api/bilibili'
import Navbar from '../../components/Navbar'

export default function AnalysisSubmit() {
  const navigate = useNavigate()
  const [searchParams] = useSearchParams()
  const [videoUrl, setVideoUrl] = useState(() => searchParams.get('url') || '')
  const [engine, setEngine] = useState('local')
  const [loading, setLoading] = useState(false)
  const [step, setStep] = useState(0) // 0:未开始, 1:爬取中, 2:分析中, 3:完成

  const handleSubmit = async (e) => {
    e.preventDefault()

    if (!videoUrl.trim()) {
      toast.error('请输入视频URL')
      return
    }

    if (!videoUrl.includes('bilibili.com')) {
      toast.error('请输入有效的B站视频URL')
      return
    }

    setLoading(true)
    setStep(1)

    try {
      const timer1 = setTimeout(() => setStep(2), 2000)

      const response = await bilibiliApi.submitAnalysis({
        video_url: videoUrl,
        engine: engine,
      })

      clearTimeout(timer1)
      setStep(3)

      if (response.code === 201) {
        toast.success('分析完成!')
        setTimeout(() => {
          navigate(`/bilibili/analysis/${response.data.analysis_id}`)
        }, 800)
      } else {
        toast.error(response.msg || '分析失败')
        setStep(0)
      }
    } catch (error) {
      console.error('分析失败:', error)
      toast.error(error.response?.data?.msg || '分析失败，请检查URL是否正确')
      setStep(0)
    } finally {
      setLoading(false)
    }
  }

  const stepLabels = [
    '',
    '正在爬取弹幕数据...',
    '正在进行情感分析...',
    '分析完成，即将跳转...',
  ]
  const stepProgress = [0, 33, 66, 100]

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="max-w-2xl mx-auto px-4 py-10">
        <div className="flex items-center gap-3 mb-8">
          <span className="text-3xl">🔍</span>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">弹幕情感分析</h1>
            <p className="text-sm text-gray-500 mt-1">输入 B 站视频链接，自动爬取弹幕并进行 AI 情感分析</p>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* 视频 URL */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                视频链接
              </label>
              <input
                type="text"
                value={videoUrl}
                onChange={(e) => setVideoUrl(e.target.value)}
                placeholder="https://www.bilibili.com/video/BV1xx411c7BF"
                disabled={loading}
                className="w-full px-4 py-3 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-pink-300 focus:border-pink-400 disabled:bg-gray-50 disabled:text-gray-400 transition"
              />
            </div>

            {/* 分析引擎 */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                分析引擎
              </label>
              <select
                value={engine}
                onChange={(e) => setEngine(e.target.value)}
                disabled={loading}
                className="w-full px-4 py-3 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-pink-300 focus:border-pink-400 disabled:bg-gray-50 transition bg-white"
              >
                <option value="local">本地模型（SnowNLP，无需配置）</option>
                <option value="api">百度 AI API（准确率高，需配置 Key）</option>
              </select>
            </div>

            {/* 提交按鈕 */}
            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-pink-500 text-white font-semibold rounded-lg hover:bg-pink-600 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors text-base"
            >
              {loading ? '分析中...' : '开始分析'}
            </button>
          </form>

          {/* 进度条 */}
          {loading && (
            <div className="mt-8">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium text-gray-700">分析进度</span>
                <span className="text-sm text-pink-500">{stepProgress[step]}%</span>
              </div>
              <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-pink-500 rounded-full transition-all duration-700"
                  style={{ width: `${stepProgress[step]}%` }}
                />
              </div>
              <p className="mt-3 text-sm text-gray-500 text-center">{stepLabels[step]}</p>
            </div>
          )}

          {/* 使用说明 */}
          <div className="mt-8 p-4 bg-blue-50 rounded-lg">
            <p className="text-sm font-semibold text-blue-700 mb-2">使用说明</p>
            <ul className="text-sm text-blue-600 space-y-1 list-disc list-inside">
              <li>输入完整的 B 站视频链接，支持 BV 号格式</li>
              <li>本地模型无需配置，推荐新手优先选择</li>
              <li>分析时间取决于弹幕数量，通常需要 10–30 秒</li>
              <li>分析结果自动保存，可在历史记录中查看</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}
