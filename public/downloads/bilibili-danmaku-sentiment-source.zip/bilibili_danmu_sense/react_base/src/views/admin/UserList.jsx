import { useCallback, useEffect, useState } from 'react'
import { toast } from 'react-toastify'
import { useUserStore } from '../../stores/userStore'
import { formatDateTime } from '../../utils/helpers'
import Navbar from '../../components/Navbar'

export default function UserList() {
  const { fetchUserList } = useUserStore()
  const [users, setUsers] = useState([])
  const [loading, setLoading] = useState(true)
  const [errorMsg, setErrorMsg] = useState('')

  const loadUsers = useCallback(async () => {
    try {
      const result = await fetchUserList()

      if (result.success) {
        if (result.data.results) {
          setUsers(result.data.results)
        } else if (Array.isArray(result.data)) {
          setUsers(result.data)
        } else {
          setUsers([])
        }
      } else {
        toast.error(result.message || '加载用户列表失败')
        setErrorMsg(result.message)
      }
    } catch (error) {
      const msg = error.response?.data?.msg || error.response?.data?.message || error.response?.data?.detail || '加载用户列表失败'
      toast.error(msg)
      setErrorMsg(msg)
    } finally {
      setLoading(false)
    }
  }, [fetchUserList])

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect -- initial remote data load
    void loadUsers()
  }, [loadUsers])

  const retryLoadUsers = () => {
    setLoading(true)
    setErrorMsg('')
    void loadUsers()
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-3xl font-bold text-gray-900 mb-8">用户管理</h1>

          <div className="bg-white rounded-lg shadow-md p-6">
            {loading ? (
              <div className="text-center py-8">
                <p className="animate-pulse text-gray-600">加载中...</p>
              </div>
            ) : errorMsg ? (
              <div className="text-center py-8">
                <p className="text-red-600 text-sm mt-1">{errorMsg}</p>
                <button 
                  onClick={retryLoadUsers}
                  className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors mt-4"
                >
                  重新加载
                </button>
              </div>
            ) : users.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        ID
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        用户名
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        邮箱
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        手机号
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        角色
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        注册时间
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {users.map((user) => (
                      <tr key={user.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {user.id}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          {user.username}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {user.email || '-'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {user.phone || '-'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span
                            className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                              user.role === 'admin' || user.is_staff
                                ? 'bg-purple-100 text-purple-800'
                                : 'bg-blue-100 text-blue-800'
                            }`}
                          >
                            {user.role === 'admin' || user.is_staff ? '管理员' : '普通用户'}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {formatDateTime(user.created_at || user.date_joined)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-gray-600">暂无用户数据</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
