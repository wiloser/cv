import api from './index'

// B站弹幕分析相关API
export const bilibiliApi = {
  // 提交分析任务
  submitAnalysis: (data) => api.post('/api/bilibili/analyze/', data),
  
  // 获取分析历史列表
  getAnalysisList: (params) => api.get('/api/bilibili/analysis/list/', { params }),
  
  // 获取分析详情
  getAnalysisDetail: (id) => api.get(`/api/bilibili/analysis/${id}/`),
  
  // 获取弹幕数据
  getDanmakuList: (id, params) => api.get(`/api/bilibili/analysis/${id}/danmaku/`, { params }),
  
  // 获取关键词数据
  getKeywords: (id) => api.get(`/api/bilibili/analysis/${id}/keywords/`),
  
  // 获取时间序列数据
  getTimeline: (id) => api.get(`/api/bilibili/analysis/${id}/timeline/`),
  
  // 获取热门视频
  getHotVideos: () => api.get('/api/bilibili/hot-videos/'),
  
  // 删除分析记录
  deleteAnalysis: (id) => api.delete(`/api/bilibili/analysis/${id}/delete/`),
}

export default bilibiliApi
