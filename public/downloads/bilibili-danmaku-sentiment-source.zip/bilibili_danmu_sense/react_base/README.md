# B站弹幕情感分析系统 - 前端

基于 React 19 + Vite 8 构建的 B 站弹幕情感分析可视化平台。

## 技术栈

- **React 19** - 用户界面库
- **React Router 7** - 路由管理
- **Zustand 5** - 轻量级状态管理
- **ECharts 6** - 数据可视化图表库
- **Axios 1.15** - HTTP 客户端
- **React Toastify 11** - 消息提示组件
- **Vite 8** - 前端构建工具

## 项目结构

```
src/
├── api/                    # API 接口层
│   ├── index.js           # Axios 实例配置
│   ├── user.js            # 用户相关接口
│   └── bilibili.js        # B站分析接口
├── assets/                # 静态资源
├── components/            # 公共组件
│   └── Navbar.jsx         # 导航栏
├── router/                # 路由配置
│   └── index.jsx          # 路由定义与权限控制
├── stores/                # 状态管理
│   └── userStore.js       # 用户状态 (Zustand)
├── utils/                 # 工具函数
├── views/                 # 页面组件
│   ├── auth/              # 认证页面
│   │   ├── Login.jsx      # 登录
│   │   └── Register.jsx   # 注册
│   ├── admin/             # 管理页面
│   │   └── UserList.jsx   # 用户列表
│   ├── user/              # 用户页面
│   │   ├── Profile.jsx    # 个人信息
│   │   └── ChangePassword.jsx  # 修改密码
│   ├── bilibili/          # B站分析页面
│   │   ├── AnalysisSubmit.jsx      # 分析提交
│   │   ├── AnalysisDetail.jsx      # 分析详情
│   │   ├── AnalysisHistory.jsx     # 历史记录
│   │   ├── HotVideos.jsx           # 热门视频
│   │   ├── SentimentCompare.jsx    # 情感对比
│   │   └── components/             # 图表组件
│   ├── Home.jsx           # 首页
│   └── NotFound.jsx       # 404页面
├── App.jsx                # 根组件
└── main.jsx               # 应用入口
```

## 快速开始

### 安装依赖

```bash
npm install
```

### 开发模式

```bash
npm run dev
```

应用将在 `http://localhost:5173` 启动，支持热更新。

### 生产构建

```bash
npm run build
```

构建产物将输出到 `dist/` 目录。

### 预览构建产物

```bash
npm run preview
```

## 环境配置

创建 `.env` 文件配置环境变量:

```env
# API 基础URL (开发环境留空使用 Vite 代理)
VITE_API_BASE_URL=

# 或使用完整URL
# VITE_API_BASE_URL=http://localhost:8000
```

## API 接口

所有 API 请求统一通过 `src/api/` 目录管理:

- **用户接口**: 登录、注册、个人信息
- **B站分析接口**: 提交分析、获取数据、历史记录

## 状态管理

使用 Zustand 进行全局状态管理:

- 用户认证状态
- Token 管理
- 用户信息缓存

## 路由权限

系统实现了基于角色的路由权限控制:

- **公开路由**: 首页、登录、注册、热门视频
- **认证路由**: 分析提交、历史记录、个人中心
- **管理员路由**: 用户管理

## 代码规范

项目使用 ESLint 进行代码质量检查:

```bash
npm run lint
```

遵循 React Hooks 规则和 React Refresh 最佳实践。

## 浏览器支持

- Chrome >= 87
- Firefox >= 78
- Safari >= 14
- Edge >= 88

## 开发规范

1. **组件命名**: PascalCase (如 `AnalysisSubmit.jsx`)
2. **文件结构**: 功能模块按目录组织
3. **API 调用**: 统一使用 api 层封装
4. **状态管理**: 全局状态使用 Zustand，局部状态使用 useState
5. **样式方案**: Tailwind CSS + 内联样式

## 部署

### Vercel

```bash
vercel deploy
```

### Nginx 配置

```nginx
server {
    listen 80;
    server_name your-domain.com;
    
    location / {
        root /path/to/dist;
        try_files $uri $uri/ /index.html;
    }
    
    location /api/ {
        proxy_pass http://localhost:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

## 许可证

MIT License
