#!/usr/bin/env bash

# Start the React frontend and Django backend together for local development.
set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
BACKEND_DIR="$ROOT/django_base"
FRONTEND_DIR="$ROOT/react_base"
VENV_DIR="$BACKEND_DIR/.venv"
BACKEND_PORT="${BACKEND_PORT:-8181}"
FRONTEND_PORT="${FRONTEND_PORT:-5173}"
BACKEND_PID=""
FRONTEND_PID=""

usage() {
  cat <<'EOF'
Usage:
  ./start.sh           Start Django and React
  ./start.sh --setup   Install dependencies and run database migrations
  ./start.sh --check   Check whether the required tools and dependencies exist
  ./start.sh --help    Show this help

Optional environment variables:
  BACKEND_PORT=8181 FRONTEND_PORT=5173 ./start.sh
EOF
}

fail() {
  printf 'Error: %s\n' "$*" >&2
  exit 1
}

find_python() {
  if [[ -x "$VENV_DIR/bin/python" ]]; then
    printf '%s\n' "$VENV_DIR/bin/python"
  elif command -v python3 >/dev/null 2>&1; then
    command -v python3
  else
    return 1
  fi
}

check_tools() {
  local python_bin
  python_bin="$(find_python)" || fail "Python 3 is not installed."
  command -v npm >/dev/null 2>&1 || fail "Node.js/npm is not installed."

  "$python_bin" -c 'import django' >/dev/null 2>&1 || \
    fail "Django dependencies are missing. Run ./start.sh --setup first."
  [[ -d "$FRONTEND_DIR/node_modules" ]] || \
    fail "React dependencies are missing. Run ./start.sh --setup first."

  printf 'Ready: Python, Django, Node.js, npm, and React dependencies found.\n'
}

setup_project() {
  command -v python3 >/dev/null 2>&1 || fail "Python 3 is not installed."
  command -v npm >/dev/null 2>&1 || fail "Node.js/npm is not installed."

  if [[ ! -x "$VENV_DIR/bin/python" ]]; then
    printf 'Creating the Python virtual environment...\n'
    python3 -m venv "$VENV_DIR" || fail "Could not create $VENV_DIR."
  fi

  printf 'Installing Django dependencies...\n'
  "$VENV_DIR/bin/python" -m pip install -r "$BACKEND_DIR/requirements.txt" || \
    fail "Python dependency installation failed."

  printf 'Applying database migrations...\n'
  (cd "$BACKEND_DIR" && "$VENV_DIR/bin/python" manage.py migrate) || \
    fail "Django database migration failed."

  printf 'Installing React dependencies...\n'
  (cd "$FRONTEND_DIR" && npm install) || fail "React dependency installation failed."

  printf '\nSetup complete. Start the project with: ./start.sh\n'
}

stop_servers() {
  trap - INT TERM EXIT
  printf '\nStopping development servers...\n'
  [[ -n "$FRONTEND_PID" ]] && kill "$FRONTEND_PID" 2>/dev/null || true
  [[ -n "$BACKEND_PID" ]] && kill "$BACKEND_PID" 2>/dev/null || true
  [[ -n "$FRONTEND_PID" ]] && wait "$FRONTEND_PID" 2>/dev/null || true
  [[ -n "$BACKEND_PID" ]] && wait "$BACKEND_PID" 2>/dev/null || true
}

start_project() {
  local python_bin process_status
  check_tools
  python_bin="$(find_python)" || fail "Python 3 is not installed."

  trap stop_servers INT TERM EXIT

  printf '\nStarting Django: http://127.0.0.1:%s\n' "$BACKEND_PORT"
  (cd "$BACKEND_DIR" && exec "$python_bin" manage.py runserver "127.0.0.1:$BACKEND_PORT") &
  BACKEND_PID=$!

  printf 'Starting React: http://127.0.0.1:%s\n' "$FRONTEND_PORT"
  printf 'Press Ctrl-C to stop both servers.\n\n'
  (cd "$FRONTEND_DIR" && exec npm run dev -- --host 127.0.0.1 --port "$FRONTEND_PORT") &
  FRONTEND_PID=$!

  # Bash 3.2 (the macOS default) has no `wait -n`, so monitor both processes.
  while kill -0 "$BACKEND_PID" 2>/dev/null && kill -0 "$FRONTEND_PID" 2>/dev/null; do
    sleep 1
  done

  if ! kill -0 "$BACKEND_PID" 2>/dev/null; then
    wait "$BACKEND_PID"
    process_status=$?
    [[ "$process_status" -eq 0 || "$process_status" -eq 130 || "$process_status" -eq 143 ]] && exit 0
    fail "The Django server stopped unexpectedly."
  fi

  wait "$FRONTEND_PID"
  process_status=$?
  [[ "$process_status" -eq 0 || "$process_status" -eq 130 || "$process_status" -eq 143 ]] && exit 0
  fail "The React server stopped unexpectedly."
}

case "${1:-start}" in
  start)
    [[ $# -le 1 ]] || fail "The start command does not accept extra arguments."
    start_project
    ;;
  --setup|-setup|setup)
    [[ $# -eq 1 ]] || fail "The setup command does not accept extra arguments."
    setup_project
    ;;
  --check|-check|check)
    [[ $# -eq 1 ]] || fail "The check command does not accept extra arguments."
    check_tools
    ;;
  --help|-h|help)
    usage
    ;;
  *)
    usage >&2
    exit 2
    ;;
esac
