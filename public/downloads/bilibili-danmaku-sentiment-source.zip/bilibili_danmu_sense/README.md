# B站弹幕情感分析系统

> 基于 Django + React 的全栈 B 站弹幕爬取与情感分析平台

![Python](https://img.shields.io/badge/Python-3.8+-blue.svg)
![Django](https://img.shields.io/badge/Django-4.2-green.svg)
![React](https://img.shields.io/badge/React-19-blue.svg)
![License](https://img.shields.io/badge/License-MIT-yellow.svg)

## 项目简介

本系统是一个完整的 B 站弹幕情感分析平台,支持用户输入 B 站视频 URL 后自动爬取弹幕数据,并通过双引擎(百度 AI API + SnowNLP 本地模型)进行情感分析,最终生成多维度的可视化图表。

系统采用前后端分离架构,后端基于 Django REST Framework 构建 RESTful API,前端使用 React + ECharts 实现数据可视化。

## 核心功能

### 🎯 弹幕分析
- **自动爬取**: 输入视频 URL 即可自动获取弹幕数据
- **双引擎分析**: 支持百度 AI API 和 SnowNLP 本地模型
- **多维度分析**: 情感极性、关键词词云、时间趋势、弹幕密度

### 📊 数据可视化
- **情感分布**: 饼图展示正面/负面/中性比例
- **关键词云**: 高频词汇可视化
- **时间趋势**: 弹幕密度与情感得分双轴折线图
- **对比分析**: 多视频情感对比 (最多 5 个)

### 💼 业务场景
- **个人分析**: 用户自主提交视频分析
- **历史记录**: 查看、管理历史分析数据
- **热门排行**: TOP 20 热门分析视频
- **情感对比**: 多视频横向对比分析

## 技术栈

### 后端
- **框架**: Django 4.2 + Django REST Framework
- **数据库**: SQLite / MySQL 8.0
- **缓存**: Redis (可选)
- **认证**: JWT (SimpleJWT)
- **爬虫**: requests + lxml
- **NLP**: SnowNLP + jieba + 百度 AI

### 前端
- **框架**: React 19
- **路由**: React Router 7
- **状态**: Zustand 5
- **图表**: ECharts 6
- **HTTP**: Axios
- **构建**: Vite 8
- **样式**: Tailwind CSS

## 项目结构

```
workplace/
├── django_base/                 # 后端项目
│   ├── apps/                    # 应用模块
│   │   ├── users/              # 用户模块
│   │   └── bilibili/           # B站分析模块
│   ├── core/                    # 核心模块
│   ├── mysite/                  # 项目配置
│   ├── logs/                    # 日志目录
│   ├── manage.py
│   └── requirements.txt
│
├── react_base/                  # 前端项目
│   ├── src/
│   │   ├── api/                # API 接口层
│   │   ├── components/         # 公共组件
│   │   ├── router/             # 路由配置
│   │   ├── stores/             # 状态管理
│   │   └── views/              # 页面组件
│   │       ├── auth/           # 认证页面
│   │       ├── admin/          # 管理页面
│   │       ├── user/           # 用户页面
│   │       └── bilibili/       # B站分析页面
│   ├── public/                  # 静态资源
│   ├── package.json
│   └── vite.config.js
│
├── B站弹幕分析系统使用说明.md    # 使用文档
└── 启动指南.md                  # 启动指南
```

## 快速开始

### 环境要求

- Python >= 3.8
- Node.js >= 16
- MySQL >= 8.0 (可选)

### 1. 克隆项目

```bash
git clone <repository-url>
cd workplace
```

### 2. 启动后端

```bash
cd django_base

# 安装依赖
pip install -r requirements.txt

# 数据库迁移
python manage.py makemigrations
python manage.py migrate

# 创建超级用户 (可选)
python manage.py createsuperuser

# 启动服务
python manage.py runserver
```

后端服务运行在: `http://localhost:8000`

### 3. 启动前端

```bash
cd react_base

# 安装依赖
npm install

# 启动开发服务器
npm run dev
```

前端服务运行在: `http://localhost:5173`

### 4. 访问系统

打开浏览器访问 `http://localhost:5173`,注册账号后即可使用。

## 配置说明

### 百度 AI API (可选)

如需使用百度 AI 情感分析引擎:

1. 注册百度 AI 开放平台: https://ai.baidu.com/
2. 创建应用获取 API Key 和 Secret Key
3. 在 `django_base/mysite/settings.py` 中配置:

```python
BAIDU_API_KEY = 'your_api_key'
BAIDU_SECRET_KEY = 'your_secret_key'
```

不配置时系统将自动降级到 SnowNLP 本地模型。

### 数据库配置

#### 使用 SQLite (默认)

无需额外配置,自动创建 `db.sqlite3`。

#### 使用 MySQL

修改 `django_base/mysite/settings.py`:

```python
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'bilibili_analysis',
        'USER': 'root',
        'PASSWORD': 'your_password',
        'HOST': 'localhost',
        'PORT': '3306',
    }
}
```

## API 文档

### 认证接口
- `POST /api/users/register/` - 用户注册
- `POST /api/users/login/` - 用户登录
- `GET /api/users/profile/` - 获取个人信息

### 弹幕分析接口
- `POST /api/bilibili/analyze/` - 提交分析任务
- `GET /api/bilibili/analysis/list/` - 获取分析历史
- `GET /api/bilibili/analysis/{id}/` - 获取分析详情
- `GET /api/bilibili/hot-videos/` - 获取热门视频

详细 API 文档请查看各项目 README。

## 部署

### 前端部署

```bash
cd react_base
npm run build
```

构建产物输出到 `dist/` 目录,可部署到 Nginx、Vercel 等平台。

### 后端部署

```bash
cd django_base
pip install gunicorn
gunicorn mysite.wsgi:application --bind 0.0.0.0:8000 --workers 4
```

配合 Nginx 反向代理使用。

## 开发规范

### 后端
- 应用模块化,放在 `apps/` 目录
- 统一使用 `APIResponse` 返回标准格式
- 基于角色的权限控制
- 关键操作记录日志

### 前端
- 组件命名: PascalCase
- API 调用统一使用 api 层封装
- 全局状态使用 Zustand
- 遵循 React Hooks 最佳实践

## 文档

- [B站弹幕分析系统使用说明.md](./B站弹幕分析系统使用说明.md) - 完整使用文档
- [启动指南.md](./启动指南.md) - 启动和排障指南
- [后端 README](./django_base/README.md) - 后端项目文档
- [前端 README](./react_base/README.md) - 前端项目文档

## 常见问题

### 1. 数据库迁移失败

清理缓存后重试:
```bash
find . -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null
python manage.py makemigrations
python manage.py migrate
```

### 2. 前端无法连接后端

确保后端服务已启动,并检查 `react_base/vite.config.js` 中的代理配置。

### 3. 情感分析失败

检查百度 API Key 配置,或确认 SnowNLP 依赖已正确安装。

更多问题请查看 [启动指南.md](./启动指南.md)

## 许可证

MIT License

## 作者

Your Name

## 更新日志

### v1.0.0 (2026-04-22)
- 初始版本发布
- 支持弹幕爬取与情感分析
- 多维度数据可视化
- 历史记录管理
- 情感对比功能
