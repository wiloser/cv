from django.contrib import admin
from apps.bilibili.models import VideoAnalysis, Danmaku, KeywordStat, DanmakuTimeSlot


@admin.register(VideoAnalysis)
class VideoAnalysisAdmin(admin.ModelAdmin):
    list_display = ['id', 'video_title', 'uploader', 'total_danmaku', 'analysis_engine', 'user', 'created_at']
    list_filter = ['analysis_engine', 'created_at']
    search_fields = ['video_title', 'video_id', 'uploader']
    readonly_fields = ['created_at', 'updated_at']


@admin.register(Danmaku)
class DanmakuAdmin(admin.ModelAdmin):
    list_display = ['id', 'content', 'timestamp', 'sentiment_label', 'sentiment_score']
    list_filter = ['sentiment_label']
    search_fields = ['content']


@admin.register(KeywordStat)
class KeywordStatAdmin(admin.ModelAdmin):
    list_display = ['id', 'keyword', 'frequency', 'avg_sentiment']
    list_filter = ['created_at']
    search_fields = ['keyword']


@admin.register(DanmakuTimeSlot)
class DanmakuTimeSlotAdmin(admin.ModelAdmin):
    list_display = ['id', 'start_time', 'end_time', 'danmaku_count', 'avg_sentiment']
