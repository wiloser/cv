"""
B站弹幕分析 URL 路由
"""
from django.urls import path
from apps.bilibili import views

urlpatterns = [
    # 提交分析任务
    path('analyze/', views.SubmitAnalysisView.as_view(), name='submit_analysis'),
    
    # 分析历史列表
    path('analysis/list/', views.AnalysisListView.as_view(), name='analysis_list'),
    
    # 分析详情
    path('analysis/<int:pk>/', views.AnalysisDetailView.as_view(), name='analysis_detail'),
    
    # 弹幕数据
    path('analysis/<int:analysis_id>/danmaku/', views.AnalysisDanmakuView.as_view(), name='analysis_danmaku'),
    
    # 关键词数据
    path('analysis/<int:analysis_id>/keywords/', views.AnalysisKeywordsView.as_view(), name='analysis_keywords'),
    
    # 时间序列数据
    path('analysis/<int:analysis_id>/timeline/', views.AnalysisTimelineView.as_view(), name='analysis_timeline'),
    
    # 热门视频排行
    path('hot-videos/', views.HotVideosView.as_view(), name='hot_videos'),
    
    # 删除分析记录
    path('analysis/<int:pk>/delete/', views.AnalysisDeleteView.as_view(), name='analysis_delete'),
]
