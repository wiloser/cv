"""
B站弹幕分析 API 视图
"""
import logging
from django.db import transaction
from rest_framework import status, generics, permissions
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from core.response import APIResponse
from core.logging_config import LoggerMixin
from apps.bilibili.models import VideoAnalysis, Danmaku, KeywordStat, DanmakuTimeSlot
from apps.bilibili.serializers import (
    VideoAnalysisSerializer,
    VideoAnalysisDetailSerializer,
    DanmakuSerializer,
    KeywordStatSerializer,
    DanmakuTimeSlotSerializer,
    AnalysisRequestSerializer,
)
from apps.bilibili.services.danmaku_fetcher import danmaku_fetcher
from apps.bilibili.services.sentiment_analyzer import sentiment_analyzer
from apps.bilibili.services.data_analyzer import data_analyzer

logger = logging.getLogger('apps')


class SubmitAnalysisView(generics.GenericAPIView, LoggerMixin):
    """提交分析任务"""
    
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = AnalysisRequestSerializer
    
    def post(self, request):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        
        video_url = serializer.validated_data['video_url']
        engine = serializer.validated_data.get('engine', 'api')
        
        try:
            # 1. 提取视频ID
            video_id = danmaku_fetcher.extract_video_id(video_url)
            self.log_info(f'开始分析视频: {video_id}')
            
            # 2. 爬取弹幕
            danmaku_list, video_info = danmaku_fetcher.fetch_danmaku_list(video_id)
            
            if not danmaku_list:
                return APIResponse(
                    code=status.HTTP_400_BAD_REQUEST,
                    msg='该视频暂无弹幕数据'
                )
            
            self.log_info(f'爬取弹幕成功: {len(danmaku_list)} 条')
            
            # 3. 情感分析
            texts = [d['content'] for d in danmaku_list]
            sentiment_results = sentiment_analyzer.analyze(texts, engine)
            
            # 合并弹幕数据和情感分析结果
            for i, d in enumerate(danmaku_list):
                d['sentiment_score'] = sentiment_results[i]['score']
                d['sentiment_label'] = sentiment_results[i]['label']
            
            self.log_info('情感分析完成')
            
            # 4. 数据分析
            distribution = data_analyzer.calculate_sentiment_distribution(danmaku_list)
            keywords = data_analyzer.extract_keywords(danmaku_list, top_n=50)
            time_slots = data_analyzer.analyze_time_series(danmaku_list, interval=30)
            
            self.log_info('数据分析完成')
            
            # 5. 保存到数据库
            with transaction.atomic():
                # 创建分析记录
                analysis = VideoAnalysis.objects.create(
                    user=request.user,
                    video_id=video_id,
                    video_title=video_info['title'],
                    video_url=video_url,
                    uploader=video_info['uploader'],
                    total_danmaku=len(danmaku_list),
                    analysis_engine=engine,
                    **distribution
                )
                
                # 批量创建弹幕记录
                danmaku_objects = [
                    Danmaku(
                        video_analysis=analysis,
                        content=d['content'],
                        timestamp=d['timestamp'],
                        sentiment_score=d['sentiment_score'],
                        sentiment_label=d['sentiment_label'],
                    )
                    for d in danmaku_list
                ]
                Danmaku.objects.bulk_create(danmaku_objects)
                
                # 批量创建关键词统计
                keyword_objects = [
                    KeywordStat(
                        video_analysis=analysis,
                        keyword=k['keyword'],
                        frequency=k['frequency'],
                        avg_sentiment=k['avg_sentiment'],
                    )
                    for k in keywords
                ]
                KeywordStat.objects.bulk_create(keyword_objects)
                
                # 批量创建时间段统计
                timeslot_objects = [
                    DanmakuTimeSlot(
                        video_analysis=analysis,
                        start_time=t['start_time'],
                        end_time=t['end_time'],
                        danmaku_count=t['danmaku_count'],
                        avg_sentiment=t['avg_sentiment'],
                    )
                    for t in time_slots
                ]
                DanmakuTimeSlot.objects.bulk_create(timeslot_objects)
            
            self.log_info(f'分析任务完成: {video_id}')
            
            # 6. 返回结果
            result_data = {
                'analysis_id': analysis.id,
                'video_title': analysis.video_title,
                'total_danmaku': analysis.total_danmaku,
                'positive_count': analysis.positive_count,
                'negative_count': analysis.negative_count,
                'neutral_count': analysis.neutral_count,
                'avg_sentiment_score': analysis.avg_sentiment_score,
            }
            
            return APIResponse(
                code=status.HTTP_201_CREATED,
                msg='分析完成',
                data=result_data
            )
            
        except ValueError as e:
            self.log_error(f'URL格式错误: {e}')
            return APIResponse(
                code=status.HTTP_400_BAD_REQUEST,
                msg=str(e)
            )
        except Exception as e:
            self.log_error(f'分析失败: {e}')
            return APIResponse(
                code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                msg=f'分析失败: {str(e)}'
            )


class AnalysisListView(generics.ListAPIView):
    """获取用户分析历史列表"""
    
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = VideoAnalysisSerializer
    
    def get_queryset(self):
        return VideoAnalysis.objects.filter(user=self.request.user)
    
    def list(self, request, *args, **kwargs):
        queryset = self.get_queryset()
        
        # 分页处理
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)
        
        serializer = self.get_serializer(queryset, many=True)
        return APIResponse(data=serializer.data)


class AnalysisDetailView(generics.RetrieveAPIView):
    """获取单次分析详情"""
    
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = VideoAnalysisDetailSerializer
    
    def get_queryset(self):
        return VideoAnalysis.objects.filter(user=self.request.user)
    
    def retrieve(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = self.get_serializer(instance)
        return APIResponse(data=serializer.data)


class AnalysisDanmakuView(generics.ListAPIView):
    """获取弹幕数据"""
    
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = DanmakuSerializer
    
    def get_queryset(self):
        analysis_id = self.kwargs['analysis_id']
        queryset = Danmaku.objects.filter(video_analysis_id=analysis_id)
        
        # 情感过滤
        sentiment = self.request.query_params.get('sentiment')
        if sentiment:
            queryset = queryset.filter(sentiment_label=sentiment)
        
        return queryset
    
    def list(self, request, *args, **kwargs):
        # 验证分析记录归属
        analysis_id = kwargs.get('analysis_id')
        if not VideoAnalysis.objects.filter(id=analysis_id, user=request.user).exists():
            return APIResponse(
                code=status.HTTP_404_NOT_FOUND,
                msg='分析记录不存在'
            )
        
        queryset = self.get_queryset()
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)
        
        serializer = self.get_serializer(queryset, many=True)
        return APIResponse(data=serializer.data)


class AnalysisKeywordsView(generics.ListAPIView):
    """获取关键词数据"""
    
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = KeywordStatSerializer
    
    def get_queryset(self):
        analysis_id = self.kwargs['analysis_id']
        return KeywordStat.objects.filter(video_analysis_id=analysis_id).order_by('-frequency')
    
    def list(self, request, *args, **kwargs):
        # 验证分析记录归属
        analysis_id = kwargs.get('analysis_id')
        if not VideoAnalysis.objects.filter(id=analysis_id, user=request.user).exists():
            return APIResponse(
                code=status.HTTP_404_NOT_FOUND,
                msg='分析记录不存在'
            )
        
        queryset = self.get_queryset()
        serializer = self.get_serializer(queryset, many=True)
        return APIResponse(data=serializer.data)


class AnalysisTimelineView(generics.ListAPIView):
    """获取时间序列数据"""
    
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = DanmakuTimeSlotSerializer
    
    def get_queryset(self):
        analysis_id = self.kwargs['analysis_id']
        return DanmakuTimeSlot.objects.filter(video_analysis_id=analysis_id).order_by('start_time')
    
    def list(self, request, *args, **kwargs):
        # 验证分析记录归属
        analysis_id = kwargs.get('analysis_id')
        if not VideoAnalysis.objects.filter(id=analysis_id, user=request.user).exists():
            return APIResponse(
                code=status.HTTP_404_NOT_FOUND,
                msg='分析记录不存在'
            )
        
        queryset = self.get_queryset()
        serializer = self.get_serializer(queryset, many=True)
        return APIResponse(data=serializer.data)


class HotVideosView(generics.GenericAPIView):
    """获取热门分析视频排行"""
    
    permission_classes = [permissions.AllowAny]
    
    def get(self, request):
        """
        按视频被分析次数排序,返回 TOP 20
        """
        from django.db.models import Count, Avg
        
        # 统计每个视频的分析次数
        hot_videos = VideoAnalysis.objects.values(
            'video_id', 'video_title', 'video_url', 'uploader'
        ).annotate(
            analysis_count=Count('id'),
            avg_sentiment=Avg('avg_sentiment_score')
        ).order_by('-analysis_count')[:20]
        
        return APIResponse(data=list(hot_videos))


class AnalysisDeleteView(generics.DestroyAPIView):
    """删除分析记录"""
    
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        return VideoAnalysis.objects.filter(user=self.request.user)
    
    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        self.perform_destroy(instance)
        return APIResponse(msg='删除成功')
