"""
序列化器
"""
from rest_framework import serializers
from apps.bilibili.models import VideoAnalysis, Danmaku, KeywordStat, DanmakuTimeSlot


class DanmakuSerializer(serializers.ModelSerializer):
    """弹幕序列化器"""
    
    class Meta:
        model = Danmaku
        fields = ['id', 'content', 'timestamp', 'sentiment_score', 'sentiment_label', 'created_at']
        read_only_fields = ['id', 'created_at']


class KeywordStatSerializer(serializers.ModelSerializer):
    """关键词统计序列化器"""
    
    class Meta:
        model = KeywordStat
        fields = ['id', 'keyword', 'frequency', 'avg_sentiment', 'created_at']
        read_only_fields = ['id', 'created_at']


class DanmakuTimeSlotSerializer(serializers.ModelSerializer):
    """时间段统计序列化器"""
    
    class Meta:
        model = DanmakuTimeSlot
        fields = ['id', 'start_time', 'end_time', 'danmaku_count', 'avg_sentiment', 'created_at']
        read_only_fields = ['id', 'created_at']


class VideoAnalysisSerializer(serializers.ModelSerializer):
    """视频分析记录序列化器"""
    
    class Meta:
        model = VideoAnalysis
        fields = [
            'id', 'video_id', 'video_title', 'video_url', 'uploader',
            'total_danmaku', 'analysis_engine', 'positive_count',
            'negative_count', 'neutral_count', 'avg_sentiment_score',
            'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']


class VideoAnalysisDetailSerializer(serializers.ModelSerializer):
    """视频分析详情序列化器"""
    danmakus = DanmakuSerializer(many=True, read_only=True)
    keywords = KeywordStatSerializer(many=True, read_only=True)
    time_slots = DanmakuTimeSlotSerializer(many=True, read_only=True)
    
    class Meta:
        model = VideoAnalysis
        fields = [
            'id', 'video_id', 'video_title', 'video_url', 'uploader',
            'total_danmaku', 'analysis_engine', 'positive_count',
            'negative_count', 'neutral_count', 'avg_sentiment_score',
            'created_at', 'updated_at',
            'danmakus', 'keywords', 'time_slots'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']


class AnalysisRequestSerializer(serializers.Serializer):
    """分析请求序列化器"""
    video_url = serializers.URLField(label='视频URL', help_text='B站视频URL')
    engine = serializers.ChoiceField(
        choices=['api', 'local'],
        default='api',
        label='分析引擎',
        help_text='分析引擎: api(百度AI) 或 local(本地模型)'
    )
    
    def validate_video_url(self, value):
        """验证视频URL"""
        if 'bilibili.com' not in value:
            raise serializers.ValidationError('请输入有效的B站视频URL')
        return value
