from django.apps import AppConfig


class BilibiliConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.bilibili'
    verbose_name = 'B站弹幕分析'
