from django.db import models
from django.conf import settings


class VideoAnalysis(models.Model):
    """视频分析记录表"""
    
    ENGINE_CHOICES = (
        ('api', '第三方API'),
        ('local', '本地模型'),
    )
    
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='video_analyses',
        verbose_name='分析用户'
    )
    video_id = models.CharField(max_length=20, verbose_name='B站视频ID')
    video_title = models.CharField(max_length=200, verbose_name='视频标题')
    video_url = models.URLField(verbose_name='视频URL')
    uploader = models.CharField(max_length=100, verbose_name='UP主名称')
    total_danmaku = models.IntegerField(default=0, verbose_name='弹幕总数')
    analysis_engine = models.CharField(max_length=10, choices=ENGINE_CHOICES, default='api', verbose_name='分析引擎')
    positive_count = models.IntegerField(default=0, verbose_name='正向弹幕数')
    negative_count = models.IntegerField(default=0, verbose_name='负向弹幕数')
    neutral_count = models.IntegerField(default=0, verbose_name='中性弹幕数')
    avg_sentiment_score = models.FloatField(default=0.0, verbose_name='平均情感得分')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    updated_at = models.DateTimeField(auto_now=True, verbose_name='更新时间')
    
    class Meta:
        db_table = 'video_analysis'
        verbose_name = '视频分析记录'
        verbose_name_plural = verbose_name
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['video_id']),
            models.Index(fields=['user', '-created_at']),
        ]
    
    def __str__(self):
        return f'{self.video_title} - {self.user.username}'


class Danmaku(models.Model):
    """弹幕数据表"""
    
    SENTIMENT_CHOICES = (
        ('positive', '正面'),
        ('negative', '负面'),
        ('neutral', '中性'),
    )
    
    video_analysis = models.ForeignKey(
        VideoAnalysis,
        on_delete=models.CASCADE,
        related_name='danmakus',
        verbose_name='所属分析记录'
    )
    content = models.CharField(max_length=500, verbose_name='弹幕内容')
    timestamp = models.FloatField(verbose_name='弹幕时间位置(秒)')
    sentiment_score = models.FloatField(default=0.0, verbose_name='情感得分')
    sentiment_label = models.CharField(max_length=10, choices=SENTIMENT_CHOICES, default='neutral', verbose_name='情感标签')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    
    class Meta:
        db_table = 'danmaku'
        verbose_name = '弹幕数据'
        verbose_name_plural = verbose_name
        ordering = ['timestamp']
        indexes = [
            models.Index(fields=['video_analysis', 'sentiment_label']),
        ]
    
    def __str__(self):
        return f'{self.content[:30]}...'


class KeywordStat(models.Model):
    """关键词统计表"""
    
    video_analysis = models.ForeignKey(
        VideoAnalysis,
        on_delete=models.CASCADE,
        related_name='keywords',
        verbose_name='所属分析记录'
    )
    keyword = models.CharField(max_length=50, verbose_name='关键词')
    frequency = models.IntegerField(default=0, verbose_name='出现频次')
    avg_sentiment = models.FloatField(default=0.0, verbose_name='平均情感得分')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    
    class Meta:
        db_table = 'keyword_stat'
        verbose_name = '关键词统计'
        verbose_name_plural = verbose_name
        ordering = ['-frequency']
        unique_together = ['video_analysis', 'keyword']
        indexes = [
            models.Index(fields=['video_analysis', '-frequency']),
        ]
    
    def __str__(self):
        return f'{self.keyword} ({self.frequency})'


class DanmakuTimeSlot(models.Model):
    """时间段统计表"""
    
    video_analysis = models.ForeignKey(
        VideoAnalysis,
        on_delete=models.CASCADE,
        related_name='time_slots',
        verbose_name='所属分析记录'
    )
    start_time = models.FloatField(verbose_name='时间段起始秒数')
    end_time = models.FloatField(verbose_name='时间段结束秒数')
    danmaku_count = models.IntegerField(default=0, verbose_name='弹幕数')
    avg_sentiment = models.FloatField(default=0.0, verbose_name='平均情感得分')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    
    class Meta:
        db_table = 'danmaku_time_slot'
        verbose_name = '时间段统计'
        verbose_name_plural = verbose_name
        ordering = ['start_time']
        unique_together = ['video_analysis', 'start_time']
    
    def __str__(self):
        return f'{self.start_time}s-{self.end_time}s'
