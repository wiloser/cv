"""
情感分析双引擎服务
"""
import logging
import time
from django.conf import settings

logger = logging.getLogger('apps')


class BaiduSentimentAnalyzer:
    """百度 AI 情感分析引擎"""
    
    def __init__(self):
        self.api_key = getattr(settings, 'BAIDU_API_KEY', '')
        self.secret_key = getattr(settings, 'BAIDU_SECRET_KEY', '')
        self.access_token = None
        self.token_expires_at = 0
    
    def _get_access_token(self):
        """获取百度 API access_token"""
        import requests
        
        # 如果 token 未过期,直接返回
        if self.access_token and time.time() < self.token_expires_at:
            return self.access_token
        
        try:
            url = 'https://aip.baidubce.com/oauth/2.0/token'
            params = {
                'grant_type': 'client_credentials',
                'client_id': self.api_key,
                'client_secret': self.secret_key,
            }
            
            response = requests.post(url, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            self.access_token = data.get('access_token')
            # token 有效期 30 天,这里设置 29 天过期
            self.token_expires_at = time.time() + 29 * 24 * 3600
            
            return self.access_token
            
        except Exception as e:
            logger.error(f'获取百度 API token 失败: {e}')
            raise Exception(f'百度 API 认证失败: {str(e)}')
    
    def analyze_single(self, text):
        """
        分析单条文本情感
        
        Args:
            text: 待分析文本
            
        Returns:
            dict: {score: float, label: str}
        """
        import requests
        
        if not self.api_key or self.api_key == 'your_api_key':
            raise Exception('未配置百度 API Key')
        
        access_token = self._get_access_token()
        
        url = f'https://aip.baidubce.com/rpc/2.0/nlp/v1/sentiment_classify?access_token={access_token}'
        
        payload = {
            'text': text[:2048]  # 百度 API 限制 2048 字符
        }
        
        headers = {'Content-Type': 'application/json'}
        
        response = requests.post(url, json=payload, headers=headers, timeout=10)
        response.raise_for_status()
        
        result = response.json()
        
        if 'error_code' in result:
            raise Exception(f'百度 API 错误: {result.get("error_msg")}')
        
        items = result.get('items', [])
        if not items:
            return {'score': 0.5, 'label': 'neutral'}
        
        item = items[0]
        sentiment = item.get('sentiment', 2)  # 0:负向, 1:中性, 2:正向
        confidence = item.get('confidence', 0.5)
        
        # 转换为 -1 ~ 1 的分数
        if sentiment == 2:  # 正向
            score = confidence
            label = 'positive'
        elif sentiment == 0:  # 负向
            score = -confidence
            label = 'negative'
        else:  # 中性
            score = 0.0
            label = 'neutral'
        
        return {'score': score, 'label': label}
    
    def analyze_batch(self, texts):
        """
        批量分析文本情感
        
        Args:
            texts: 文本列表
            
        Returns:
            list: [{score, label}, ...]
        """
        results = []
        
        for i, text in enumerate(texts):
            try:
                result = self.analyze_single(text)
                results.append(result)
                
                # 避免触发限流,每 10 条延迟 1 秒
                if (i + 1) % 10 == 0:
                    time.sleep(1)
                    
            except Exception as e:
                logger.error(f'分析第 {i+1} 条文本失败: {e}')
                # 失败时使用默认值
                results.append({'score': 0.0, 'label': 'neutral'})
        
        return results


class SnowNLPSentimentAnalyzer:
    """SnowNLP 本地情感分析引擎"""
    
    def __init__(self):
        try:
            from snownlp import SnowNLP
            self.SnowNLP = SnowNLP
            self.available = True
        except ImportError:
            logger.error('SnowNLP 未安装,请运行: pip install SnowNLP')
            self.available = False
    
    def analyze_single(self, text):
        """
        分析单条文本情感
        
        Args:
            text: 待分析文本
            
        Returns:
            dict: {score: float, label: str}
        """
        if not self.available:
            raise Exception('SnowNLP 未安装')
        
        try:
            s = self.SnowNLP(text)
            # SnowNLP 返回 0~1 的分数,越接近 1 越正面
            score = s.sentiments
            
            # 转换为 -1 ~ 1
            normalized_score = score * 2 - 1
            
            # 判断标签
            if normalized_score > 0.1:
                label = 'positive'
            elif normalized_score < -0.1:
                label = 'negative'
            else:
                label = 'neutral'
            
            return {'score': normalized_score, 'label': label}
            
        except Exception as e:
            logger.error(f'SnowNLP 分析失败: {e}')
            return {'score': 0.0, 'label': 'neutral'}
    
    def analyze_batch(self, texts):
        """
        批量分析文本情感
        
        Args:
            texts: 文本列表
            
        Returns:
            list: [{score, label}, ...]
        """
        results = []
        
        for i, text in enumerate(texts):
            result = self.analyze_single(text)
            results.append(result)
        
        return results


class SentimentAnalyzer:
    """情感分析统一接口"""
    
    def __init__(self):
        self.baidu_analyzer = BaiduSentimentAnalyzer()
        self.snownlp_analyzer = SnowNLPSentimentAnalyzer()
    
    def analyze(self, texts, engine='api'):
        """
        统一情感分析入口
        
        Args:
            texts: 文本列表
            engine: 分析引擎 ('api' 或 'local')
            
        Returns:
            list: [{score, label}, ...]
        """
        try:
            if engine == 'api':
                # 使用百度 API
                return self.baidu_analyzer.analyze_batch(texts)
            else:
                # 使用本地模型
                return self.snownlp_analyzer.analyze_batch(texts)
                
        except Exception as e:
            logger.warning(f'{engine} 引擎分析失败,尝试降级: {e}')
            
            # 自动降级
            if engine == 'api':
                logger.info('降级到本地模型')
                return self.snownlp_analyzer.analyze_batch(texts)
            else:
                logger.info('降级到百度 API')
                return self.baidu_analyzer.analyze_batch(texts)


# 全局实例
sentiment_analyzer = SentimentAnalyzer()
