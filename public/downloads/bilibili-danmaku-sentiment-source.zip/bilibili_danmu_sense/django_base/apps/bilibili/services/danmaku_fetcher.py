"""
B站弹幕爬取服务
"""
import re
import time
import logging
import requests
from lxml import etree
from django.conf import settings

logger = logging.getLogger('apps')


class BilibiliDanmakuFetcher:
    """B站弹幕爬取器"""
    
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Referer': 'https://www.bilibili.com',
        })
    
    def extract_video_id(self, url):
        """
        从URL中提取BV号
        
        Args:
            url: B站视频URL
            
        Returns:
            str: BV号
            
        Raises:
            ValueError: URL格式错误
        """
        # 匹配 BV 号
        bv_pattern = r'(BV[a-zA-Z0-9]+)'
        match = re.search(bv_pattern, url)
        
        if not match:
            raise ValueError('无法从URL中提取BV号,请检查URL格式')
        
        return match.group(1)
    
    def fetch_video_info(self, video_id):
        """
        获取视频信息
        
        Args:
            video_id: BV号
            
        Returns:
            dict: 视频信息 {title, uploader, cid}
            
        Raises:
            Exception: 获取失败
        """
        try:
            url = 'https://api.bilibili.com/x/web-interface/view'
            params = {'bvid': video_id}
            
            response = self.session.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            
            if data.get('code') != 0:
                raise Exception(f'视频不存在或已被删除: {data.get("message")}')
            
            video_data = data['data']
            
            return {
                'title': video_data.get('title', ''),
                'uploader': video_data.get('owner', {}).get('name', ''),
                'cid': video_data.get('cid'),
            }
            
        except requests.RequestException as e:
            logger.error(f'获取视频信息失败: {e}')
            raise Exception(f'网络请求失败: {str(e)}')
        except Exception as e:
            logger.error(f'获取视频信息异常: {e}')
            raise
    
    def fetch_danmaku_list(self, video_id, max_count=3000):
        """
        爬取弹幕列表
        
        Args:
            video_id: BV号
            max_count: 最大弹幕数量(避免数据过大)
            
        Returns:
            list: 弹幕列表 [{content, timestamp}, ...]
            
        Raises:
            Exception: 爬取失败
        """
        try:
            # 1. 获取视频信息得到 cid
            video_info = self.fetch_video_info(video_id)
            cid = video_info['cid']
            
            if not cid:
                raise Exception('无法获取视频CID')
            
            # 2. 获取弹幕XML
            danmaku_url = f'https://comment.bilibili.com/{cid}.xml'
            response = self.session.get(danmaku_url, timeout=15)
            response.raise_for_status()
            
            # 3. 解析XML
            xml_content = response.content.decode('utf-8')
            root = etree.fromstring(xml_content.encode('utf-8'))
            
            danmaku_list = []
            
            for d in root.findall('d'):
                try:
                    # d 标签的 p 属性包含: 时间,模式,字号,颜色,时间戳,来源,池类型
                    p_attr = d.get('p', '').split(',')
                    if len(p_attr) < 5:
                        continue
                    
                    timestamp = float(p_attr[0])  # 弹幕在视频中的时间位置
                    content = d.text.strip() if d.text else ''
                    
                    if not content:
                        continue
                    
                    danmaku_list.append({
                        'content': content,
                        'timestamp': timestamp,
                    })
                    
                    # 限制最大数量
                    if len(danmaku_list) >= max_count:
                        break
                    
                except Exception as e:
                    logger.warning(f'解析单条弹幕失败: {e}')
                    continue
            
            logger.info(f'成功爬取弹幕: {len(danmaku_list)} 条')
            return danmaku_list, video_info
            
        except requests.RequestException as e:
            logger.error(f'爬取弹幕失败: {e}')
            raise Exception(f'网络请求失败: {str(e)}')
        except Exception as e:
            logger.error(f'爬取弹幕异常: {e}')
            raise
    
    def test_connection(self):
        """测试B站API连接"""
        try:
            response = self.session.get('https://api.bilibili.com/x/web-interface/nav', timeout=5)
            return response.status_code == 200
        except Exception:
            return False


# 全局实例
danmaku_fetcher = BilibiliDanmakuFetcher()

