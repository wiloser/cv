"""
数据分析服务
"""
import logging
from collections import Counter

logger = logging.getLogger('apps')


class DataAnalyzer:
    """数据分析器"""
    
    @staticmethod
    def calculate_sentiment_distribution(danmakus):
        """
        计算情感分布
        
        Args:
            danmakus: 弹幕列表 [{sentiment_score, sentiment_label}, ...]
            
        Returns:
            dict: {positive_count, negative_count, neutral_count, avg_score}
        """
        positive_count = 0
        negative_count = 0
        neutral_count = 0
        total_score = 0.0
        
        for d in danmakus:
            score = d.get('sentiment_score', 0.0)
            label = d.get('sentiment_label', 'neutral')
            
            total_score += score
            
            if label == 'positive':
                positive_count += 1
            elif label == 'negative':
                negative_count += 1
            else:
                neutral_count += 1
        
        total_count = len(danmakus)
        avg_score = total_score / total_count if total_count > 0 else 0.0
        
        return {
            'positive_count': positive_count,
            'negative_count': negative_count,
            'neutral_count': neutral_count,
            'avg_sentiment_score': round(avg_score, 4),
        }
    
    @staticmethod
    def extract_keywords(danmakus, top_n=50):
        """
        提取高频关键词
        
        Args:
            danmakus: 弹幕列表 [{content, sentiment_score}, ...]
            top_n: 返回前 N 个关键词
            
        Returns:
            list: [{keyword, frequency, avg_sentiment}, ...]
        """
        try:
            import jieba
        except ImportError:
            logger.error('jieba 未安装')
            return []
        
        # 停用词表
        stop_words = {
            '的', '了', '是', '在', '我', '有', '和', '就', '不', '人', '都', '一', '一个',
            '上', '也', '很', '到', '说', '要', '去', '你', '会', '着', '没有', '看', '好',
            '自己', '这', '他', '她', '它', '们', '那', '些', '啊', '呢', '吧', '吗',
            '哦', '嗯', '哎', '哇', '哈', '哈哈', '哈哈哈', '233', '2333', '23333',
        }
        
        # 统计词频和情感得分
        word_counter = Counter()
        word_sentiments = {}
        
        for d in danmakus:
            content = d.get('content', '')
            score = d.get('sentiment_score', 0.0)
            
            # 分词
            words = jieba.cut(content)
            
            for word in words:
                word = word.strip().lower()
                
                # 过滤停用词和单字
                if word in stop_words or len(word) < 2:
                    continue
                
                # 只保留中文和英文单词
                if not word.isalpha():
                    continue
                
                word_counter[word] += 1
                
                # 累加情感得分
                if word not in word_sentiments:
                    word_sentiments[word] = []
                word_sentiments[word].append(score)
        
        # 获取 top_n 关键词
        keywords = []
        for word, freq in word_counter.most_common(top_n):
            avg_sentiment = sum(word_sentiments[word]) / len(word_sentiments[word])
            keywords.append({
                'keyword': word,
                'frequency': freq,
                'avg_sentiment': round(avg_sentiment, 4),
            })
        
        return keywords
    
    @staticmethod
    def analyze_time_series(danmakus, interval=30):
        """
        时间序列分析
        
        Args:
            danmakus: 弹幕列表 [{timestamp, sentiment_score}, ...]
            interval: 时间段间隔(秒)
            
        Returns:
            list: [{start_time, end_time, danmaku_count, avg_sentiment}, ...]
        """
        if not danmakus:
            return []
        
        # 找到最大时间
        max_time = max(d.get('timestamp', 0) for d in danmakus)
        
        # 生成时间段
        time_slots = []
        start = 0
        
        while start < max_time:
            end = start + interval
            
            # 筛选该时间段的弹幕
            slot_danmakus = [
                d for d in danmakus
                if start <= d.get('timestamp', 0) < end
            ]
            
            danmaku_count = len(slot_danmakus)
            
            if danmaku_count > 0:
                avg_sentiment = sum(d.get('sentiment_score', 0.0) for d in slot_danmakus) / danmaku_count
            else:
                avg_sentiment = 0.0
            
            time_slots.append({
                'start_time': start,
                'end_time': end,
                'danmaku_count': danmaku_count,
                'avg_sentiment': round(avg_sentiment, 4),
            })
            
            start = end
        
        return time_slots


# 全局实例
data_analyzer = DataAnalyzer()
