from rest_framework.pagination import PageNumberPagination
from core.response import APIResponse


class StandardPagination(PageNumberPagination):
    """标准分页工具类"""
    
    # 默认每页数量
    page_size = 10
    # 前端可以通过 page_size 参数指定每页数量
    page_size_query_param = 'page_size'
    # 最大每页数量限制
    max_page_size = 100

    def get_paginated_response(self, data):
        """
        覆盖 DRF 默认分页响应，包裹为统一 APIResponse 格式

        Args:
            data: 序列化后的列表数据

        Returns:
            APIResponse: 统一格式的分页响应
        """
        return APIResponse(data={
            'count': self.page.paginator.count,
            'next': self.get_next_link(),
            'previous': self.get_previous_link(),
            'results': data,
        })
