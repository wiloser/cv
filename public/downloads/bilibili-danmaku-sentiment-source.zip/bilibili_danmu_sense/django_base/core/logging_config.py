"""
日志配置工具类
提供便捷的日志获取方法
"""
import logging


def get_logger(name):
    """
    获取日志记录器
    
    Args:
        name: 日志记录器名称，通常使用 __name__
        
    Returns:
        logging.Logger: 日志记录器实例
        
    Example:
        logger = get_logger(__name__)
        logger.info('这是一条信息')
        logger.error('这是一条错误')
    """
    return logging.getLogger(f'apps.{name}')


class LoggerMixin:
    """日志混入类，为视图提供便捷的日志方法"""

    @property
    def logger(self):
        """获取当前类的日志记录器"""
        if not hasattr(self, '_logger'):
            self._logger = get_logger(self.__class__.__name__)
        return self._logger

    def log_info(self, msg):
        self.logger.info(msg)

    def log_warning(self, msg):
        self.logger.warning(msg)

    def log_error(self, msg):
        self.logger.error(msg)

    def log_debug(self, msg):
        self.logger.debug(msg)
