# B站弹幕情感分析系统 - 后端

基于 Django 4.2 + Django REST Framework 构建的 B 站弹幕情感分析 API 服务。

## 技术栈

- **Django 4.2** - Python Web 框架
- **Django REST Framework 3.14** - RESTful API 框架
- **SimpleJWT 5.3** - JWT 认证
- **PyMySQL 1.1** - MySQL 数据库驱动
- **Redis 5.0** - 缓存服务
- **requests 2.31** - HTTP 客户端
- **SnowNLP 0.12** - 中文情感分析
- **jieba 0.42** - 中文分词
- **baidu-aip 4.16** - 百度 AI SDK
- **lxml 5.1** - XML 解析

## 项目结构

```
django_base/
├── apps/                      # 应用模块
│   ├── users/                 # 用户模块
│   │   ├── models.py          # 用户模型
│   │   ├── serializers.py     # 序列化器
│   │   ├── views.py           # 视图
│   │   ├── urls.py            # 路由
│   │   └── permissions.py     # 权限控制
│   └── bilibili/              # B站分析模块
│       ├── models.py          # 数据模型
│       ├── serializers.py     # 序列化器
│       ├── views.py           # API 视图
│       ├── urls.py            # 路由配置
│       ├── admin.py           # Admin 配置
│       └── services/          # 业务服务
│           ├── danmaku_fetcher.py    # 弹幕爬虫
│           ├── sentiment_analyzer.py # 情感分析
│           └── data_analyzer.py      # 数据分析
├── core/                      # 核心模块
│   ├── response.py            # 统一响应格式
│   ├── exceptions.py          # 异常处理
│   ├── pagination.py          # 分页配置
│   ├── middleware.py          # 中间件
│   └── logging_config.py      # 日志配置
├── mysite/                    # 项目配置
│   ├── settings.py            # 主配置
│   ├── urls.py                # 主路由
│   └── wsgi.py                # WSGI 配置
├── logs/                      # 日志目录
├── manage.py                  # Django 管理脚本
└── requirements.txt           # Python 依赖
```

## 快速开始

### 环境要求

- Python >= 3.8
- MySQL >= 8.0 (可选,默认使用 SQLite)
- Redis (可选)

### 安装依赖

```bash
pip install -r requirements.txt
```

### 配置数据库

#### 使用 SQLite (默认)

无需额外配置,自动创建 `db.sqlite3` 文件。

#### 使用 MySQL

1. 创建数据库:
```sql
CREATE DATABASE bilibili_analysis CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

2. 修改 `mysite/settings.py`:
```python
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'bilibili_analysis',
        'USER': 'root',
        'PASSWORD': 'your_password',
        'HOST': 'localhost',
        'PORT': '3306',
        'OPTIONS': {
            'charset': 'utf8mb4',
        },
    }
}
```

### 数据库迁移

```bash
python manage.py makemigrations
python manage.py migrate
```

### 创建超级用户

```bash
python manage.py createsuperuser
```

### 启动服务

```bash
python manage.py runserver
```

API 服务将在 `http://localhost:8000` 启动。

## API 文档

### 认证接口

- `POST /api/users/register/` - 用户注册
- `POST /api/users/login/` - 用户登录
- `POST /api/users/logout/` - 用户登出
- `GET /api/users/profile/` - 获取个人信息
- `PUT /api/users/profile/` - 更新个人信息
- `POST /api/users/password/change/` - 修改密码

### B站分析接口

- `POST /api/bilibili/analyze/` - 提交分析任务
- `GET /api/bilibili/analysis/list/` - 获取分析历史(分页)
- `GET /api/bilibili/analysis/{id}/` - 获取分析详情
- `GET /api/bilibili/analysis/{id}/danmaku/` - 获取弹幕数据
- `GET /api/bilibili/analysis/{id}/keywords/` - 获取关键词
- `GET /api/bilibili/analysis/{id}/timeline/` - 获取时间序列
- `GET /api/bilibili/hot-videos/` - 获取热门视频
- `DELETE /api/bilibili/analysis/{id}/delete/` - 删除分析记录

### 健康检查

- `GET /api/health/` - 健康检查

## 配置说明

### JWT 配置

```python
SIMPLE_JWT = {
    'ACCESS_TOKEN_LIFETIME': timedelta(hours=2),
    'REFRESH_TOKEN_LIFETIME': timedelta(days=7),
    'ROTATE_REFRESH_TOKENS': True,
    'BLACKLIST_AFTER_ROTATION': True,
}
```

### 百度 AI 配置 (可选)

在 `mysite/settings.py` 中配置:

```python
BAIDU_API_KEY = 'your_api_key'
BAIDU_SECRET_KEY = 'your_secret_key'
```

不配置时将自动降级到 SnowNLP 本地模型。

### CORS 配置

```python
CORS_ALLOWED_ORIGINS = [
    'http://localhost:5173',
    'http://127.0.0.1:5173',
]
```

## 开发规范

1. **应用结构**: 每个功能模块独立应用,放在 `apps/` 目录
2. **API 响应**: 统一使用 `APIResponse` 类返回标准格式
3. **异常处理**: 使用自定义异常处理器
4. **权限控制**: 基于角色的权限管理
5. **日志记录**: 关键操作记录日志

## 数据库模型

### VideoAnalysis (视频分析记录)
- 视频信息、UP主、弹幕总数
- 情感统计 (正面/负面/中性)
- 平均情感得分、分析引擎

### Danmaku (弹幕数据)
- 弹幕内容、时间位置
- 情感得分、情感标签

### KeywordStat (关键词统计)
- 关键词、出现频次
- 该关键词平均情感得分

### DanmakuTimeSlot (时间段统计)
- 时间段起止时间
- 弹幕数、平均情感得分

## 部署

### 生产环境配置

1. 设置 `DEBUG = False`
2. 配置正确的 `SECRET_KEY`
3. 使用 PostgreSQL 或 MySQL
4. 配置 Redis 缓存
5. 使用 Gunicorn 或 uWSGI

### Gunicorn 启动

```bash
gunicorn mysite.wsgi:application --bind 0.0.0.0:8000 --workers 4
```

### Nginx 配置

```nginx
server {
    listen 80;
    server_name your-domain.com;
    
    location /api/ {
        proxy_pass http://localhost:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
    
    location /admin/ {
        proxy_pass http://localhost:8000;
        proxy_set_header Host $host;
    }
    
    location /static/ {
        alias /path/to/static/;
    }
}
```

## 测试

```bash
python manage.py test
```

## 管理后台

访问 `http://localhost:8000/admin/` 使用超级用户账号登录。

## 常见问题

### 1. MySQL 连接失败

确保 MySQL 服务运行,并且创建了数据库。

### 2. 依赖安装失败

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

### 3. 日志文件权限

```bash
mkdir -p logs
chmod 755 logs
```

## 许可证

MIT License
