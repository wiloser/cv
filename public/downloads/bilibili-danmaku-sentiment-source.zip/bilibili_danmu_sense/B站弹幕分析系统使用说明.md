# B站弹幕情感分析系统

基于 Django + React 的 B 站弹幕爬取与情感分析系统,支持双引擎情感分析、多维度数据可视化、历史记录管理等核心功能。

## 功能特性

### 核心功能
- **弹幕爬取**: 输入B站视频URL,自动爬取弹幕数据
- **双引擎情感分析**: 
  - 百度AI API (准确率高,需配置API Key)
  - SnowNLP 本地模型 (无需配置,完全本地运行)
- **多维度数据分析**:
  - 情感极性分析 (正面/负面/中性)
  - 关键词词云提取
  - 时间趋势分析 (弹幕密度 + 情感得分)
  - 时间段统计
- **数据可视化**: 使用 ECharts 生成饼图、词云、折线图等
- **历史记录管理**: 查看、对比、删除历史分析记录
- **热门视频排行**: 展示被分析次数最多的视频

### 业务场景
1. **个人弹幕分析**: 用户自主提交视频分析
2. **历史数据管理**: 查看、对比、删除历史分析
3. **热门视频排行**: 社区维度展示热门分析视频
4. **情感对比分析**: 多视频情感趋势对比 (最多5个)

## 技术栈

### 后端
- Django 4.2 + Django REST Framework
- MySQL / SQLite
- requests (HTTP请求)
- SnowNLP (本地情感分析)
- jieba (中文分词)
- baidu-aip (百度AI SDK)
- lxml (XML解析)

### 前端
- React 19
- React Router 7
- Zustand (状态管理)
- ECharts + echarts-for-react (数据可视化)
- Axios (HTTP客户端)
- React Toastify (消息提示)

## 快速开始

### 1. 后端启动

```bash
cd django_base

# 安装依赖
pip install -r requirements.txt

# 数据库迁移
python manage.py makemigrations
python manage.py migrate

# 创建超级用户 (可选)
python manage.py createsuperuser

# 启动服务
python manage.py runserver
```

后端服务运行在: http://localhost:8000

### 2. 前端启动

```bash
cd react_base

# 安装依赖
npm install

# 启动开发服务器
npm run dev
```

前端服务运行在: http://localhost:5173

### 3. 配置百度AI API (可选)

如需使用百度AI情感分析引擎,需要:

1. 注册百度AI开放平台账号: https://ai.baidu.com/
2. 创建应用,获取 API Key 和 Secret Key
3. 在 `django_base/mysite/settings.py` 中配置:

```python
BAIDU_API_KEY = 'your_api_key'
BAIDU_SECRET_KEY = 'your_secret_key'
```

**注意**: 如果不配置,系统会自动降级到 SnowNLP 本地模型。

## 使用说明

### 分析视频弹幕

1. 注册/登录账号
2. 进入 "B站弹幕分析" 页面
3. 输入视频URL (例如: https://www.bilibili.com/video/BV1xx411c7BF)
4. 选择分析引擎 (百度API 或 本地模型)
5. 点击 "开始分析"
6. 等待分析完成,自动跳转到详情页面

### 查看分析详情

分析详情页包含:
- 视频基本信息
- 情感分布饼图
- 关键词词云
- 时间趋势图 (弹幕密度 + 情感得分)
- 弹幕数据列表

### 对比多个视频

1. 进入 "情感对比分析" 页面
2. 选择 2-5 个历史分析记录
3. 点击 "开始对比"
4. 查看对比图表和数据表格

### 查看热门视频

访问 "热门视频" 页面,查看被分析次数最多的 TOP 20 视频。

## API 接口

### 认证接口
- `POST /api/users/register/` - 用户注册
- `POST /api/users/login/` - 用户登录
- `GET /api/users/profile/` - 获取个人信息

### 弹幕分析接口
- `POST /api/bilibili/analyze/` - 提交分析任务
- `GET /api/bilibili/analysis/list/` - 获取分析历史
- `GET /api/bilibili/analysis/{id}/` - 获取分析详情
- `GET /api/bilibili/analysis/{id}/danmaku/` - 获取弹幕数据
- `GET /api/bilibili/analysis/{id}/keywords/` - 获取关键词
- `GET /api/bilibili/analysis/{id}/timeline/` - 获取时间序列
- `GET /api/bilibili/hot-videos/` - 获取热门视频
- `DELETE /api/bilibili/analysis/{id}/delete/` - 删除分析记录

## 项目结构

```
django_base/
├── apps/
│   ├── users/              # 用户模块
│   └── bilibili/           # B站分析模块
│       ├── models.py       # 数据模型
│       ├── serializers.py  # 序列化器
│       ├── views.py        # API视图
│       ├── urls.py         # 路由配置
│       ├── admin.py        # Admin配置
│       └── services/       # 业务服务
│           ├── danmaku_fetcher.py    # 弹幕爬虫
│           ├── sentiment_analyzer.py # 情感分析
│           └── data_analyzer.py      # 数据分析
└── mysite/
    └── settings.py         # 项目配置

react_base/
├── src/
│   ├── api/
│   │   └── bilibili.js     # API封装
│   ├── views/
│   │   └── bilibili/       # 页面组件
│   │       ├── AnalysisSubmit.jsx      # 分析提交页
│   │       ├── AnalysisDetail.jsx      # 分析详情页
│   │       ├── AnalysisHistory.jsx     # 历史列表页
│   │       ├── HotVideos.jsx           # 热门视频页
│   │       └── SentimentCompare.jsx    # 情感对比页
│   └── router/
│       └── index.jsx       # 路由配置
```

## 数据库模型

### VideoAnalysis (视频分析记录)
- 视频信息、UP主、弹幕总数
- 情感统计 (正面/负面/中性数量)
- 平均情感得分、分析引擎

### Danmaku (弹幕数据)
- 弹幕内容、时间位置
- 情感得分、情感标签

### KeywordStat (关键词统计)
- 关键词、出现频次
- 该关键词平均情感得分

### DanmakuTimeSlot (时间段统计)
- 时间段起止时间
- 弹幕数、平均情感得分

## 注意事项

1. **B站API限制**: 系统已添加合理请求延迟,但仍建议不要频繁爬取
2. **弹幕数量**: 默认最多爬取3000条弹幕,避免数据过大
3. **分析时间**: 取决于弹幕数量,通常需要10-30秒
4. **情感分析API**: 百度AI有免费额度,超出后会自动降级到本地模型
5. **浏览器兼容**: 推荐使用 Chrome、Firefox、Edge 等现代浏览器

## 毕设相关

本系统适合作为本科毕业设计项目,具有以下特点:

### 工作量体现
- ✅ 多业务场景 (5个核心页面)
- ✅ 双引擎情感分析 (API + 本地模型)
- ✅ 多维度数据分析 (4种分析维度)
- ✅ 完整数据流程 (爬虫 → 分析 → 存储 → 可视化)
- ✅ 前后端分离架构

### 论文可写点
- B站API逆向与反爬策略
- 中文情感分析算法对比 (百度AI vs SnowNLP)
- 弹幕数据可视化设计
- 系统架构设计 (前后端分离)
- 性能优化 (批量处理、数据库索引)

## 许可证

MIT License

## 联系方式

如有问题,请提交 Issue 或联系开发者。
