# 云游迹——旅游景点个性化推荐系统

本项目是一个基于 React 与 Django REST Framework 的前后端分离旅游景点推荐系统。系统以用户评分、收藏和浏览行为为基础，通过基于用户的协同过滤（UserCF）生成个性化景点推荐，并在数据稀疏时使用分类偏好与热门景点完成冷启动兜底。

## 项目组成

| 目录 | 内容 |
|---|---|
| `django_base/` | Django REST Framework API、JWT 认证、旅游业务模型、UserCF 推荐算法、测试与演示数据 |
| `react_base/` | React 用户端与管理端、路由、状态管理、API 封装和响应式界面 |
| `docs/` | 系统设计、数据库设计、测试记录、Draw.io 论文图和真实运行截图 |

## 快速运行

先启动后端：

```bash
cd /Users/trees/Documents/bishe/django_base
python3 -m pip install -r requirements.txt
python3 manage.py migrate
python3 manage.py seed_demo
python3 manage.py runserver 127.0.0.1:8181
```

再启动前端：

```bash
cd /Users/trees/Documents/bishe/react_base
npm install
npm run dev -- --host 127.0.0.1
```

访问地址：

- 前端：`http://127.0.0.1:5174`
- 后端健康检查：`http://127.0.0.1:8181/api/health/`

演示账号：

| 角色 | 用户名 | 密码 |
|---|---|---|
| 管理员 | `admin` | `Admin@123456` |
| 普通用户 | `demo` | `Demo@123456` |

`seed_demo` 可重复执行；还会创建 `alice`、`bob`、`carol`、`david` 等用于形成协同评分矩阵的演示用户。

## 质量检查

```bash
cd /Users/trees/Documents/bishe/django_base
python3 manage.py check
python3 manage.py makemigrations --check --dry-run
python3 manage.py test

cd /Users/trees/Documents/bishe/react_base
npm run lint
npm run build
```

2026-07-14 的本机验收结果为：Django 10 项测试全部通过，前端 ESLint 与 Vite 生产构建通过，Draw.io XML 校验通过。

## 论文与验收材料

- [文档总索引](./docs/README.md)
- [系统设计说明](./docs/系统设计说明.md)
- [数据库设计](./docs/数据库设计.md)
- [测试说明](./docs/测试说明.md)
- [四页 Draw.io 论文图](./docs/旅游景点推荐系统架构图.drawio)
- [真实运行截图](./docs/screenshots/README.md)

论文图题、表题、字体与编号最终应以所在学校当年发布的本科毕业论文模板为准。
