from django.urls import include, path
from rest_framework.routers import DefaultRouter

from .views import (
    AttractionViewSet,
    CategoryViewSet,
    DashboardStatsView,
    FavoriteListView,
    RatingListView,
    RecommendationView,
    ViewHistoryListView,
)

router = DefaultRouter()
router.register('categories', CategoryViewSet, basename='category')
router.register('attractions', AttractionViewSet, basename='attraction')

urlpatterns = [
    path('', include(router.urls)),
    path('recommendations/', RecommendationView.as_view(), name='recommendations'),
    path('interactions/favorites/', FavoriteListView.as_view(), name='favorite-list'),
    path('interactions/history/', ViewHistoryListView.as_view(), name='history-list'),
    path('interactions/ratings/', RatingListView.as_view(), name='rating-list'),
    path('dashboard/stats/', DashboardStatsView.as_view(), name='dashboard-stats'),
]

