from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand
from django.db import transaction

from apps.attractions.models import Attraction, Category, Favorite, Rating, RecommendationLog, ViewHistory

User = get_user_model()


CATEGORIES = [
    {'name': '人文古迹', 'description': '历史遗址、博物馆与传统园林', 'icon': 'landmark', 'sort_order': 1},
    {'name': '自然风光', 'description': '山川、湖泊、森林与地貌景观', 'icon': 'mountain', 'sort_order': 2},
    {'name': '城市地标', 'description': '代表城市形象的经典目的地', 'icon': 'building', 'sort_order': 3},
    {'name': '休闲度假', 'description': '海滨、亲子与轻松度假目的地', 'icon': 'umbrella-beach', 'sort_order': 4},
]


ATTRACTIONS = [
    {
        'name': '故宫博物院', 'category': '人文古迹', 'province': '北京市', 'city': '北京',
        'address': '北京市东城区景山前街4号', 'level': '5A', 'price': '60.00',
        'summary': '中国明清两代皇家宫殿，也是世界上规模最大的木质结构古建筑群之一。',
        'description': '故宫以中轴线布局展开，收藏大量珍贵文物，是了解中国古代宫廷建筑、礼制与艺术的重要窗口。建议提前预约，并按中轴线与东西六宫组合游览。',
        'cover_image': '/covers/forbidden-city.svg',
        'tags': ['世界遗产', '博物馆', '古建筑'], 'opening_hours': '08:30-17:00（周一闭馆）',
        'suggested_duration': '4-6小时', 'latitude': '39.916345', 'longitude': '116.397155',
        'is_featured': True, 'view_count': 18560,
    },
    {
        'name': '八达岭长城', 'category': '人文古迹', 'province': '北京市', 'city': '北京',
        'address': '北京市延庆区G6京藏高速58号出口', 'level': '5A', 'price': '40.00',
        'summary': '万里长城向游人开放最早、保存较完整且极具代表性的一段。',
        'description': '八达岭长城地势险峻、城关坚固，四季景色各具特色。可选择徒步或索道登城，旺季建议错峰出行。',
        'cover_image': '/covers/great-wall.svg',
        'tags': ['世界遗产', '长城', '徒步'], 'opening_hours': '06:30-16:30',
        'suggested_duration': '3-5小时', 'latitude': '40.359741', 'longitude': '116.020039',
        'is_featured': True, 'view_count': 16280,
    },
    {
        'name': '上海外滩', 'category': '城市地标', 'province': '上海市', 'city': '上海',
        'address': '上海市黄浦区中山东一路', 'level': '', 'price': '0.00',
        'summary': '沿黄浦江展开的城市名片，可隔江欣赏陆家嘴天际线与万国建筑群。',
        'description': '外滩浓缩了上海近现代城市发展记忆。傍晚至夜间灯光景观尤其出色，可串联南京路、外白渡桥等地游览。',
        'cover_image': 'https://images.unsplash.com/photo-1537531383496-f4749b8032cf?auto=format&fit=crop&w=1200&q=80',
        'tags': ['夜景', '建筑', '免费'], 'opening_hours': '全天开放',
        'suggested_duration': '2-3小时', 'latitude': '31.240010', 'longitude': '121.490180',
        'is_featured': True, 'view_count': 14930,
    },
    {
        'name': '杭州西湖', 'category': '自然风光', 'province': '浙江省', 'city': '杭州',
        'address': '浙江省杭州市西湖区龙井路1号', 'level': '5A', 'price': '0.00',
        'summary': '山水与城市相融的世界文化遗产，以西湖十景和深厚人文积淀闻名。',
        'description': '西湖景区范围广阔，可步行、骑行或乘游船。苏堤春晓、曲院风荷、雷峰夕照等景观随季节和时段呈现不同韵味。',
        'cover_image': '/covers/west-lake.svg',
        'tags': ['世界遗产', '湖泊', '免费'], 'opening_hours': '全天开放',
        'suggested_duration': '半天至1天', 'latitude': '30.242490', 'longitude': '120.140880',
        'is_featured': True, 'view_count': 17120,
    },
    {
        'name': '黄山风景区', 'category': '自然风光', 'province': '安徽省', 'city': '黄山',
        'address': '安徽省黄山市黄山区汤口镇', 'level': '5A', 'price': '190.00',
        'summary': '以奇松、怪石、云海、温泉和冬雪著称的世界自然与文化双遗产。',
        'description': '黄山峰林壮丽，前山险峻、后山秀美。游览需根据体力与天气规划路线，建议至少安排两天并关注索道运营时间。',
        'cover_image': 'https://images.unsplash.com/photo-1576485375217-d6a95e34d043?auto=format&fit=crop&w=1200&q=80',
        'tags': ['世界遗产', '登山', '云海'], 'opening_hours': '06:00-17:30',
        'suggested_duration': '1-2天', 'latitude': '30.131860', 'longitude': '118.168470',
        'is_featured': True, 'view_count': 13840,
    },
    {
        'name': '张家界国家森林公园', 'category': '自然风光', 'province': '湖南省', 'city': '张家界',
        'address': '湖南省张家界市武陵源区', 'level': '5A', 'price': '227.00',
        'summary': '以石英砂岩峰林地貌闻名，数千座奇峰在云雾中形成独特景观。',
        'description': '景区包含袁家界、杨家界、金鞭溪等片区，面积较大。推荐分区游览，并预留摆渡与排队时间。',
        'cover_image': 'https://images.unsplash.com/photo-1528360983277-13d401cdc186?auto=format&fit=crop&w=1200&q=80',
        'tags': ['峰林', '徒步', '世界地质公园'], 'opening_hours': '07:00-18:00',
        'suggested_duration': '2-3天', 'latitude': '29.316670', 'longitude': '110.433330',
        'is_featured': False, 'view_count': 11260,
    },
    {
        'name': '九寨沟风景名胜区', 'category': '自然风光', 'province': '四川省', 'city': '阿坝',
        'address': '四川省阿坝藏族羌族自治州九寨沟县', 'level': '5A', 'price': '190.00',
        'summary': '以彩林、叠瀑、翠海和藏族风情构成的高原湖泊群景观。',
        'description': '九寨沟水景层次丰富，秋季彩林尤为著名。景区海拔较高，应合理安排休息并遵循观光车分流路线。',
        'cover_image': '/covers/jiuzhaigou.svg',
        'tags': ['世界遗产', '湖泊', '彩林'], 'opening_hours': '08:00-17:00',
        'suggested_duration': '1天', 'latitude': '33.260000', 'longitude': '103.918000',
        'is_featured': True, 'view_count': 13070,
    },
    {
        'name': '秦始皇帝陵博物院', 'category': '人文古迹', 'province': '陕西省', 'city': '西安',
        'address': '陕西省西安市临潼区秦陵北路', 'level': '5A', 'price': '120.00',
        'summary': '以兵马俑坑为核心，展现秦代军事、雕塑与统一帝国历史的遗址博物馆。',
        'description': '一号坑规模宏大，二、三号坑与文物陈列补充了秦军阵列和考古信息。建议结合讲解服务深入参观。',
        'cover_image': '/covers/terracotta.svg',
        'tags': ['世界遗产', '考古', '博物馆'], 'opening_hours': '08:30-17:00',
        'suggested_duration': '3-4小时', 'latitude': '34.384100', 'longitude': '109.278500',
        'is_featured': True, 'view_count': 14590,
    },
    {
        'name': '桂林漓江风景区', 'category': '自然风光', 'province': '广西壮族自治区', 'city': '桂林',
        'address': '广西壮族自治区桂林市灵川县磨盘山码头', 'level': '5A', 'price': '210.00',
        'summary': '喀斯特峰林与清澈江水相映成景，构成经典的桂林山水画卷。',
        'description': '乘船由桂林至阳朔可连续欣赏九马画山、黄布倒影等景观，也可组合遇龙河骑行体验田园风光。',
        'cover_image': 'https://images.unsplash.com/photo-1537531383496-f4749b8032cf?auto=format&fit=crop&w=1200&q=80',
        'tags': ['山水', '游船', '喀斯特'], 'opening_hours': '游船班次以当日公告为准',
        'suggested_duration': '4-5小时', 'latitude': '25.140170', 'longitude': '110.434540',
        'is_featured': False, 'view_count': 9870,
    },
    {
        'name': '三亚亚龙湾', 'category': '休闲度假', 'province': '海南省', 'city': '三亚',
        'address': '海南省三亚市吉阳区亚龙湾路', 'level': '4A', 'price': '0.00',
        'summary': '沙质细腻、海水清澈的热带海湾，适合滨海休闲和水上活动。',
        'description': '亚龙湾海岸线舒展，周边度假设施完善。日照较强，户外活动需注意防晒并关注海上安全提示。',
        'cover_image': 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=80',
        'tags': ['海滨', '度假', '亲子'], 'opening_hours': '全天开放',
        'suggested_duration': '半天至1天', 'latitude': '18.233610', 'longitude': '109.638000',
        'is_featured': False, 'view_count': 10380,
    },
    {
        'name': '成都大熊猫繁育研究基地', 'category': '休闲度假', 'province': '四川省', 'city': '成都',
        'address': '四川省成都市成华区熊猫大道1375号', 'level': '4A', 'price': '55.00',
        'summary': '集大熊猫科研繁育、保护教育与公众参观于一体的生态园区。',
        'description': '大熊猫上午较活跃，建议早间入园。园区步行距离较长，可按年龄段和场馆分布规划路线。',
        'cover_image': '/covers/panda.svg',
        'tags': ['大熊猫', '亲子', '科普'], 'opening_hours': '07:30-18:00',
        'suggested_duration': '3-5小时', 'latitude': '30.734540', 'longitude': '104.145650',
        'is_featured': True, 'view_count': 15420,
    },
    {
        'name': '苏州古典园林', 'category': '人文古迹', 'province': '江苏省', 'city': '苏州',
        'address': '江苏省苏州市姑苏区东北街178号（拙政园）', 'level': '5A', 'price': '80.00',
        'summary': '以有限空间营造山水意境，集中体现江南私家园林的造园艺术。',
        'description': '拙政园、留园等园林通过叠山理水、花木建筑与借景形成移步换景的体验，适合慢行品味。',
        'cover_image': '/covers/suzhou-garden.svg',
        'tags': ['世界遗产', '园林', '江南'], 'opening_hours': '07:30-17:30',
        'suggested_duration': '2-4小时', 'latitude': '31.324320', 'longitude': '120.629450',
        'is_featured': False, 'view_count': 8640,
    },
]


USERS = [
    ('admin', 'Admin@123456', 'admin', True, True),
    ('demo', 'Demo@123456', 'user', False, False),
    ('alice', 'Demo@123456', 'user', False, False),
    ('bob', 'Demo@123456', 'user', False, False),
    ('carol', 'Demo@123456', 'user', False, False),
    ('david', 'Demo@123456', 'user', False, False),
]


RATINGS = {
    'demo': {'故宫博物院': 5, '八达岭长城': 5, '上海外滩': 3, '杭州西湖': 4, '黄山风景区': 4},
    'alice': {'故宫博物院': 5, '八达岭长城': 5, '上海外滩': 3, '杭州西湖': 4, '黄山风景区': 4, '秦始皇帝陵博物院': 5, '苏州古典园林': 5, '成都大熊猫繁育研究基地': 4},
    'bob': {'故宫博物院': 3, '杭州西湖': 5, '黄山风景区': 5, '张家界国家森林公园': 5, '九寨沟风景名胜区': 5, '桂林漓江风景区': 5, '三亚亚龙湾': 4},
    'carol': {'故宫博物院': 4, '上海外滩': 5, '杭州西湖': 4, '三亚亚龙湾': 5, '成都大熊猫繁育研究基地': 5, '苏州古典园林': 4},
    'david': {'故宫博物院': 5, '八达岭长城': 4, '杭州西湖': 4, '黄山风景区': 3, '秦始皇帝陵博物院': 5, '苏州古典园林': 5},
}


class Command(BaseCommand):
    help = '创建旅游推荐系统的分类、景点、演示用户和协同过滤评分数据'

    def add_arguments(self, parser):
        parser.add_argument('--reset', action='store_true', help='先清空业务数据及演示账号')

    @transaction.atomic
    def handle(self, *args, **options):
        usernames = [item[0] for item in USERS]
        if options['reset']:
            RecommendationLog.objects.all().delete()
            ViewHistory.objects.all().delete()
            Favorite.objects.all().delete()
            Rating.objects.all().delete()
            Attraction.objects.all().delete()
            Category.objects.all().delete()
            User.objects.filter(username__in=usernames).delete()

        category_map = {}
        for data in CATEGORIES:
            category, _ = Category.objects.update_or_create(
                name=data['name'], defaults={**data, 'is_active': True}
            )
            category_map[category.name] = category

        attraction_map = {}
        for data in ATTRACTIONS:
            defaults = data.copy()
            category_name = defaults.pop('category')
            cover_image = defaults['cover_image']
            defaults['category'] = category_map[category_name]
            defaults['images'] = [cover_image]
            defaults['is_active'] = True
            attraction, _ = Attraction.objects.update_or_create(
                name=defaults.pop('name'),
                province=defaults['province'],
                defaults=defaults,
            )
            attraction_map[attraction.name] = attraction

        user_map = {}
        for username, password, role, is_staff, is_superuser in USERS:
            user, _ = User.objects.update_or_create(
                username=username,
                defaults={
                    'role': role,
                    'is_staff': is_staff,
                    'is_superuser': is_superuser,
                    'is_active': True,
                    'email': f'{username}@travel-demo.local',
                },
            )
            user.set_password(password)
            user.save(update_fields=('password',))
            user_map[username] = user

        for username, ratings in RATINGS.items():
            for attraction_name, score in ratings.items():
                Rating.objects.update_or_create(
                    user=user_map[username],
                    attraction=attraction_map[attraction_name],
                    defaults={'score': score, 'comment': '演示评分数据'},
                )

        demo = user_map['demo']
        for attraction_name in ('故宫博物院', '杭州西湖', '成都大熊猫繁育研究基地'):
            Favorite.objects.get_or_create(user=demo, attraction=attraction_map[attraction_name])
        ViewHistory.objects.update_or_create(
            user=demo,
            attraction=attraction_map['九寨沟风景名胜区'],
            defaults={'view_count': 3},
        )
        ViewHistory.objects.update_or_create(
            user=demo,
            attraction=attraction_map['苏州古典园林'],
            defaults={'view_count': 2},
        )

        # 在重复执行命令后也校准缓存统计字段。
        for attraction in Attraction.objects.all():
            attraction.refresh_rating_stats()
            attraction.refresh_favorite_count()

        self.stdout.write(self.style.SUCCESS(
            f'演示数据创建完成：{Category.objects.count()} 个分类，'
            f'{Attraction.objects.count()} 个景点，{Rating.objects.count()} 条评分。'
        ))
        self.stdout.write('管理员：admin / Admin@123456')
        self.stdout.write('普通用户：demo / Demo@123456（alice、bob、carol、david 同密码）')
