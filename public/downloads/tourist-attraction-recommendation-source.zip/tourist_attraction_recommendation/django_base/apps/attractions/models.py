from decimal import Decimal

from django.conf import settings
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models
from django.db.models import Avg, Count
from django.db.models.signals import post_delete, post_save
from django.dispatch import receiver


class Category(models.Model):
    """景点分类。"""

    name = models.CharField('分类名称', max_length=50, unique=True)
    description = models.CharField('分类说明', max_length=255, blank=True)
    icon = models.CharField('图标', max_length=100, blank=True)
    sort_order = models.PositiveIntegerField('排序', default=0)
    is_active = models.BooleanField('是否启用', default=True)
    created_at = models.DateTimeField('创建时间', auto_now_add=True)
    updated_at = models.DateTimeField('更新时间', auto_now=True)

    class Meta:
        db_table = 'attraction_categories'
        verbose_name = '景点分类'
        verbose_name_plural = verbose_name
        ordering = ('sort_order', 'id')

    def __str__(self):
        return self.name


class Attraction(models.Model):
    """旅游景点基础资料与用于排序的统计字段。"""

    category = models.ForeignKey(
        Category,
        verbose_name='分类',
        related_name='attractions',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
    )
    name = models.CharField('景点名称', max_length=120)
    province = models.CharField('省份/直辖市', max_length=50, db_index=True)
    city = models.CharField('城市', max_length=50, blank=True)
    address = models.CharField('详细地址', max_length=255, blank=True)
    summary = models.CharField('景点简介', max_length=300)
    description = models.TextField('详细介绍', blank=True)
    cover_image = models.URLField('封面图片', max_length=500, blank=True)
    images = models.JSONField('景点图片', default=list, blank=True)
    tags = models.JSONField('标签', default=list, blank=True)
    level = models.CharField('景区等级', max_length=20, blank=True)
    price = models.DecimalField('参考票价', max_digits=10, decimal_places=2, default=0)
    opening_hours = models.CharField('开放时间', max_length=120, blank=True)
    suggested_duration = models.CharField('建议游玩时长', max_length=50, blank=True)
    latitude = models.DecimalField('纬度', max_digits=9, decimal_places=6, null=True, blank=True)
    longitude = models.DecimalField('经度', max_digits=9, decimal_places=6, null=True, blank=True)
    is_featured = models.BooleanField('是否精选', default=False, db_index=True)
    is_active = models.BooleanField('是否上架', default=True, db_index=True)
    average_rating = models.DecimalField(
        '平均评分', max_digits=3, decimal_places=2, default=Decimal('0.00')
    )
    rating_count = models.PositiveIntegerField('评分数', default=0)
    favorite_count = models.PositiveIntegerField('收藏数', default=0)
    view_count = models.PositiveIntegerField('浏览数', default=0)
    created_at = models.DateTimeField('创建时间', auto_now_add=True)
    updated_at = models.DateTimeField('更新时间', auto_now=True)

    class Meta:
        db_table = 'attractions'
        verbose_name = '旅游景点'
        verbose_name_plural = verbose_name
        ordering = ('-is_featured', '-average_rating', '-view_count', 'id')
        indexes = [
            models.Index(fields=('province', 'city'), name='attr_province_city_idx'),
            models.Index(fields=('is_active', 'is_featured'), name='attr_active_feature_idx'),
        ]

    def __str__(self):
        return self.name

    def refresh_rating_stats(self):
        stats = self.ratings.aggregate(average=Avg('score'), count=Count('id'))
        average = Decimal(str(stats['average'] or 0)).quantize(Decimal('0.01'))
        Attraction.objects.filter(pk=self.pk).update(
            average_rating=average,
            rating_count=stats['count'],
        )
        self.average_rating = average
        self.rating_count = stats['count']

    def refresh_favorite_count(self):
        count = self.favorites.count()
        Attraction.objects.filter(pk=self.pk).update(favorite_count=count)
        self.favorite_count = count


class Rating(models.Model):
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        verbose_name='用户',
        related_name='attraction_ratings',
        on_delete=models.CASCADE,
    )
    attraction = models.ForeignKey(
        Attraction,
        verbose_name='景点',
        related_name='ratings',
        on_delete=models.CASCADE,
    )
    score = models.PositiveSmallIntegerField(
        '评分', validators=[MinValueValidator(1), MaxValueValidator(5)]
    )
    comment = models.CharField('简短评价', max_length=500, blank=True)
    created_at = models.DateTimeField('创建时间', auto_now_add=True)
    updated_at = models.DateTimeField('更新时间', auto_now=True)

    class Meta:
        db_table = 'attraction_ratings'
        verbose_name = '景点评分'
        verbose_name_plural = verbose_name
        ordering = ('-updated_at',)
        constraints = [
            models.UniqueConstraint(
                fields=('user', 'attraction'), name='unique_user_attraction_rating'
            ),
            models.CheckConstraint(
                check=models.Q(score__gte=1, score__lte=5), name='rating_score_between_1_and_5'
            ),
        ]
        indexes = [models.Index(fields=('user', 'updated_at'), name='rating_user_time_idx')]

    def __str__(self):
        return f'{self.user} - {self.attraction}: {self.score}'


class Favorite(models.Model):
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        verbose_name='用户',
        related_name='attraction_favorites',
        on_delete=models.CASCADE,
    )
    attraction = models.ForeignKey(
        Attraction,
        verbose_name='景点',
        related_name='favorites',
        on_delete=models.CASCADE,
    )
    created_at = models.DateTimeField('收藏时间', auto_now_add=True)

    class Meta:
        db_table = 'attraction_favorites'
        verbose_name = '景点收藏'
        verbose_name_plural = verbose_name
        ordering = ('-created_at',)
        constraints = [
            models.UniqueConstraint(
                fields=('user', 'attraction'), name='unique_user_attraction_favorite'
            )
        ]

    def __str__(self):
        return f'{self.user} 收藏 {self.attraction}'


class ViewHistory(models.Model):
    """按用户和景点聚合浏览记录，保留最近时间与累计次数。"""

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        verbose_name='用户',
        related_name='attraction_view_history',
        on_delete=models.CASCADE,
    )
    attraction = models.ForeignKey(
        Attraction,
        verbose_name='景点',
        related_name='view_histories',
        on_delete=models.CASCADE,
    )
    view_count = models.PositiveIntegerField('浏览次数', default=1)
    viewed_at = models.DateTimeField('最近浏览时间', auto_now=True)
    created_at = models.DateTimeField('首次浏览时间', auto_now_add=True)

    class Meta:
        db_table = 'attraction_view_history'
        verbose_name = '浏览历史'
        verbose_name_plural = verbose_name
        ordering = ('-viewed_at',)
        constraints = [
            models.UniqueConstraint(
                fields=('user', 'attraction'), name='unique_user_attraction_history'
            )
        ]
        indexes = [models.Index(fields=('user', 'viewed_at'), name='history_user_time_idx')]

    def __str__(self):
        return f'{self.user} 浏览 {self.attraction}'


class RecommendationLog(models.Model):
    ALGORITHM_CHOICES = (
        ('user_cf', '用户协同过滤'),
        ('popular', '热门/精选兜底'),
    )

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        verbose_name='用户',
        related_name='recommendation_logs',
        on_delete=models.CASCADE,
    )
    attraction = models.ForeignKey(
        Attraction,
        verbose_name='景点',
        related_name='recommendation_logs',
        on_delete=models.CASCADE,
    )
    algorithm = models.CharField('算法', max_length=20, choices=ALGORITHM_CHOICES)
    recommendation_score = models.DecimalField('推荐分', max_digits=5, decimal_places=3)
    reason = models.CharField('推荐理由', max_length=255)
    created_at = models.DateTimeField('推荐时间', auto_now_add=True)

    class Meta:
        db_table = 'recommendation_logs'
        verbose_name = '推荐日志'
        verbose_name_plural = verbose_name
        ordering = ('-created_at',)
        indexes = [models.Index(fields=('user', 'created_at'), name='rec_user_time_idx')]


@receiver([post_save, post_delete], sender=Rating)
def update_rating_statistics(sender, instance, **kwargs):
    if Attraction.objects.filter(pk=instance.attraction_id).exists():
        instance.attraction.refresh_rating_stats()


@receiver([post_save, post_delete], sender=Favorite)
def update_favorite_statistics(sender, instance, **kwargs):
    if Attraction.objects.filter(pk=instance.attraction_id).exists():
        instance.attraction.refresh_favorite_count()

