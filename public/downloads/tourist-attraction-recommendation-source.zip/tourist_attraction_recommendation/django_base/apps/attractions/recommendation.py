"""不依赖第三方科学计算库的用户协同过滤推荐。"""

import math
from collections import defaultdict
from dataclasses import dataclass
from statistics import mean

from django.db.models import Case, IntegerField, Value, When

from .models import Attraction, Favorite, Rating, ViewHistory


@dataclass(frozen=True)
class RecommendationResult:
    attraction: Attraction
    score: float
    reason: str
    algorithm: str


def pearson_similarity(left, right):
    """计算两个 ``{景点ID: 评分}`` 向量在共同评分项上的皮尔逊相似度。"""
    common = set(left).intersection(right)
    if len(common) < 2:
        return 0.0

    left_values = [float(left[item]) for item in common]
    right_values = [float(right[item]) for item in common]
    left_mean = mean(left_values)
    right_mean = mean(right_values)
    numerator = sum(
        (left_value - left_mean) * (right_value - right_mean)
        for left_value, right_value in zip(left_values, right_values)
    )
    left_norm = math.sqrt(sum((value - left_mean) ** 2 for value in left_values))
    right_norm = math.sqrt(sum((value - right_mean) ** 2 for value in right_values))
    denominator = left_norm * right_norm
    return numerator / denominator if denominator else 0.0


def _popular_results(
    excluded_ids,
    limit,
    reason='热门与精选景点推荐',
    preferred_category_ids=None,
):
    preferred_category_ids = set(preferred_category_ids or [])
    preference_order = Case(
        When(category_id__in=preferred_category_ids, then=Value(1)),
        default=Value(0),
        output_field=IntegerField(),
    )
    candidates = (
        Attraction.objects.filter(is_active=True)
        .exclude(id__in=excluded_ids)
        .annotate(preference_match=preference_order)
        .order_by(
            '-preference_match', '-is_featured', '-average_rating', '-favorite_count',
            '-view_count', '-rating_count', 'id',
        )[:limit]
    )
    results = []
    for attraction in candidates:
        average = float(attraction.average_rating or 0)
        # 未评分景点仍可凭精选与热度进入兜底列表，输出分始终位于 1~5。
        score = average if attraction.rating_count else 3.5 + (0.25 if attraction.is_featured else 0)
        score += min(math.log1p(attraction.favorite_count + attraction.view_count) / 50, 0.2)
        results.append(
            RecommendationResult(
                attraction=attraction,
                score=round(max(1.0, min(5.0, score)), 3),
                reason=reason,
                algorithm='popular',
            )
        )
    return results


def recommend_for_user(user, limit=10):
    """
    基于用户评分的协同过滤。

    至少有两条评分才建立兴趣向量；数据稀疏、无正相似邻居或结果不足时，
    使用热门/精选景点补齐，保证新用户也能得到稳定结果。
    """
    limit = max(1, min(int(limit), 20))
    rows = list(
        Rating.objects.filter(attraction__is_active=True)
        .values_list('user_id', 'attraction_id', 'score')
    )
    ratings_by_user = defaultdict(dict)
    for user_id, attraction_id, score in rows:
        ratings_by_user[user_id][attraction_id] = float(score)

    target_ratings = ratings_by_user.get(user.id, {})
    rated_ids = set(target_ratings)
    if len(target_ratings) < 2:
        preferred_category_ids = set(
            Attraction.objects.filter(id__in=rated_ids, category_id__isnull=False)
            .values_list('category_id', flat=True)
        )
        preferred_category_ids.update(
            Favorite.objects.filter(user=user, attraction__category_id__isnull=False)
            .values_list('attraction__category_id', flat=True)
        )
        preferred_category_ids.update(
            ViewHistory.objects.filter(user=user, attraction__category_id__isnull=False)
            .values_list('attraction__category_id', flat=True)
        )
        reason = (
            '根据你的收藏与浏览偏好，并结合热门精选景点推荐（冷启动策略）'
            if preferred_category_ids
            else '热门与精选景点推荐（评分数据不足，采用冷启动策略）'
        )
        return _popular_results(
            rated_ids,
            limit,
            reason=reason,
            preferred_category_ids=preferred_category_ids,
        )

    similarities = {}
    for other_user_id, other_ratings in ratings_by_user.items():
        if other_user_id == user.id:
            continue
        similarity = pearson_similarity(target_ratings, other_ratings)
        if similarity > 0:
            similarities[other_user_id] = similarity

    weighted_deviations = defaultdict(float)
    similarity_totals = defaultdict(float)
    contributor_ids = defaultdict(set)
    target_mean = mean(target_ratings.values())

    for other_user_id, similarity in similarities.items():
        other_ratings = ratings_by_user[other_user_id]
        other_mean = mean(other_ratings.values())
        for attraction_id, score in other_ratings.items():
            if attraction_id in rated_ids:
                continue
            weighted_deviations[attraction_id] += similarity * (score - other_mean)
            similarity_totals[attraction_id] += abs(similarity)
            contributor_ids[attraction_id].add(other_user_id)

    candidate_scores = []
    for attraction_id, numerator in weighted_deviations.items():
        denominator = similarity_totals[attraction_id]
        if not denominator:
            continue
        predicted = target_mean + numerator / denominator
        candidate_scores.append((attraction_id, max(1.0, min(5.0, predicted))))
    candidate_scores.sort(key=lambda item: (-item[1], item[0]))

    attraction_map = Attraction.objects.in_bulk(
        [attraction_id for attraction_id, _ in candidate_scores]
    )
    results = []
    for attraction_id, score in candidate_scores:
        attraction = attraction_map.get(attraction_id)
        if not attraction or not attraction.is_active:
            continue
        contributors = len(contributor_ids[attraction_id])
        results.append(
            RecommendationResult(
                attraction=attraction,
                score=round(score, 3),
                reason=f'根据与你兴趣相似的{contributors}位用户的高评分推荐',
                algorithm='user_cf',
            )
        )
        if len(results) == limit:
            return results

    if len(results) < limit:
        excluded = rated_ids.union(result.attraction.id for result in results)
        results.extend(
            _popular_results(excluded, limit - len(results), reason='基于热门度与精选标记补充推荐')
        )
    return results
