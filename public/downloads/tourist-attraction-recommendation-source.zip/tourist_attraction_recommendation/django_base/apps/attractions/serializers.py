from rest_framework import serializers

from .models import Attraction, Category, Favorite, Rating, ViewHistory


class CategorySerializer(serializers.ModelSerializer):
    attraction_count = serializers.SerializerMethodField()

    class Meta:
        model = Category
        fields = (
            'id', 'name', 'description', 'icon', 'sort_order', 'is_active',
            'attraction_count', 'created_at', 'updated_at',
        )
        read_only_fields = ('id', 'attraction_count', 'created_at', 'updated_at')

    def get_attraction_count(self, obj):
        annotated = getattr(obj, 'active_attraction_count', None)
        if annotated is not None:
            return annotated
        return obj.attractions.filter(is_active=True).count()


class CategoryBriefSerializer(serializers.ModelSerializer):
    """景点嵌套使用的轻量分类，避免逐景点统计数量造成 N+1 查询。"""

    class Meta:
        model = Category
        fields = ('id', 'name', 'description', 'icon')


class AttractionSerializer(serializers.ModelSerializer):
    category = CategoryBriefSerializer(read_only=True)
    category_id = serializers.PrimaryKeyRelatedField(
        source='category',
        queryset=Category.objects.all(),
        required=False,
        allow_null=True,
    )
    average_rating = serializers.FloatField(read_only=True)
    price = serializers.FloatField(required=False, min_value=0)
    latitude = serializers.FloatField(required=False, allow_null=True)
    longitude = serializers.FloatField(required=False, allow_null=True)
    is_favorite = serializers.SerializerMethodField()
    user_rating = serializers.SerializerMethodField()

    class Meta:
        model = Attraction
        fields = (
            'id', 'name', 'category', 'category_id', 'province', 'city', 'address',
            'summary', 'description', 'cover_image', 'images', 'tags', 'level',
            'price', 'opening_hours', 'suggested_duration', 'latitude', 'longitude',
            'is_featured', 'is_active', 'average_rating', 'rating_count',
            'favorite_count', 'view_count', 'is_favorite', 'user_rating',
            'created_at', 'updated_at',
        )
        read_only_fields = (
            'id', 'average_rating', 'rating_count', 'favorite_count', 'view_count',
            'is_favorite', 'user_rating', 'created_at', 'updated_at',
        )

    def get_is_favorite(self, obj):
        request = self.context.get('request')
        if not request or not request.user.is_authenticated:
            return False
        prefetched = getattr(obj, '_current_user_favorites', None)
        if prefetched is not None:
            return bool(prefetched)
        return obj.favorites.filter(user=request.user).exists()

    def get_user_rating(self, obj):
        request = self.context.get('request')
        if not request or not request.user.is_authenticated:
            return None
        prefetched = getattr(obj, '_current_user_ratings', None)
        if prefetched is not None:
            return prefetched[0].score if prefetched else None
        return obj.ratings.filter(user=request.user).values_list('score', flat=True).first()

    def validate_images(self, value):
        if not isinstance(value, list) or any(not isinstance(item, str) for item in value):
            raise serializers.ValidationError('景点图片必须是 URL 字符串数组')
        return value

    def validate_tags(self, value):
        if not isinstance(value, list) or any(not isinstance(item, str) for item in value):
            raise serializers.ValidationError('标签必须是字符串数组')
        return value


class RatingInputSerializer(serializers.Serializer):
    score = serializers.IntegerField(min_value=1, max_value=5)
    comment = serializers.CharField(max_length=500, required=False, allow_blank=True, default='')


class RatingSerializer(serializers.ModelSerializer):
    attraction = AttractionSerializer(read_only=True)

    class Meta:
        model = Rating
        fields = ('id', 'attraction', 'score', 'comment', 'created_at', 'updated_at')


class FavoriteSerializer(serializers.ModelSerializer):
    attraction = AttractionSerializer(read_only=True)

    class Meta:
        model = Favorite
        fields = ('id', 'attraction', 'created_at')


class ViewHistorySerializer(serializers.ModelSerializer):
    attraction = AttractionSerializer(read_only=True)

    class Meta:
        model = ViewHistory
        fields = ('id', 'attraction', 'view_count', 'created_at', 'viewed_at')
