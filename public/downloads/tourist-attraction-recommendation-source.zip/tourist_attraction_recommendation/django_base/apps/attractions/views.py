from decimal import Decimal

from django.contrib.auth import get_user_model
from django.db import transaction
from django.db.models import Count, F, Prefetch, Q
from django.utils import timezone
from rest_framework import generics, status, viewsets
from rest_framework.decorators import action
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.views import APIView

from apps.users.permissions import IsAdminUser
from core.response import APIResponse

from .models import Attraction, Category, Favorite, Rating, RecommendationLog, ViewHistory
from .recommendation import recommend_for_user
from .serializers import (
    AttractionSerializer,
    CategorySerializer,
    FavoriteSerializer,
    RatingInputSerializer,
    RatingSerializer,
    ViewHistorySerializer,
)

User = get_user_model()


def attach_user_interaction_state(attractions, user):
    """批量挂载当前用户的收藏和评分状态，供序列化器零额外查询读取。"""
    attractions = list(attractions)
    if not user.is_authenticated or not attractions:
        return attractions
    attraction_ids = [attraction.id for attraction in attractions]
    favorite_ids = set(
        Favorite.objects.filter(user=user, attraction_id__in=attraction_ids)
        .values_list('attraction_id', flat=True)
    )
    rating_map = {
        rating.attraction_id: rating
        for rating in Rating.objects.filter(user=user, attraction_id__in=attraction_ids)
    }
    for attraction in attractions:
        attraction._current_user_favorites = [True] if attraction.id in favorite_ids else []
        attraction._current_user_ratings = (
            [rating_map[attraction.id]] if attraction.id in rating_map else []
        )
    return attractions


def current_user_interaction_prefetches(user):
    """跨 Favorite/History/Rating 列表复用的嵌套景点预取规则。"""
    return (
        Prefetch(
            'attraction__favorites',
            queryset=Favorite.objects.filter(user=user),
            to_attr='_current_user_favorites',
        ),
        Prefetch(
            'attraction__ratings',
            queryset=Rating.objects.filter(user=user),
            to_attr='_current_user_ratings',
        ),
    )


class UnifiedModelViewSet(viewsets.ModelViewSet):
    """为标准 CRUD 操作统一套用 APIResponse。"""

    def list(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.get_queryset())
        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)
        return APIResponse(data=self.get_serializer(queryset, many=True).data)

    def retrieve(self, request, *args, **kwargs):
        return APIResponse(data=self.get_serializer(self.get_object()).data)

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        instance = serializer.save()
        return APIResponse(
            code=status.HTTP_201_CREATED,
            msg='创建成功',
            data=self.get_serializer(instance).data,
        )

    def update(self, request, *args, **kwargs):
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        instance = serializer.save()
        return APIResponse(msg='更新成功', data=self.get_serializer(instance).data)

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        self.perform_destroy(instance)
        return APIResponse(msg='删除成功')


class CategoryViewSet(UnifiedModelViewSet):
    serializer_class = CategorySerializer
    http_method_names = ('get', 'post', 'put', 'patch', 'delete', 'head', 'options')

    def get_permissions(self):
        if self.action in ('list', 'retrieve'):
            return [AllowAny()]
        return [IsAuthenticated(), IsAdminUser()]

    def get_queryset(self):
        queryset = Category.objects.annotate(
            active_attraction_count=Count(
                'attractions', filter=Q(attractions__is_active=True), distinct=True
            )
        )
        user = self.request.user
        if not user.is_authenticated or not getattr(user, 'is_admin', False):
            queryset = queryset.filter(is_active=True)
        return queryset.order_by('sort_order', 'id')


class AttractionViewSet(UnifiedModelViewSet):
    serializer_class = AttractionSerializer
    http_method_names = ('get', 'post', 'put', 'patch', 'delete', 'head', 'options')

    def get_permissions(self):
        if self.action in ('list', 'retrieve', 'featured'):
            return [AllowAny()]
        if self.action in ('favorite', 'rate', 'record_view'):
            return [IsAuthenticated()]
        return [IsAuthenticated(), IsAdminUser()]

    def get_queryset(self):
        queryset = Attraction.objects.select_related('category')
        user = self.request.user
        if user.is_authenticated:
            queryset = queryset.prefetch_related(
                Prefetch(
                    'favorites',
                    queryset=Favorite.objects.filter(user=user),
                    to_attr='_current_user_favorites',
                ),
                Prefetch(
                    'ratings',
                    queryset=Rating.objects.filter(user=user),
                    to_attr='_current_user_ratings',
                ),
            )
        if not user.is_authenticated or not getattr(user, 'is_admin', False):
            queryset = queryset.filter(is_active=True)

        params = self.request.query_params
        search = params.get('search', '').strip()
        if search:
            queryset = queryset.filter(
                Q(name__icontains=search)
                | Q(summary__icontains=search)
                | Q(description__icontains=search)
                | Q(address__icontains=search)
                | Q(city__icontains=search)
                | Q(province__icontains=search)
            )
        province = params.get('province', '').strip()
        if province:
            queryset = queryset.filter(province__iexact=province)
        city = params.get('city', '').strip()
        if city:
            queryset = queryset.filter(city__iexact=city)
        category = params.get('category', '').strip()
        if category:
            if category.isdigit():
                queryset = queryset.filter(category_id=int(category))
            else:
                queryset = queryset.filter(category__name__iexact=category)
        featured = params.get('featured', '').lower()
        if featured in ('1', 'true', 'yes'):
            queryset = queryset.filter(is_featured=True)

        ordering = {
            'popular': ('-view_count', '-favorite_count', '-average_rating'),
            'rating': ('-average_rating', '-rating_count', '-view_count'),
            'price_asc': ('price', '-average_rating'),
            'price_desc': ('-price', '-average_rating'),
            'newest': ('-created_at',),
        }.get(params.get('sort'))
        if ordering:
            return queryset.order_by(*ordering, 'id')
        return queryset.order_by('-is_featured', '-average_rating', '-view_count', 'id')

    @action(detail=False, methods=('get',), url_path='featured')
    def featured(self, request):
        queryset = self.filter_queryset(self.get_queryset()).filter(is_featured=True)[:8]
        return APIResponse(data=self.get_serializer(queryset, many=True).data)

    @action(detail=True, methods=('post', 'delete'), url_path='favorite')
    def favorite(self, request, pk=None):
        attraction = self.get_object()
        if request.method == 'DELETE':
            deleted, _ = Favorite.objects.filter(
                user=request.user, attraction=attraction
            ).delete()
            attraction.refresh_from_db(fields=('favorite_count',))
            return APIResponse(
                msg='已取消收藏' if deleted else '尚未收藏',
                data={'is_favorite': False, 'favorite_count': attraction.favorite_count},
            )

        favorite, created = Favorite.objects.get_or_create(
            user=request.user, attraction=attraction
        )
        attraction.refresh_from_db(fields=('favorite_count',))
        return APIResponse(
            code=status.HTTP_201_CREATED if created else status.HTTP_200_OK,
            msg='收藏成功' if created else '已收藏',
            data={
                'id': favorite.id,
                'is_favorite': True,
                'favorite_count': attraction.favorite_count,
            },
        )

    @action(detail=True, methods=('post',), url_path='rate')
    def rate(self, request, pk=None):
        attraction = self.get_object()
        input_serializer = RatingInputSerializer(data=request.data)
        input_serializer.is_valid(raise_exception=True)
        rating, created = Rating.objects.update_or_create(
            user=request.user,
            attraction=attraction,
            defaults=input_serializer.validated_data,
        )
        rating.refresh_from_db()
        return APIResponse(
            code=status.HTTP_201_CREATED if created else status.HTTP_200_OK,
            msg='评分成功' if created else '评分已更新',
            data=RatingSerializer(rating, context=self.get_serializer_context()).data,
        )

    @action(detail=True, methods=('post',), url_path='view')
    def record_view(self, request, pk=None):
        attraction = self.get_object()
        with transaction.atomic():
            history, created = ViewHistory.objects.get_or_create(
                user=request.user,
                attraction=attraction,
                defaults={'view_count': 1},
            )
            if not created:
                ViewHistory.objects.filter(pk=history.pk).update(
                    view_count=F('view_count') + 1,
                    viewed_at=timezone.now(),
                )
                history.refresh_from_db()
            Attraction.objects.filter(pk=attraction.pk).update(view_count=F('view_count') + 1)
        attraction.refresh_from_db(fields=('view_count',))
        return APIResponse(
            msg='浏览记录已保存',
            data={
                'history_id': history.id,
                'history_view_count': history.view_count,
                'view_count': attraction.view_count,
            },
        )


class RecommendationView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request):
        try:
            limit = int(request.query_params.get('limit', 10))
        except (TypeError, ValueError):
            limit = 10
        results = recommend_for_user(request.user, limit=limit)
        attach_user_interaction_state(
            [result.attraction for result in results],
            request.user,
        )
        data = []
        logs = []
        for result in results:
            item = dict(AttractionSerializer(result.attraction, context={'request': request}).data)
            item.update(
                recommendation_score=result.score,
                reason=result.reason,
                algorithm=result.algorithm,
            )
            data.append(item)
            logs.append(
                RecommendationLog(
                    user=request.user,
                    attraction=result.attraction,
                    algorithm=result.algorithm,
                    recommendation_score=Decimal(str(result.score)),
                    reason=result.reason,
                )
            )
        if logs:
            RecommendationLog.objects.bulk_create(logs)
        return APIResponse(data=data)


class FavoriteListView(generics.ListAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = FavoriteSerializer

    def get_queryset(self):
        return Favorite.objects.filter(
            user=self.request.user, attraction__is_active=True
        ).select_related('attraction__category').prefetch_related(
            *current_user_interaction_prefetches(self.request.user)
        )


class ViewHistoryListView(generics.ListAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = ViewHistorySerializer

    def get_queryset(self):
        return ViewHistory.objects.filter(
            user=self.request.user, attraction__is_active=True
        ).select_related('attraction__category').prefetch_related(
            *current_user_interaction_prefetches(self.request.user)
        )


class RatingListView(generics.ListAPIView):
    permission_classes = (IsAuthenticated,)
    serializer_class = RatingSerializer

    def get_queryset(self):
        return Rating.objects.filter(
            user=self.request.user, attraction__is_active=True
        ).select_related('attraction__category').prefetch_related(
            *current_user_interaction_prefetches(self.request.user)
        )


class DashboardStatsView(APIView):
    permission_classes = (IsAuthenticated, IsAdminUser)

    def get(self, request):
        top_attractions = attach_user_interaction_state(
            Attraction.objects.select_related('category').order_by(
                '-view_count', '-favorite_count', '-average_rating'
            )[:5],
            request.user,
        )
        recent_ratings = Rating.objects.select_related('user', 'attraction').order_by('-updated_at')[:5]
        return APIResponse(data={
            'user_count': User.objects.count(),
            'attraction_count': Attraction.objects.count(),
            'active_attraction_count': Attraction.objects.filter(is_active=True).count(),
            'category_count': Category.objects.count(),
            'rating_count': Rating.objects.count(),
            'favorite_count': Favorite.objects.count(),
            'history_count': ViewHistory.objects.count(),
            'recommendation_count': RecommendationLog.objects.count(),
            'top_attractions': AttractionSerializer(
                top_attractions, many=True, context={'request': request}
            ).data,
            'recent_ratings': [
                {
                    'id': rating.id,
                    'username': rating.user.username,
                    'attraction_id': rating.attraction_id,
                    'attraction_name': rating.attraction.name,
                    'score': rating.score,
                    'comment': rating.comment,
                    'updated_at': rating.updated_at,
                }
                for rating in recent_ratings
            ],
        })
