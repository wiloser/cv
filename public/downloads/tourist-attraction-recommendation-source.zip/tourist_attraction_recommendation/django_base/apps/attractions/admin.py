from django.contrib import admin

from .models import Attraction, Category, Favorite, Rating, RecommendationLog, ViewHistory


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'sort_order', 'is_active', 'updated_at')
    list_editable = ('sort_order', 'is_active')
    search_fields = ('name', 'description')


@admin.register(Attraction)
class AttractionAdmin(admin.ModelAdmin):
    list_display = (
        'name', 'province', 'city', 'category', 'average_rating', 'rating_count',
        'view_count', 'is_featured', 'is_active',
    )
    list_filter = ('is_active', 'is_featured', 'province', 'category')
    search_fields = ('name', 'summary', 'description', 'address')
    list_editable = ('is_featured', 'is_active')
    readonly_fields = ('average_rating', 'rating_count', 'favorite_count', 'view_count')


@admin.register(Rating)
class RatingAdmin(admin.ModelAdmin):
    list_display = ('user', 'attraction', 'score', 'updated_at')
    list_filter = ('score', 'updated_at')
    search_fields = ('user__username', 'attraction__name', 'comment')


@admin.register(Favorite)
class FavoriteAdmin(admin.ModelAdmin):
    list_display = ('user', 'attraction', 'created_at')
    search_fields = ('user__username', 'attraction__name')


@admin.register(ViewHistory)
class ViewHistoryAdmin(admin.ModelAdmin):
    list_display = ('user', 'attraction', 'view_count', 'viewed_at')
    search_fields = ('user__username', 'attraction__name')


@admin.register(RecommendationLog)
class RecommendationLogAdmin(admin.ModelAdmin):
    list_display = ('user', 'attraction', 'algorithm', 'recommendation_score', 'created_at')
    list_filter = ('algorithm', 'created_at')
    search_fields = ('user__username', 'attraction__name', 'reason')

