from django.contrib.auth import get_user_model
from rest_framework.test import APITestCase

from apps.attractions.models import Attraction, Category, Favorite, Rating, ViewHistory

User = get_user_model()


class AttractionAPITests(APITestCase):
    @classmethod
    def setUpTestData(cls):
        cls.category = Category.objects.create(
            name='自然风光', description='自然景观', is_active=True
        )
        cls.other_category = Category.objects.create(
            name='人文古迹', description='人文景观', sort_order=2, is_active=True
        )
        cls.attraction = Attraction.objects.create(
            name='测试西湖', category=cls.category, province='浙江省', city='杭州',
            summary='湖泊自然景点', description='用于接口测试', price=0,
            is_featured=True, view_count=20,
        )
        cls.second = Attraction.objects.create(
            name='测试古城', category=cls.other_category, province='陕西省', city='西安',
            summary='历史文化景点', description='用于推荐测试', price=80,
            view_count=10,
        )
        cls.third = Attraction.objects.create(
            name='测试园林', category=cls.other_category, province='江苏省', city='苏州',
            summary='古典园林', description='用于推荐测试', price=40,
            is_featured=True, view_count=15,
        )
        cls.user = User.objects.create_user('api-user', password='Test@123456')
        cls.neighbor = User.objects.create_user('api-neighbor', password='Test@123456')
        cls.admin = User.objects.create_superuser('api-admin', password='Admin@123456')

        Rating.objects.create(user=cls.user, attraction=cls.attraction, score=5)
        Rating.objects.create(user=cls.user, attraction=cls.second, score=3)
        Rating.objects.create(user=cls.neighbor, attraction=cls.attraction, score=5)
        Rating.objects.create(user=cls.neighbor, attraction=cls.second, score=3)
        Rating.objects.create(user=cls.neighbor, attraction=cls.third, score=5)

    def assert_envelope(self, response, expected_code=200):
        self.assertEqual(response.status_code, expected_code)
        self.assertEqual(response.data['code'], expected_code)
        self.assertIn('msg', response.data)
        self.assertIn('data', response.data)

    def test_public_list_detail_featured_and_filters(self):
        category_response = self.client.get('/api/categories/')
        self.assert_envelope(category_response)
        self.assertEqual(category_response.data['data']['count'], 2)

        list_response = self.client.get('/api/attractions/?search=西湖&province=浙江省')
        self.assert_envelope(list_response)
        self.assertEqual(list_response.data['data']['count'], 1)
        self.assertEqual(list_response.data['data']['results'][0]['name'], '测试西湖')

        detail_response = self.client.get(f'/api/attractions/{self.attraction.id}/')
        self.assert_envelope(detail_response)
        self.assertEqual(detail_response.data['data']['category']['name'], '自然风光')
        self.assertFalse(detail_response.data['data']['is_favorite'])

        featured_response = self.client.get('/api/attractions/featured/')
        self.assert_envelope(featured_response)
        self.assertEqual(len(featured_response.data['data']), 2)

    def test_protected_endpoints_rely_on_drf_permissions(self):
        response = self.client.get('/api/recommendations/')
        self.assert_envelope(response, 401)
        response = self.client.get('/api/interactions/favorites/')
        self.assert_envelope(response, 401)

    def test_favorite_rate_view_and_interaction_lists(self):
        self.client.force_authenticate(self.user)

        favorite_response = self.client.post(f'/api/attractions/{self.third.id}/favorite/')
        self.assert_envelope(favorite_response, 201)
        self.assertTrue(Favorite.objects.filter(user=self.user, attraction=self.third).exists())
        self.third.refresh_from_db()
        self.assertEqual(self.third.favorite_count, 1)

        rate_response = self.client.post(
            f'/api/attractions/{self.third.id}/rate/',
            {'score': 4, 'comment': '值得游览'},
            format='json',
        )
        self.assert_envelope(rate_response, 201)
        self.assertEqual(rate_response.data['data']['score'], 4)
        rate_update = self.client.post(
            f'/api/attractions/{self.third.id}/rate/', {'score': 5}, format='json'
        )
        self.assert_envelope(rate_update)
        self.assertEqual(Rating.objects.get(user=self.user, attraction=self.third).score, 5)

        first_view = self.client.post(f'/api/attractions/{self.third.id}/view/')
        second_view = self.client.post(f'/api/attractions/{self.third.id}/view/')
        self.assert_envelope(first_view)
        self.assert_envelope(second_view)
        history = ViewHistory.objects.get(user=self.user, attraction=self.third)
        self.assertEqual(history.view_count, 2)

        for endpoint in ('favorites', 'history', 'ratings'):
            response = self.client.get(f'/api/interactions/{endpoint}/')
            self.assert_envelope(response)
            self.assertGreaterEqual(response.data['data']['count'], 1)

        delete_response = self.client.delete(f'/api/attractions/{self.third.id}/favorite/')
        self.assert_envelope(delete_response)
        self.assertFalse(Favorite.objects.filter(user=self.user, attraction=self.third).exists())

    def test_recommendation_response_contains_score_reason_and_algorithm(self):
        self.client.force_authenticate(self.user)
        response = self.client.get('/api/recommendations/?limit=3')
        self.assert_envelope(response)
        self.assertTrue(response.data['data'])
        item = response.data['data'][0]
        self.assertEqual(item['id'], self.third.id)
        self.assertIn('recommendation_score', item)
        self.assertIn('reason', item)
        self.assertEqual(item['algorithm'], 'user_cf')

    def test_admin_crud_dashboard_and_user_list_pagination(self):
        self.client.force_authenticate(self.admin)
        category_response = self.client.post(
            '/api/categories/',
            {'name': '休闲度假', 'description': '度假景点', 'sort_order': 3},
            format='json',
        )
        self.assert_envelope(category_response, 201)
        category_id = category_response.data['data']['id']

        attraction_response = self.client.post(
            '/api/attractions/',
            {
                'name': '测试海湾', 'category_id': category_id, 'province': '海南省',
                'city': '三亚', 'summary': '滨海度假景点', 'description': '管理员创建测试',
                'price': 0, 'tags': ['海滨'], 'images': [], 'is_active': True,
            },
            format='json',
        )
        self.assert_envelope(attraction_response, 201)
        attraction_id = attraction_response.data['data']['id']
        update_response = self.client.patch(
            f'/api/attractions/{attraction_id}/', {'is_featured': True}, format='json'
        )
        self.assert_envelope(update_response)
        self.assertTrue(update_response.data['data']['is_featured'])

        dashboard_response = self.client.get('/api/dashboard/stats/')
        self.assert_envelope(dashboard_response)
        self.assertEqual(dashboard_response.data['data']['attraction_count'], 4)

        for index in range(4):
            User.objects.create_user(f'page-user-{index}', password='Test@123456')
        user_list_response = self.client.get('/api/users/list/?page_size=2')
        self.assert_envelope(user_list_response)
        self.assertEqual(len(user_list_response.data['data']['results']), 2)

        delete_response = self.client.delete(f'/api/attractions/{attraction_id}/')
        self.assert_envelope(delete_response)
        self.assertFalse(Attraction.objects.filter(id=attraction_id).exists())

    def test_non_admin_cannot_mutate_catalog(self):
        self.client.force_authenticate(self.user)
        response = self.client.post(
            '/api/categories/', {'name': '无权限分类'}, format='json'
        )
        self.assert_envelope(response, 403)

