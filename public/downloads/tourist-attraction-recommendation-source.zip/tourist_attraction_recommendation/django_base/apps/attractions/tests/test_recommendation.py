from django.contrib.auth import get_user_model
from django.test import TestCase

from apps.attractions.models import Attraction, Category, Favorite, Rating
from apps.attractions.recommendation import pearson_similarity, recommend_for_user

User = get_user_model()


class RecommendationAlgorithmTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.history_category = Category.objects.create(name='人文古迹')
        cls.nature_category = Category.objects.create(name='自然风光')
        cls.attractions = [
            Attraction.objects.create(
                name=f'景点{i}',
                category=cls.history_category if i < 3 else cls.nature_category,
                province='测试省',
                summary=f'景点{i}简介',
                is_featured=i in (0, 3),
                view_count=100 - i,
            )
            for i in range(5)
        ]
        cls.target = User.objects.create_user('target', password='Test@123456')
        cls.neighbor = User.objects.create_user('neighbor', password='Test@123456')
        cls.inverse = User.objects.create_user('inverse', password='Test@123456')

        Rating.objects.create(user=cls.target, attraction=cls.attractions[0], score=5)
        Rating.objects.create(user=cls.target, attraction=cls.attractions[1], score=2)
        Rating.objects.create(user=cls.neighbor, attraction=cls.attractions[0], score=5)
        Rating.objects.create(user=cls.neighbor, attraction=cls.attractions[1], score=2)
        Rating.objects.create(user=cls.neighbor, attraction=cls.attractions[2], score=5)
        Rating.objects.create(user=cls.inverse, attraction=cls.attractions[0], score=1)
        Rating.objects.create(user=cls.inverse, attraction=cls.attractions[1], score=5)
        Rating.objects.create(user=cls.inverse, attraction=cls.attractions[4], score=5)

    def test_pearson_similarity_uses_common_ratings(self):
        self.assertAlmostEqual(pearson_similarity({1: 5, 2: 2}, {1: 4, 2: 1}), 1.0)
        self.assertAlmostEqual(pearson_similarity({1: 5, 2: 2}, {1: 1, 2: 5}), -1.0)
        self.assertEqual(pearson_similarity({1: 5}, {1: 5}), 0.0)

    def test_collaborative_filtering_excludes_rated_items_and_has_reason(self):
        results = recommend_for_user(self.target, limit=3)
        result_ids = [result.attraction.id for result in results]
        self.assertNotIn(self.attractions[0].id, result_ids)
        self.assertNotIn(self.attractions[1].id, result_ids)
        self.assertEqual(results[0].attraction, self.attractions[2])
        self.assertEqual(results[0].algorithm, 'user_cf')
        self.assertIn('兴趣相似', results[0].reason)
        self.assertTrue(1 <= results[0].score <= 5)

    def test_cold_start_uses_favorite_category_then_popularity(self):
        newcomer = User.objects.create_user('newcomer', password='Test@123456')
        Favorite.objects.create(user=newcomer, attraction=self.attractions[3])
        results = recommend_for_user(newcomer, limit=2)
        self.assertTrue(results)
        self.assertEqual(results[0].attraction.category, self.nature_category)
        self.assertEqual(results[0].algorithm, 'popular')
        self.assertIn('冷启动', results[0].reason)
        self.assertIn('收藏与浏览偏好', results[0].reason)

