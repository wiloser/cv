from django.contrib.auth import get_user_model
from rest_framework.test import APITestCase


User = get_user_model()


class AuthenticationFlowTests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(
            username='auth-user',
            password='Test@123456',
        )

    def test_login_updates_last_login_and_logout_revokes_refresh_token(self):
        login = self.client.post(
            '/api/users/login/',
            {'username': 'auth-user', 'password': 'Test@123456'},
            format='json',
        )
        self.assertEqual(login.status_code, 200)
        access = login.data['data']['access']
        refresh = login.data['data']['refresh']

        self.user.refresh_from_db()
        self.assertIsNotNone(self.user.last_login)

        self.client.credentials(HTTP_AUTHORIZATION=f'Bearer {access}')
        logout = self.client.post(
            '/api/users/logout/',
            {'refresh': refresh},
            format='json',
        )
        self.assertEqual(logout.status_code, 200)

        self.client.credentials()
        refresh_response = self.client.post(
            '/api/users/token/refresh/',
            {'refresh': refresh},
            format='json',
        )
        self.assertEqual(refresh_response.status_code, 401)
