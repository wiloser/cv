from rest_framework import serializers
from django.contrib.auth import get_user_model
from django.contrib.auth.password_validation import validate_password

User = get_user_model()


class UserSerializer(serializers.ModelSerializer):
    """用户序列化器"""
    
    class Meta:
        model = User
        fields = ('id', 'username', 'email', 'phone', 'role', 'date_joined', 'last_login')
        read_only_fields = ('id', 'username', 'date_joined', 'last_login', 'role')
        extra_kwargs = {
            'phone': {'validators': []},  # 移除默认的唯一性验证器
        }
    
    def validate_phone(self, value):
        """验证手机号唯一性（排除当前用户）"""
        # 将空字符串转换为 None
        if value == '':
            value = None
        
        if value:
            user = self.context['request'].user
            if User.objects.filter(phone=value).exclude(id=user.id).exists():
                raise serializers.ValidationError("该手机号已被注册")
        return value


class RegisterSerializer(serializers.ModelSerializer):
    """注册序列化器"""
    
    password = serializers.CharField(write_only=True, required=True, validators=[validate_password])
    password_confirm = serializers.CharField(write_only=True, required=True)
    
    class Meta:
        model = User
        fields = ('username', 'email', 'password', 'password_confirm', 'phone')
    
    def validate(self, attrs):
        """验证密码是否一致"""
        if attrs['password'] != attrs['password_confirm']:
            raise serializers.ValidationError({"password": "两次密码不一致"})
        return attrs
    
    def create(self, validated_data):
        """创建用户"""
        validated_data.pop('password_confirm')
        user = User.objects.create_user(
            username=validated_data['username'],
            email=validated_data.get('email'),
            password=validated_data['password'],
            phone=validated_data.get('phone'),
        )
        return user


class LoginSerializer(serializers.Serializer):
    """登录序列化器"""
    
    username = serializers.CharField(required=True)
    password = serializers.CharField(required=True, write_only=True)


class ChangePasswordSerializer(serializers.Serializer):
    """修改密码序列化器"""
    
    old_password = serializers.CharField(required=True, write_only=True)
    new_password = serializers.CharField(required=True, write_only=True, validators=[validate_password])
    new_password_confirm = serializers.CharField(required=True, write_only=True)
    
    def validate(self, attrs):
        """验证新密码是否一致"""
        if attrs['new_password'] != attrs['new_password_confirm']:
            raise serializers.ValidationError({"new_password": "两次密码不一致"})
        return attrs
