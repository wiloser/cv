from rest_framework.permissions import BasePermission


class IsAdminUser(BasePermission):
    """
    自定义管理员权限
    
    只有 role='admin' 的用户才能访问
    """
    
    def has_permission(self, request, view):
        return request.user and request.user.is_authenticated and request.user.is_admin


class IsOwnerOrAdmin(BasePermission):
    """
    对象级权限
    
    只有资源所有者或管理员才能访问
    """
    
    def has_object_permission(self, request, view, obj):
        # 管理员可以访问所有资源
        if request.user.is_admin:
            return True
        # 资源所有者可以访问
        return obj == request.user
