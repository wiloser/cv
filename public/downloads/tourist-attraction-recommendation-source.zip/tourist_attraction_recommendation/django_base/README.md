# 云游迹后端

该目录提供旅游景点个性化推荐系统的 RESTful API，采用 Django 4.2、Django REST Framework 3.14、SimpleJWT 和 Django ORM 实现。

## 已实现业务

- 注册、登录、退出、Token 刷新与黑名单撤销；
- 景点分类、景点列表、搜索、筛选、排序、详情和精选景点；
- 评分评论、收藏、聚合浏览历史和个人交互列表；
- 基于 Pearson 相似度的 UserCF 推荐，以及分类偏好/热门景点冷启动兜底；
- 管理员分类与景点 CRUD、用户列表和数据看板；
- 开发环境 SQLite、生产环境 MySQL 配置。

## 启动

```bash
python3 -m pip install -r requirements.txt
python3 manage.py migrate
python3 manage.py seed_demo
python3 manage.py runserver 127.0.0.1:8181
```

健康检查：`GET http://127.0.0.1:8181/api/health/`

## 主要 API

| 方法 | 路径 | 权限 | 说明 |
|---|---|---|---|
| POST | `/api/users/register/` | 公开 | 用户注册 |
| POST | `/api/users/login/` | 公开 | 用户登录 |
| POST | `/api/users/logout/` | 登录 | 退出并撤销 Refresh Token |
| GET | `/api/categories/` | 公开 | 分类列表 |
| GET | `/api/attractions/` | 公开 | 景点检索与分页 |
| GET | `/api/attractions/{id}/` | 公开 | 景点详情 |
| POST | `/api/attractions/{id}/rate/` | 登录 | 新增或更新评分 |
| POST/DELETE | `/api/attractions/{id}/favorite/` | 登录 | 收藏或取消收藏 |
| GET | `/api/recommendations/` | 登录 | 个性化推荐 |
| GET | `/api/dashboard/stats/` | 管理员 | 数据概览 |

完整接口与字段说明见 [`../docs/系统设计说明.md`](../docs/系统设计说明.md)。

## 测试

```bash
python3 manage.py check
python3 manage.py makemigrations --check --dry-run
python3 manage.py test
```

生产环境必须设置强随机 `DJANGO_SECRET_KEY`，并通过环境变量配置 MySQL 连接信息。
