"""
全局中间件
"""
import logging
from django.conf import settings
from django.http import JsonResponse
from django.utils.deprecation import MiddlewareMixin
logger = logging.getLogger('apps')


class LoginRequiredMiddleware(MiddlewareMixin):
    """
    全局登录拦截中间件
    
    功能：
    仅处理已携带的 Bearer Token（例如黑名单校验）。是否需要登录由各个
    DRF 视图的 permission_classes 决定，避免中间件误伤公开景点等接口。
    """
    
    def process_request(self, request):
        # 跳过白名单路径
        path = request.path_info
        if self._is_white_list(path):
            return None
        
        # 跳过非 API 请求（如静态文件、admin等）
        if not path.startswith('/api/'):
            return None
        
        # 未携带 Token 时继续交给 DRF 权限系统。公开接口可正常访问，受保护
        # 接口仍会由 IsAuthenticated 返回统一的 401 响应。
        auth_header = request.META.get('HTTP_AUTHORIZATION', '')
        if not auth_header:
            return None
        
        # 提取 token
        try:
            token_type, token = auth_header.split(' ', 1)
            if token_type.lower() != 'bearer':
                return self._unauthorized_response('无效的认证类型')
        except ValueError:
            return self._unauthorized_response('无效的认证格式')
        
        # 检查 token 是否在黑名单中
        if self._is_token_blacklisted(token):
            return self._unauthorized_response('Token 已失效')
        
        return None
    
    def _is_white_list(self, path):
        """检查路径是否在白名单中"""
        white_list = getattr(settings, 'LOGIN_WHITE_LIST', [])
        for white_path in white_list:
            if path.startswith(white_path):
                return True
        return False
    
    def _is_token_blacklisted(self, token):
        """
        检查 token 是否在 Redis 黑名单中
        
        Args:
            token: JWT token
            
        Returns:
            bool: 是否在黑名单中
        """
        try:
            # 使用 Django cache 框架
            from django.core.cache import cache
            blacklist_key = f'token_blacklist:{token}'
            return cache.get(blacklist_key) is not None
        except Exception as e:
            logger.error(f'检查 token 黑名单失败: {e}')
            return False
    
    def _unauthorized_response(self, message):
        """返回未授权响应"""
        return JsonResponse({
            'code': 401,
            'msg': 'unauthorized',
            'data': {'detail': message}
        }, status=401)
