from rest_framework.response import Response


class APIResponse(Response):
    """统一 API 响应格式"""
    
    def __init__(self, code=200, msg='success', data=None, **kwargs):
        """
        初始化统一响应
        
        Args:
            code: 状态码，默认 200
            msg: 消息，默认 success
            data: 数据，默认 None
            **kwargs: 其他 Response 参数
        """
        response_data = {
            'code': code,
            'msg': msg,
            'data': data,
        }
        
        # HTTP Status 与业务 code 保持一致（业界标准）
        if 'status' not in kwargs:
            kwargs['status'] = code
        
        super().__init__(data=response_data, **kwargs)
