import logging
from rest_framework.views import exception_handler
from rest_framework.exceptions import (
    AuthenticationFailed,
    NotAuthenticated,
    PermissionDenied,
    ValidationError,
    NotFound,
    MethodNotAllowed,
)
from core.response import APIResponse

logger = logging.getLogger('apps')


def custom_exception_handler(exc, context):
    """
    全局异常处理
    
    Args:
        exc: 异常对象
        context: 异常上下文
        
    Returns:
        APIResponse: 统一格式的异常响应
    """
    # 调用 DRF 默认异常处理
    response = exception_handler(exc, context)
    
    # 获取请求信息用于日志
    request = context.get('request')
    view = context.get('view')
    view_name = view.__class__.__name__ if view else 'Unknown'
    
    if response is not None:
        # DRF 已处理的异常
        error_data = response.data
        
        # 记录错误日志
        if response.status_code >= 500:
            logger.error(
                f'Server Error: {exc} | View: {view_name} | Path: {request.path if request else "Unknown"}'
            )
        elif response.status_code >= 400:
            logger.warning(
                f'Client Error: {exc} | View: {view_name} | Path: {request.path if request else "Unknown"}'
            )
        
        # 提取第一个错误信息作为 msg
        first_error = None
        if isinstance(error_data, dict):
            for field, errors in error_data.items():
                if errors:
                    first_error = errors[0] if isinstance(errors, list) else str(errors)
                    break
        elif isinstance(error_data, list):
            first_error = error_data[0]
        
        # 统一错误响应格式
        return APIResponse(
            code=response.status_code,
            msg=first_error or '请求失败',
            data=None
        )
    else:
        # 未处理的异常（如数据库错误等）
        logger.error(
            f'Unhandled Exception: {exc} | View: {view_name} | Path: {request.path if request else "Unknown"}'
        )
        
        return APIResponse(
            code=500,
            msg='服务器内部错误，请稍后重试',
            data=None
        )
