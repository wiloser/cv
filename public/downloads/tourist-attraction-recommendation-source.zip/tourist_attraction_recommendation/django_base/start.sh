#!/bin/bash

# Django 开发服务器启动脚本

echo "======================================"
echo "  Django RESTful 后端框架启动脚本"
echo "======================================"
echo ""
echo "启动开发服务器..."
echo "访问地址: http://127.0.0.1:8181"
echo "API 文档: http://127.0.0.1:8181/api/health/"
echo ""

# 启动服务器
python3 manage.py runserver 8181
