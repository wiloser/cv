import pymysql


# Django 的 MySQL 后端默认导入 MySQLdb；项目使用纯 Python 的 PyMySQL，
# 在此提供兼容桥接，确保 production settings 能按 requirements.txt 启动。
pymysql.install_as_MySQLdb()
