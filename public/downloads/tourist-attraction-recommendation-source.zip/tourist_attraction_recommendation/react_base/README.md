# 云游迹前端

该目录是旅游景点个性化推荐系统的 React 用户端与管理端，使用 Vite、React Router、Axios 和 Zustand 构建。

## 页面

- 首页、景点列表与景点详情；
- 登录、注册、个人资料和密码修改；
- 个性化推荐、我的收藏、浏览足迹；
- 管理员数据看板、景点管理和用户管理；
- 加载、空数据、错误提示与响应式布局。

## 启动

```bash
npm install
npm run dev -- --host 127.0.0.1
```

开发地址为 `http://127.0.0.1:5174`。Vite 会将 `/api` 代理至 `http://127.0.0.1:8181`，因此请先启动 Django 后端。

## 检查与构建

```bash
npm run lint
npm run build
```

生产构建输出到 `dist/`，该目录不提交版本控制。
