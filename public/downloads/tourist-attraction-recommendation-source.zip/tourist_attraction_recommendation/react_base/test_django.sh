#!/bin/bash

# React + Django 联调测试脚本

BASE_URL="http://127.0.0.1:8181"

echo "======================================"
echo "  React + Django 联调测试"
echo "======================================"
echo ""

# 1. 测试健康检查
echo "1. 测试健康检查..."
HEALTH=$(curl -s ${BASE_URL}/api/health/)
echo "响应: ${HEALTH}"
echo ""

# 2. 测试注册（新用户）
echo "2. 测试用户注册..."
REGISTER_RESPONSE=$(curl -s -X POST ${BASE_URL}/api/users/register/ \
  -H "Content-Type: application/json" \
  -d '{
    "username": "react_test_user",
    "password": "TestPass123",
    "password_confirm": "TestPass123"
  }')
echo "响应: ${REGISTER_RESPONSE}"
echo ""

# 3. 测试登录
echo "3. 测试用户登录..."
LOGIN_RESPONSE=$(curl -s -X POST ${BASE_URL}/api/users/login/ \
  -H "Content-Type: application/json" \
  -d '{
    "username": "trees1681",
    "password": "123456"
  }')
echo "响应: ${LOGIN_RESPONSE}"
echo ""

# 提取 token
ACCESS_TOKEN=$(echo ${LOGIN_RESPONSE} | python3 -c "import sys, json; print(json.load(sys.stdin).get('data', {}).get('access', ''))" 2>/dev/null)

if [ -n "${ACCESS_TOKEN}" ]; then
  echo "✅ 登录成功，获取到 Access Token"
  echo ""
  
  # 4. 测试获取用户信息
  echo "4. 测试获取用户信息..."
  PROFILE_RESPONSE=$(curl -s ${BASE_URL}/api/users/profile/ \
    -H "Authorization: Bearer ${ACCESS_TOKEN}")
  echo "响应: ${PROFILE_RESPONSE}"
  echo ""
  
  # 5. 测试修改用户信息
  echo "5. 测试修改用户信息..."
  UPDATE_RESPONSE=$(curl -s -X PUT ${BASE_URL}/api/users/profile/ \
    -H "Content-Type: application/json" \
    -H "Authorization: Bearer ${ACCESS_TOKEN}" \
    -d '{
      "email": "react_test@example.com"
    }')
  echo "响应: ${UPDATE_RESPONSE}"
  echo ""
  
  # 6. 测试修改密码
  echo "6. 测试修改密码..."
  CHANGE_PWD_RESPONSE=$(curl -s -X POST ${BASE_URL}/api/users/change_password/ \
    -H "Content-Type: application/json" \
    -H "Authorization: Bearer ${ACCESS_TOKEN}" \
    -d '{
      "old_password": "123456",
      "new_password": "NewPass123",
      "new_password_confirm": "NewPass123"
    }')
  echo "响应: ${CHANGE_PWD_RESPONSE}"
  echo ""
  
  # 7. 测试 Token 刷新
  REFRESH_TOKEN=$(echo ${LOGIN_RESPONSE} | python3 -c "import sys, json; print(json.load(sys.stdin).get('data', {}).get('refresh', ''))" 2>/dev/null)
  
  if [ -n "${REFRESH_TOKEN}" ]; then
    echo "7. 测试 Token 刷新..."
    REFRESH_RESPONSE=$(curl -s -X POST ${BASE_URL}/api/users/token/refresh/ \
      -H "Content-Type: application/json" \
      -d "{\"refresh\": \"${REFRESH_TOKEN}\"}")
    echo "响应: ${REFRESH_RESPONSE}"
    echo ""
  fi
  
  # 8. 测试管理员接口（如果用户是管理员）
  echo "8. 测试管理员接口（获取用户列表）..."
  ADMIN_RESPONSE=$(curl -s ${BASE_URL}/api/users/ \
    -H "Authorization: Bearer ${ACCESS_TOKEN}")
  echo "响应: ${ADMIN_RESPONSE}"
  echo ""
else
  echo "❌ 登录失败，跳过需要认证的测试"
  echo ""
fi

echo "======================================"
echo "  测试完成！"
echo "======================================"
echo ""
echo "React 前端地址: http://localhost:5174"
echo "Django 后端地址: ${BASE_URL}"
echo ""
echo "请检查上述 API 响应是否正常"
