import { useState } from 'react'
import Icon from './Icon'

export default function AttractionImage({ src, alt, className = '' }) {
  const [failed, setFailed] = useState(false)

  if (!src || failed) {
    return (
      <div className={`image-placeholder ${className}`} role="img" aria-label={`${alt || '景点'}暂无图片`}>
        <span className="placeholder-sun" />
        <span className="placeholder-mountain one" />
        <span className="placeholder-mountain two" />
        <span className="placeholder-label"><Icon name="map" size={16}/>{alt || '云游迹'}</span>
      </div>
    )
  }

  return <img className={className} src={src} alt={alt} loading="lazy" onError={() => setFailed(true)} />
}
