import Icon from './Icon'

export function Loading({ label = '正在加载精彩内容…', cards = false }) {
  if (cards) {
    return <div className="card-grid skeleton-grid">{[1, 2, 3, 4].map((item) => <div className="skeleton-card" key={item}><span/><div><i/><i/><i/></div></div>)}</div>
  }
  return <div className="loading-state"><span className="loader"/><p>{label}</p></div>
}

export function EmptyState({ icon = 'compass', title = '暂时没有内容', description = '换个条件试试，或稍后再来看看。', action }) {
  return (
    <div className="empty-state">
      <div className="empty-icon"><Icon name={icon} size={30}/></div>
      <h3>{title}</h3><p>{description}</p>{action}
    </div>
  )
}

export function PageIntro({ eyebrow, title, description, children }) {
  return (
    <section className="page-intro">
      <div className="shell page-intro-inner">
        <div>{eyebrow && <p className="eyebrow">{eyebrow}</p>}<h1>{title}</h1>{description && <p>{description}</p>}</div>
        {children && <div className="page-intro-action">{children}</div>}
      </div>
    </section>
  )
}
