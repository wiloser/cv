import { Link } from 'react-router-dom'
import Icon from './Icon'

export default function AuthShell({ title, subtitle, alternateText, alternateLink, alternateLabel, children, register = false }) {
  return (
    <section className="auth-section">
      <div className="shell auth-grid">
        <div className="auth-visual">
          <div className="auth-visual-copy"><span className="auth-kicker"><Icon name="compass" size={17}/>云游迹</span><h1>{register ? '从一次心动开始，\n收藏你的万里山河' : '山河辽阔，\n总有风景与你契合'}</h1><p>{register ? '加入云游迹，让每一次浏览与评分，都成为下一次惊喜出发的线索。' : '登录后获取专属目的地推荐，延续你的收藏与浏览足迹。'}</p></div>
          <div className="auth-landscape" aria-hidden="true"><i className="auth-sun"/><i className="auth-cloud one"/><i className="auth-cloud two"/><i className="auth-hill one"/><i className="auth-hill two"/><i className="auth-hill three"/><i className="auth-road"/><span className="auth-pin"><Icon name="map" size={19}/></span></div>
          <div className="auth-quote"><Icon name="sparkles" size={18}/><span>“旅行的意义，是在陌生的风景里遇见新的自己。”</span></div>
        </div>
        <div className="auth-card">
          <div className="auth-card-head"><p className="eyebrow">WELCOME TO CLOUD JOURNEY</p><h2>{title}</h2><p>{subtitle}</p></div>
          {children}
          <p className="auth-alternate">{alternateText}<Link to={alternateLink}>{alternateLabel}</Link></p>
          <div className="auth-security"><Icon name="shield" size={15}/>你的账户信息将被安全保护</div>
        </div>
      </div>
    </section>
  )
}
