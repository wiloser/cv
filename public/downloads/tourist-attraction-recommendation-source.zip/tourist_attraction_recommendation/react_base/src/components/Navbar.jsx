import { useState } from 'react'
import { Link, NavLink, useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'
import { useUserStore } from '../stores/userStore'
import Icon from './Icon'

const navItems = [
  { to: '/', label: '首页', end: true },
  { to: '/attractions', label: '发现景点' },
  { to: '/recommendations', label: '为你推荐', icon: 'sparkles' },
]

export default function Navbar() {
  const navigate = useNavigate()
  const { isAuthenticated, user, logout } = useUserStore()
  const [mobileOpen, setMobileOpen] = useState(false)
  const [userOpen, setUserOpen] = useState(false)
  const isAdmin = user?.role === 'admin' || user?.is_staff

  const handleLogout = async () => {
    await logout()
    setMobileOpen(false)
    setUserOpen(false)
    toast.success('已安全退出登录')
    navigate('/')
  }

  const closeMenus = () => {
    setMobileOpen(false)
    setUserOpen(false)
  }

  return (
    <header className="site-header">
      <div className="navbar shell">
        <Link className="brand" to="/" onClick={closeMenus} aria-label="云游迹首页">
          <span className="brand-mark">
            <svg viewBox="0 0 36 36" aria-hidden="true"><path d="M5 25.5 13.5 14l5.1 6.5 4.2-5.5L31 25.5H5Z"/><path className="brand-route" d="M7 28c6.2-2.4 13.6-2.4 22 0"/></svg>
          </span>
          <span><strong>云游迹</strong><small>发现更懂你的风景</small></span>
        </Link>

        <nav className="desktop-nav" aria-label="主导航">
          {navItems.map((item) => (
            <NavLink key={item.to} to={item.to} end={item.end} className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
              {item.icon && <Icon name={item.icon} size={16} />}{item.label}
            </NavLink>
          ))}
        </nav>

        <div className="nav-actions">
          {isAuthenticated ? (
            <div className="user-menu-wrap">
              <button className="user-trigger" onClick={() => setUserOpen(!userOpen)} aria-expanded={userOpen}>
                <span className="avatar">{(user?.username || '旅')[0].toUpperCase()}</span>
                <span className="user-trigger-name">{user?.username || '旅行者'}</span>
                <Icon name="chevron" size={15} className={userOpen ? 'rotate-90' : ''} />
              </button>
              {userOpen && (
                <div className="user-dropdown">
                  <div className="dropdown-head"><span>你好，{user?.username || '旅行者'}</span><small>{isAdmin ? '系统管理员' : '普通用户'}</small></div>
                  <Link to="/favorites" onClick={closeMenus}><Icon name="heart" size={17}/>我的收藏</Link>
                  <Link to="/history" onClick={closeMenus}><Icon name="history" size={17}/>浏览足迹</Link>
                  <Link to="/profile" onClick={closeMenus}><Icon name="user" size={17}/>个人中心</Link>
                  {isAdmin && <Link to="/admin" onClick={closeMenus}><Icon name="chart" size={17}/>管理中心</Link>}
                  <button onClick={handleLogout}><Icon name="logout" size={17}/>退出登录</button>
                </div>
              )}
            </div>
          ) : (
            <>
              <Link className="nav-login" to="/login">登录</Link>
              <Link className="button button-primary button-sm" to="/register">免费注册</Link>
            </>
          )}
          <button className="mobile-toggle" onClick={() => setMobileOpen(!mobileOpen)} aria-label="展开导航">
            <Icon name={mobileOpen ? 'close' : 'menu'} size={24}/>
          </button>
        </div>
      </div>

      {mobileOpen && (
        <div className="mobile-menu">
          <div className="shell">
            {navItems.map((item) => <NavLink key={item.to} to={item.to} end={item.end} onClick={closeMenus}>{item.label}</NavLink>)}
            {isAuthenticated ? (
              <>
                <Link to="/favorites" onClick={closeMenus}>我的收藏</Link>
                <Link to="/history" onClick={closeMenus}>浏览足迹</Link>
                <Link to="/profile" onClick={closeMenus}>个人中心</Link>
                {isAdmin && <Link to="/admin" onClick={closeMenus}>管理中心</Link>}
                <button onClick={handleLogout}>退出登录</button>
              </>
            ) : (
              <div className="mobile-auth"><Link to="/login" onClick={closeMenus}>登录</Link><Link to="/register" onClick={closeMenus}>注册账号</Link></div>
            )}
          </div>
        </div>
      )}
    </header>
  )
}
