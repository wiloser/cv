import { Link } from 'react-router-dom'
import AttractionImage from './AttractionImage'
import Icon from './Icon'
import { formatCount, formatPrice, locationOf, normalizeAttraction } from '../utils/attraction'

export default function AttractionCard({ item, reason = '', compact = false }) {
  const attraction = normalizeAttraction(item)

  return (
    <article className={`attraction-card ${compact ? 'compact' : ''}`}>
      <Link className="card-image" to={`/attractions/${attraction.id}`}>
        <AttractionImage src={attraction.cover} alt={attraction.name}/>
        <div className="card-badges">
          {attraction.level && <span className="badge badge-gold">{attraction.level}</span>}
          {attraction.category && <span className="badge badge-glass">{attraction.category}</span>}
        </div>
      </Link>
      <div className="card-body">
        {(reason || attraction.reason) && <p className="recommend-reason"><Icon name="sparkles" size={14}/>{reason || attraction.reason}</p>}
        <div className="card-title-row">
          <h3><Link to={`/attractions/${attraction.id}`}>{attraction.name}</Link></h3>
          <span className="card-rating"><Icon name="star" size={15} fill="currentColor"/>{attraction.rating ? attraction.rating.toFixed(1) : '暂无'}</span>
        </div>
        <p className="card-location"><Icon name="map" size={15}/>{locationOf(attraction)}</p>
        {!compact && <p className="card-description">{attraction.shortDescription || '一处值得探索的人气目的地，等待你发现它的独特魅力。'}</p>}
        <div className="card-meta">
          <span className="card-price">{formatPrice(attraction.price)}{attraction.price ? <small> 起</small> : null}</span>
          <span><Icon name="eye" size={15}/>{formatCount(attraction.viewCount)} 人浏览</span>
        </div>
      </div>
    </article>
  )
}
