import { Link } from 'react-router-dom'

export default function Footer() {
  return (
    <footer className="site-footer">
      <div className="shell footer-grid">
        <div className="footer-brand">
          <div className="brand brand-light">
            <span className="brand-mark"><svg viewBox="0 0 36 36"><path d="M5 25.5 13.5 14l5.1 6.5 4.2-5.5L31 25.5H5Z"/><path className="brand-route" d="M7 28c6.2-2.4 13.6-2.4 22 0"/></svg></span>
            <span><strong>云游迹</strong><small>旅游景点个性化推荐系统</small></span>
          </div>
          <p>让数据读懂偏好，让每一次出发都有惊喜。</p>
        </div>
        <div><h4>探索发现</h4><Link to="/attractions">全部景点</Link><Link to="/recommendations">个性推荐</Link></div>
        <div><h4>我的旅程</h4><Link to="/favorites">我的收藏</Link><Link to="/history">浏览足迹</Link></div>
        <div><h4>系统说明</h4><p>基于协同过滤算法</p><p>数据仅供学习研究使用</p></div>
      </div>
      <div className="shell footer-bottom"><span>© 2026 云游迹 · 本科毕业设计</span><span>React + Django REST Framework</span></div>
    </footer>
  )
}
