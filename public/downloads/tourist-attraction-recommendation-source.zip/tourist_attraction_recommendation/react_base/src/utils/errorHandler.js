/**
 * 错误处理工具函数
 */

export function getErrorMessage(error, defaultMsg = '操作失败') {
  const errorData = error.response?.data
  
  // 1. 字段级错误（Django DRF 格式）
  if (errorData?.data && typeof errorData.data === 'object' && !Array.isArray(errorData.data)) {
    const firstField = Object.keys(errorData.data)[0]
    if (firstField) {
      const fieldErrors = errorData.data[firstField]
      if (Array.isArray(fieldErrors)) {
        return fieldErrors[0]
      }
      if (typeof fieldErrors === 'string') {
        return fieldErrors
      }
    }
  }
  
  // 2. 统一响应格式 (msg: Django/Flask/Gin)
  if (errorData?.msg) {
    return errorData.msg
  }
  
  // 3. 统一响应格式 (message: Spring Boot)
  if (errorData?.message) {
    return errorData.message
  }
  
  // 4. Detail 格式
  if (errorData?.detail) {
    return errorData.detail
  }
  
  // 5. Network error
  if (error.message === 'Network Error') {
    return '网络连接失败，请检查网络'
  }
  
  // 6. Timeout
  if (error.code === 'ECONNABORTED') {
    return '请求超时，请稍后重试'
  }
  
  // 7. 默认消息
  return defaultMsg
}

export function getFieldErrors(error) {
  const errorData = error.response?.data
  
  if (errorData?.data && typeof errorData.data === 'object' && !Array.isArray(errorData.data)) {
    const errors = {}
    Object.keys(errorData.data).forEach(field => {
      const fieldErrors = errorData.data[field]
      errors[field] = Array.isArray(fieldErrors) ? fieldErrors[0] : fieldErrors
    })
    return errors
  }
  
  return {}
}

export default {
  getErrorMessage,
  getFieldErrors,
}
