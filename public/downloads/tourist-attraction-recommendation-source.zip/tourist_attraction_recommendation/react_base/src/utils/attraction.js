export function unwrapData(payload) {
  if (payload && typeof payload === 'object' && 'data' in payload) return payload.data
  return payload
}

export function unwrapList(payload) {
  const data = unwrapData(payload)
  if (Array.isArray(data)) return data
  if (Array.isArray(data?.results)) return data.results
  if (Array.isArray(data?.items)) return data.items
  if (Array.isArray(data?.list)) return data.list
  if (Array.isArray(data?.attractions)) return data.attractions
  if (Array.isArray(data?.recommendations)) return data.recommendations
  if (Array.isArray(data?.favorites)) return data.favorites
  if (Array.isArray(data?.history)) return data.history
  if (Array.isArray(data?.ratings)) return data.ratings
  return []
}

function textOf(value) {
  if (value && typeof value === 'object') return value.name || value.title || value.label || ''
  return value ?? ''
}

export function normalizeAttraction(record = {}) {
  const item = record.attraction || record.scenic_spot || record.item || record
  const location = item.location || item.address || ''
  const category = textOf(item.category || item.category_name || item.type)

  return {
    ...item,
    id: item.id ?? item.pk ?? record.attraction_id,
    name: item.name || item.title || item.attraction_name || '未命名景点',
    cover: item.cover_url || item.cover_image || item.image_url || item.image || item.cover || '',
    province: textOf(item.province || item.province_name),
    city: textOf(item.city || item.city_name),
    addressText: textOf(location),
    category,
    rating: Number(item.average_rating ?? item.avg_rating ?? item.rating ?? item.score ?? 0),
    ratingCount: Number(item.rating_count ?? item.reviews_count ?? item.review_count ?? 0),
    viewCount: Number(item.view_count ?? item.views ?? item.popularity ?? 0),
    favoriteCount: Number(item.favorite_count ?? item.favorites_count ?? 0),
    price: item.ticket_price ?? item.price ?? item.admission_price,
    level: item.level || item.grade || item.scenic_level || '',
    shortDescription: item.summary || item.short_description || item.description || item.introduction || '',
    description: item.description || item.introduction || item.summary || '',
    tags: Array.isArray(item.tags) ? item.tags.map(textOf).filter(Boolean) : [],
    isFavorite: Boolean(item.is_favorite ?? item.favorited ?? record.is_favorite),
    reason: record.reason || record.recommendation_reason || item.recommendation_reason || '',
    interactedAt: record.viewed_at || record.created_at || record.updated_at || '',
    userScore: Number(record.score ?? record.rating ?? item.user_rating ?? 0),
  }
}

export function locationOf(attraction) {
  return [attraction.province, attraction.city].filter(Boolean).join(' · ') || attraction.addressText || '位置待完善'
}

export function formatCount(value) {
  const number = Number(value || 0)
  if (number >= 10000) return `${(number / 10000).toFixed(number >= 100000 ? 0 : 1)}万`
  return String(number)
}

export function formatPrice(value) {
  if (value === null || value === undefined || value === '' || Number(value) === 0) return '免费开放'
  const number = Number(value)
  return Number.isNaN(number) ? String(value) : `¥${number % 1 === 0 ? number : number.toFixed(1)}`
}
