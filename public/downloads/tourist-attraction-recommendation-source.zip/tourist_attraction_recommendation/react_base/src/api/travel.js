import api from './index'

export const travelApi = {
  getCategories: (params = {}) => api.get('/api/categories/', { params }),
  getAttractions: (params = {}) => api.get('/api/attractions/', { params }),
  getFeatured: () => api.get('/api/attractions/featured/'),
  getAttraction: (id) => api.get(`/api/attractions/${id}/`),
  recordView: (id) => api.post(`/api/attractions/${id}/view/`),
  addFavorite: (id) => api.post(`/api/attractions/${id}/favorite/`),
  removeFavorite: (id) => api.delete(`/api/attractions/${id}/favorite/`),
  rateAttraction: (id, data) => api.post(`/api/attractions/${id}/rate/`, data),
  getRecommendations: (params = {}) => api.get('/api/recommendations/', { params }),
  getFavorites: (params = {}) => api.get('/api/interactions/favorites/', { params }),
  getHistory: (params = {}) => api.get('/api/interactions/history/', { params }),
  getRatings: (params = {}) => api.get('/api/interactions/ratings/', { params }),
  getDashboardStats: () => api.get('/api/dashboard/stats/'),
}

export default travelApi
