import { BrowserRouter, Navigate, Route, Routes, useLocation } from 'react-router-dom'
import { useUserStore } from '../stores/userStore'
import Layout from '../components/Layout'
import Home from '../views/Home'
import Attractions from '../views/Attractions'
import AttractionDetail from '../views/AttractionDetail'
import Recommendations from '../views/Recommendations'
import Login from '../views/auth/Login'
import Register from '../views/auth/Register'
import Profile from '../views/user/Profile'
import ChangePassword from '../views/user/ChangePassword'
import CollectionPage from '../views/user/CollectionPage'
import Dashboard from '../views/admin/Dashboard'
import AttractionManage from '../views/admin/AttractionManage'
import UserList from '../views/admin/UserList'
import NotFound from '../views/NotFound'

function ProtectedRoute({ children, adminOnly = false }) {
  const location = useLocation()
  const isAuthenticated = useUserStore((state) => state.isAuthenticated)
  const user = useUserStore((state) => state.user)
  const isAdmin = user?.role === 'admin' || user?.is_staff === true

  if (!isAuthenticated) return <Navigate to={`/login?redirect=${encodeURIComponent(location.pathname + location.search)}`} replace />
  if (adminOnly && !isAdmin) return <Navigate to="/" replace />
  return children
}

export default function AppRouter() {
  return (
    <BrowserRouter basename={import.meta.env.BASE_URL}>
      <Routes>
        <Route element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="attractions" element={<Attractions />} />
          <Route path="attractions/:id" element={<AttractionDetail />} />
          <Route path="login" element={<Login />} />
          <Route path="register" element={<Register />} />
          <Route path="recommendations" element={<ProtectedRoute><Recommendations /></ProtectedRoute>} />
          <Route path="favorites" element={<ProtectedRoute><CollectionPage type="favorites" /></ProtectedRoute>} />
          <Route path="history" element={<ProtectedRoute><CollectionPage type="history" /></ProtectedRoute>} />
          <Route path="profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />
          <Route path="change-password" element={<ProtectedRoute><ChangePassword /></ProtectedRoute>} />
          <Route path="admin" element={<ProtectedRoute adminOnly><Dashboard /></ProtectedRoute>} />
          <Route path="admin/attractions" element={<ProtectedRoute adminOnly><AttractionManage /></ProtectedRoute>} />
          <Route path="admin/users" element={<ProtectedRoute adminOnly><UserList /></ProtectedRoute>} />
          <Route path="*" element={<NotFound />} />
        </Route>
      </Routes>
    </BrowserRouter>
  )
}
