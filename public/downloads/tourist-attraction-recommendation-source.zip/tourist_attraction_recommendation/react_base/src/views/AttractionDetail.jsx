import { useEffect, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { toast } from 'react-toastify'
import travelApi from '../api/travel'
import { useUserStore } from '../stores/userStore'
import { formatCount, formatPrice, locationOf, normalizeAttraction, unwrapData, unwrapList } from '../utils/attraction'
import AttractionImage from '../components/AttractionImage'
import AttractionCard from '../components/AttractionCard'
import Icon from '../components/Icon'
import { EmptyState, Loading } from '../components/Feedback'
import { getErrorMessage } from '../utils/errorHandler'

export default function AttractionDetail() {
  const { id } = useParams()
  const navigate = useNavigate()
  const isAuthenticated = useUserStore((state) => state.isAuthenticated)
  const [attraction, setAttraction] = useState(null)
  const [similar, setSimilar] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [favoriteBusy, setFavoriteBusy] = useState(false)
  const [score, setScore] = useState(0)
  const [hoverScore, setHoverScore] = useState(0)
  const [comment, setComment] = useState('')
  const [ratingBusy, setRatingBusy] = useState(false)

  useEffect(() => {
    let active = true
    setLoading(true)
    setError('')
    travelApi.getAttraction(id).then(async (response) => {
      if (!active) return
      const raw = unwrapData(response) || {}
      const normalized = normalizeAttraction(raw)
      setAttraction(normalized)
      setScore(normalized.userScore || 0)
      let related = unwrapList({ data: raw.similar_attractions || raw.related || raw.recommendations || [] })
      if (related.length === 0) {
        try {
          const fallback = await travelApi.getAttractions({ category: raw.category?.id || normalized.category, sort: 'rating', page_size: 5 })
          related = unwrapList(fallback).filter((item) => String(item.id ?? item.pk) !== String(id))
        } catch {
          related = []
        }
      }
      if (active) setSimilar(related.slice(0, 4))
      if (isAuthenticated) travelApi.recordView(id).catch(() => {})
    }).catch(() => {
      if (active) setError('未能加载景点详情，请检查网络后重试。')
    }).finally(() => active && setLoading(false))
    return () => { active = false }
  }, [id, isAuthenticated])

  const toggleFavorite = async () => {
    if (!isAuthenticated) {
      navigate(`/login?redirect=${encodeURIComponent(`/attractions/${id}`)}`)
      return
    }
    setFavoriteBusy(true)
    try {
      if (attraction.isFavorite) await travelApi.removeFavorite(id)
      else await travelApi.addFavorite(id)
      setAttraction((current) => ({ ...current, isFavorite: !current.isFavorite, favoriteCount: Math.max(0, current.favoriteCount + (current.isFavorite ? -1 : 1)) }))
      toast.success(attraction.isFavorite ? '已取消收藏' : '已加入我的收藏')
    } catch (requestError) {
      toast.error(getErrorMessage(requestError, '收藏操作失败，请稍后重试'))
    } finally {
      setFavoriteBusy(false)
    }
  }

  const submitRating = async (event) => {
    event.preventDefault()
    if (!isAuthenticated) return navigate(`/login?redirect=${encodeURIComponent(`/attractions/${id}`)}`)
    if (!score) return toast.info('请先选择 1 至 5 星评分')
    setRatingBusy(true)
    try {
      await travelApi.rateAttraction(id, { score, comment: comment.trim() })
      toast.success('评分已提交，感谢你的分享')
      setComment('')
      setAttraction((current) => ({ ...current, rating: current.rating || score }))
    } catch (requestError) {
      toast.error(getErrorMessage(requestError, '评分提交失败，请稍后重试'))
    } finally {
      setRatingBusy(false)
    }
  }

  if (loading) return <section className="section"><div className="shell"><Loading label="正在打开这处风景…"/></div></section>
  if (error || !attraction) return <section className="section"><div className="shell"><EmptyState icon="refresh" title="景点详情未能打开" description={error || '该景点可能已下架。'} action={<div className="empty-actions"><button className="button button-primary" onClick={() => window.location.reload()}>重新加载</button><Link className="button button-ghost" to="/attractions">返回景点库</Link></div>}/></div></section>

  return (
    <>
      <section className="detail-hero">
        <AttractionImage className="detail-cover" src={attraction.cover} alt={attraction.name}/><div className="detail-overlay"/>
        <div className="shell detail-hero-content">
          <div className="breadcrumbs"><Link to="/">首页</Link><Icon name="chevron" size={13}/><Link to="/attractions">景点库</Link><Icon name="chevron" size={13}/><span>{attraction.name}</span></div>
          <div className="detail-title-wrap">
            <div><div className="detail-badges">{attraction.level && <span>{attraction.level}</span>}{attraction.category && <span>{attraction.category}</span>}</div><h1>{attraction.name}</h1><p><Icon name="map" size={18}/>{locationOf(attraction)}{attraction.addressText && ` · ${attraction.addressText}`}</p></div>
            <button className={`favorite-button ${attraction.isFavorite ? 'active' : ''}`} onClick={toggleFavorite} disabled={favoriteBusy}><Icon name="heart" size={21} fill={attraction.isFavorite ? 'currentColor' : 'none'}/>{favoriteBusy ? '处理中…' : attraction.isFavorite ? '已收藏' : '收藏景点'}</button>
          </div>
        </div>
      </section>

      <section className="section detail-section">
        <div className="shell detail-layout">
          <div className="detail-main">
            <div className="detail-stat-grid">
              <div><span><Icon name="star" size={20} fill="currentColor"/></span><div><strong>{attraction.rating ? attraction.rating.toFixed(1) : '暂无'}</strong><small>{attraction.ratingCount} 人评分</small></div></div>
              <div><span><Icon name="ticket" size={20}/></span><div><strong>{formatPrice(attraction.price)}</strong><small>门票参考</small></div></div>
              <div><span><Icon name="eye" size={20}/></span><div><strong>{formatCount(attraction.viewCount)}</strong><small>累计浏览</small></div></div>
              <div><span><Icon name="heart" size={20}/></span><div><strong>{formatCount(attraction.favoriteCount)}</strong><small>用户收藏</small></div></div>
            </div>

            <article className="content-card detail-description"><div className="content-title"><span/><h2>景点介绍</h2></div><p>{attraction.description || '该景点的详细介绍正在完善中，你可以先收藏并稍后再来了解。'}</p>{attraction.tags.length > 0 && <div className="tag-list">{attraction.tags.map((tag) => <span key={tag}>#{tag}</span>)}</div>}</article>

            <article className="content-card detail-info-card"><div className="content-title"><span/><h2>游览信息</h2></div><div className="travel-info-grid"><div><Icon name="history" size={19}/><span><small>开放时间</small><strong>{attraction.opening_hours || '以景区当日公告为准'}</strong></span></div><div><Icon name="compass" size={19}/><span><small>建议游玩</small><strong>{attraction.suggested_duration || '建议预留半天时间'}</strong></span></div><div><Icon name="map" size={19}/><span><small>详细地址</small><strong>{attraction.addressText || locationOf(attraction)}</strong></span></div><div><Icon name="shield" size={19}/><span><small>景区等级</small><strong>{attraction.level || '品质景区'}</strong></span></div></div></article>

            <article className="content-card rating-card"><div className="content-title"><span/><h2>分享你的体验</h2></div><p className="rating-tip">你的真实评分，将帮助系统为你和其他旅行者带来更准确的推荐。</p><form onSubmit={submitRating}><div className="star-picker" onMouseLeave={() => setHoverScore(0)}>{[1, 2, 3, 4, 5].map((value) => <button type="button" key={value} onMouseEnter={() => setHoverScore(value)} onClick={() => setScore(value)} aria-label={`${value}星`}><Icon name="star" size={29} fill={(hoverScore || score) >= value ? 'currentColor' : 'none'}/></button>)}<span>{score ? ['','很失望','不太满意','还不错','值得推荐','非常满意'][score] : '点击星星评分'}</span></div><textarea value={comment} onChange={(event) => setComment(event.target.value)} maxLength={300} placeholder="说说这里最打动你的地方吧（选填）"/><div className="form-foot"><small>{comment.length}/300</small><button className="button button-primary" disabled={ratingBusy}>{ratingBusy ? '提交中…' : isAuthenticated ? '提交评分' : '登录后评分'}</button></div></form></article>
          </div>

          <aside className="detail-aside">
            <div className="aside-card"><p className="eyebrow">TRAVEL TIPS</p><h3>出行小贴士</h3><ul><li><Icon name="check" size={16}/>出发前留意开放时间与天气</li><li><Icon name="check" size={16}/>节假日建议提前预约门票</li><li><Icon name="check" size={16}/>文明游览，爱护自然环境</li></ul></div>
            <div className="aside-recommend"><Icon name="sparkles" size={23}/><h3>想看更懂你的推荐？</h3><p>完成更多评分，推荐结果会越来越准确。</p><Link to="/recommendations">查看个性推荐 <Icon name="arrow" size={16}/></Link></div>
          </aside>
        </div>
      </section>

      {similar.length > 0 && <section className="section similar-section"><div className="shell"><div className="section-heading"><div><p className="eyebrow">SIMILAR PLACES</p><h2>你可能还喜欢</h2></div><Link className="text-link" to="/attractions">更多景点 <Icon name="arrow" size={17}/></Link></div><div className="card-grid">{similar.map((item) => <AttractionCard item={item} key={item.id || item.pk}/>)}</div></div></section>}
    </>
  )
}
