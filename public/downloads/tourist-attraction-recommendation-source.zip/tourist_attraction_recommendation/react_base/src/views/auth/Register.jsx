import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'
import { useUserStore } from '../../stores/userStore'
import { validateEmail, validatePhone, validatePassword } from '../../utils/helpers'
import AuthShell from '../../components/AuthShell'
import Icon from '../../components/Icon'

export default function Register() {
  const navigate = useNavigate()
  const registerUser = useUserStore((state) => state.register)
  const [form, setForm] = useState({ username: '', email: '', phone: '', password: '', passwordConfirm: '' })
  const [errors, setErrors] = useState({})
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (event) => {
    event.preventDefault()
    const nextErrors = {}
    if (form.username.trim().length < 3) nextErrors.username = '用户名至少需要 3 个字符'
    if (form.email && !validateEmail(form.email)) nextErrors.email = '请输入正确的邮箱地址'
    if (form.phone && !validatePhone(form.phone)) nextErrors.phone = '请输入正确的大陆手机号'
    const passwordResult = validatePassword(form.password)
    if (!passwordResult.valid) nextErrors.password = passwordResult.message
    if (form.password !== form.passwordConfirm) nextErrors.passwordConfirm = '两次输入的密码不一致'
    if (Object.keys(nextErrors).length) return setErrors(nextErrors)

    setErrors({})
    setLoading(true)
    const result = await registerUser({ username: form.username.trim(), email: form.email || undefined, phone: form.phone || undefined, password: form.password, password_confirm: form.passwordConfirm })
    setLoading(false)
    if (result.success) {
      toast.success('注册成功，请登录开启专属旅程')
      navigate('/login')
    } else toast.error(result.message || '注册失败，请稍后重试')
  }

  const field = (name, label, icon, placeholder, type = 'text', autoComplete = '') => (
    <label><span>{label}</span><div className={errors[name] ? 'input-wrap error' : 'input-wrap'}><Icon name={icon} size={19}/><input type={type} autoComplete={autoComplete} value={form[name]} onChange={(event) => setForm({ ...form, [name]: event.target.value })} placeholder={placeholder}/></div>{errors[name] && <small className="field-error">{errors[name]}</small>}</label>
  )

  return (
    <AuthShell register title="创建账号" subtitle="记录偏好，收获属于你的旅行推荐" alternateText="已经有账号？" alternateLink="/login" alternateLabel="返回登录">
      <form className="auth-form auth-form-register" onSubmit={handleSubmit}>
        {field('username', '用户名', 'user', '至少 3 个字符', 'text', 'username')}
        <div className="form-pair">{field('email', '邮箱（选填）', 'mail', 'name@example.com', 'email', 'email')}{field('phone', '手机号（选填）', 'phone', '11 位手机号', 'tel', 'tel')}</div>
        <div className="form-pair">{field('password', '设置密码', 'lock', '至少 8 位，含大小写与数字', 'password', 'new-password')}{field('passwordConfirm', '确认密码', 'lock', '请再次输入密码', 'password', 'new-password')}</div>
        <label className="terms-label"><input type="checkbox" required/><span>我已阅读并同意用户服务说明与隐私保护约定</span></label>
        <button className="button button-primary auth-submit" disabled={loading}>{loading ? <><span className="mini-loader"/>正在创建…</> : <>注册并开始探索 <Icon name="arrow" size={18}/></>}</button>
      </form>
    </AuthShell>
  )
}
