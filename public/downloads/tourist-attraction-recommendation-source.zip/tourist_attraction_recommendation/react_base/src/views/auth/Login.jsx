import { useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'
import { useUserStore } from '../../stores/userStore'
import AuthShell from '../../components/AuthShell'
import Icon from '../../components/Icon'

export default function Login() {
  const navigate = useNavigate()
  const location = useLocation()
  const login = useUserStore((state) => state.login)
  const [form, setForm] = useState({ username: '', password: '' })
  const [errors, setErrors] = useState({})
  const [loading, setLoading] = useState(false)
  const redirect = new URLSearchParams(location.search).get('redirect') || '/recommendations'

  const handleSubmit = async (event) => {
    event.preventDefault()
    const nextErrors = {}
    if (!form.username.trim()) nextErrors.username = '请输入用户名'
    if (!form.password) nextErrors.password = '请输入密码'
    if (Object.keys(nextErrors).length) return setErrors(nextErrors)

    setErrors({})
    setLoading(true)
    const result = await login(form)
    setLoading(false)
    if (result.success) {
      toast.success('欢迎回来，旅程继续')
      navigate(redirect, { replace: true })
    } else toast.error(result.message || '登录失败，请检查账号和密码')
  }

  return (
    <AuthShell title="登录账号" subtitle="继续探索为你精选的目的地" alternateText="还没有账号？" alternateLink="/register" alternateLabel="立即注册">
      <form className="auth-form" onSubmit={handleSubmit}>
        <label><span>用户名</span><div className={errors.username ? 'input-wrap error' : 'input-wrap'}><Icon name="user" size={19}/><input autoComplete="username" value={form.username} onChange={(event) => setForm({ ...form, username: event.target.value })} placeholder="请输入用户名"/></div>{errors.username && <small className="field-error">{errors.username}</small>}</label>
        <label><span>密码</span><div className={errors.password ? 'input-wrap error' : 'input-wrap'}><Icon name="lock" size={19}/><input type="password" autoComplete="current-password" value={form.password} onChange={(event) => setForm({ ...form, password: event.target.value })} placeholder="请输入密码"/></div>{errors.password && <small className="field-error">{errors.password}</small>}</label>
        <div className="auth-form-extra"><label className="check-label"><input type="checkbox"/> <span>记住我</span></label><span>忘记密码请联系管理员</span></div>
        <button className="button button-primary auth-submit" disabled={loading}>{loading ? <><span className="mini-loader"/>正在登录…</> : <>登录 <Icon name="arrow" size={18}/></>}</button>
      </form>
    </AuthShell>
  )
}
