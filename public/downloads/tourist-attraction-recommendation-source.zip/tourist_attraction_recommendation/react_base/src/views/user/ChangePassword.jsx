import { useState } from 'react'
import { Link } from 'react-router-dom'
import { toast } from 'react-toastify'
import { useUserStore } from '../../stores/userStore'
import { validatePassword } from '../../utils/helpers'
import Icon from '../../components/Icon'
import { PageIntro } from '../../components/Feedback'

export default function ChangePassword() {
  const changePassword = useUserStore((state) => state.changePassword)
  const [form, setForm] = useState({ old_password: '', new_password: '', new_password_confirm: '' })
  const [errors, setErrors] = useState({})
  const [loading, setLoading] = useState(false)

  const submit = async (event) => {
    event.preventDefault()
    const nextErrors = {}
    if (!form.old_password) nextErrors.old_password = '请输入当前密码'
    const result = validatePassword(form.new_password)
    if (!result.valid) nextErrors.new_password = result.message
    if (form.new_password !== form.new_password_confirm) nextErrors.new_password_confirm = '两次输入的新密码不一致'
    if (Object.keys(nextErrors).length) return setErrors(nextErrors)
    setErrors({})
    setLoading(true)
    const response = await changePassword(form)
    setLoading(false)
    if (response.success) {
      toast.success('密码修改成功')
      setForm({ old_password: '', new_password: '', new_password_confirm: '' })
    } else toast.error(response.message || '密码修改失败')
  }

  const passwordField = (name, label, placeholder) => <label><span>{label}</span><div className={errors[name] ? 'input-wrap error' : 'input-wrap'}><Icon name="lock" size={19}/><input type="password" autoComplete={name === 'old_password' ? 'current-password' : 'new-password'} value={form[name]} onChange={(event) => setForm({ ...form, [name]: event.target.value })} placeholder={placeholder}/></div>{errors[name] && <small className="field-error">{errors[name]}</small>}</label>

  return (
    <><PageIntro eyebrow="ACCOUNT SECURITY" title="账号安全" description="定期更新密码，为你的旅行数据增加一层保护。"/><section className="section"><div className="shell narrow-shell"><div className="content-card password-card"><div className="security-banner"><span><Icon name="shield" size={25}/></span><div><strong>设置一个高强度密码</strong><p>建议使用至少 8 位，且包含大小写字母和数字的组合。</p></div></div><form className="auth-form" onSubmit={submit}>{passwordField('old_password', '当前密码', '请输入当前使用的密码')}{passwordField('new_password', '新密码', '至少 8 位，包含大小写字母和数字')}{passwordField('new_password_confirm', '确认新密码', '请再次输入新密码')}<div className="profile-form-actions"><Link className="button button-ghost" to="/profile">返回个人中心</Link><button className="button button-primary" disabled={loading}>{loading ? '正在修改…' : '确认修改密码'}</button></div></form></div></div></section></>
  )
}
