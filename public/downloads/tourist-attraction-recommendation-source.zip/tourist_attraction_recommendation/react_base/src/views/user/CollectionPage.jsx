import { useCallback, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import travelApi from '../../api/travel'
import { normalizeAttraction, unwrapList } from '../../utils/attraction'
import AttractionCard from '../../components/AttractionCard'
import Icon from '../../components/Icon'
import { EmptyState, Loading, PageIntro } from '../../components/Feedback'
import { formatDateTime } from '../../utils/helpers'

const pageConfig = {
  favorites: {
    eyebrow: 'MY COLLECTION', title: '我的心愿清单', description: '把心动的风景留在这里，为下一次出发积攒灵感。', icon: 'heart',
    api: () => travelApi.getFavorites({ page_size: 100 }), emptyTitle: '还没有收藏景点', emptyText: '遇到喜欢的目的地时，点击收藏按钮就能在这里找到它。',
  },
  history: {
    eyebrow: 'TRAVEL FOOTPRINT', title: '浏览足迹', description: '回顾最近看过的景点，也许下一站就在其中。', icon: 'history',
    api: () => travelApi.getHistory({ page_size: 100 }), emptyTitle: '还没有浏览足迹', emptyText: '去景点库逛逛，你查看过的目的地会自动记录在这里。',
  },
}

export default function CollectionPage({ type }) {
  const config = pageConfig[type]
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const load = useCallback(async () => {
    setLoading(true)
    setError('')
    try {
      const response = await config.api()
      setItems(unwrapList(response))
    } catch {
      setItems([])
      setError('数据暂时无法加载，请稍后再试。')
    } finally {
      setLoading(false)
    }
  }, [config])

  useEffect(() => { load() }, [load])

  return (
    <>
      <PageIntro eyebrow={config.eyebrow} title={config.title} description={config.description}>
        <div className="intro-icon"><Icon name={config.icon} size={26}/></div>
      </PageIntro>
      <section className="section collection-page"><div className="shell">
        <div className="result-bar"><p>共记录 <strong>{items.length}</strong> 个景点</p><Link className="text-link" to="/attractions">继续探索 <Icon name="arrow" size={17}/></Link></div>
        {loading ? <Loading cards/> : items.length > 0 ? (
          <div className="card-grid">{items.map((item, index) => { const attraction = normalizeAttraction(item); return <div className="activity-card-wrap" key={attraction.id || index}><AttractionCard item={item}/>{type === 'history' && attraction.interactedAt && <span className="activity-time"><Icon name="history" size={14}/>浏览于 {formatDateTime(attraction.interactedAt, 'YYYY-MM-DD HH:mm')}</span>}</div> })}</div>
        ) : <EmptyState icon={error ? 'refresh' : config.icon} title={error ? '加载失败' : config.emptyTitle} description={error || config.emptyText} action={<div className="empty-actions">{error && <button className="button button-ghost" onClick={load}>重新加载</button>}<Link className="button button-primary" to="/attractions">发现景点</Link></div>}/>} 
      </div></section>
    </>
  )
}
