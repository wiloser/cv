import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { toast } from 'react-toastify'
import { useUserStore } from '../../stores/userStore'
import travelApi from '../../api/travel'
import { unwrapList } from '../../utils/attraction'
import { formatDateTime, validateEmail, validatePhone } from '../../utils/helpers'
import Icon from '../../components/Icon'

export default function Profile() {
  const { user, fetchProfile, updateProfile } = useUserStore()
  const [form, setForm] = useState({ email: '', phone: '' })
  const [stats, setStats] = useState({ favorites: 0, history: 0, ratings: 0 })
  const [errors, setErrors] = useState({})
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    let active = true
    Promise.allSettled([fetchProfile(), travelApi.getFavorites({ page_size: 100 }), travelApi.getHistory({ page_size: 100 }), travelApi.getRatings({ page_size: 100 })]).then(([profileResult, favorites, history, ratings]) => {
      if (!active) return
      if (profileResult.status === 'fulfilled' && profileResult.value.success) {
        const profile = profileResult.value.data
        setForm({ email: profile.email || '', phone: profile.phone || '' })
      }
      setStats({
        favorites: favorites.status === 'fulfilled' ? unwrapList(favorites.value).length : 0,
        history: history.status === 'fulfilled' ? unwrapList(history.value).length : 0,
        ratings: ratings.status === 'fulfilled' ? unwrapList(ratings.value).length : 0,
      })
    }).finally(() => active && setLoading(false))
    return () => { active = false }
  }, [fetchProfile])

  const submit = async (event) => {
    event.preventDefault()
    const nextErrors = {}
    if (form.email && !validateEmail(form.email)) nextErrors.email = '请输入正确的邮箱地址'
    if (form.phone && !validatePhone(form.phone)) nextErrors.phone = '请输入正确的大陆手机号'
    if (Object.keys(nextErrors).length) return setErrors(nextErrors)
    setErrors({})
    setSaving(true)
    const result = await updateProfile(form)
    setSaving(false)
    if (result.success) toast.success('个人资料已更新')
    else toast.error(result.message || '资料更新失败')
  }

  const roleName = user?.role === 'admin' || user?.is_staff ? '系统管理员' : '旅行探索者'

  return (
    <section className="section profile-page">
      <div className="shell profile-layout">
        <aside className="profile-sidebar">
          <div className="profile-identity"><div className="profile-avatar">{(user?.username || '旅')[0].toUpperCase()}</div><h2>{user?.username || '旅行者'}</h2><p>{roleName}</p><span><Icon name="check" size={13}/>账号状态正常</span></div>
          <nav><Link className="active" to="/profile"><Icon name="user" size={18}/>个人资料</Link><Link to="/favorites"><Icon name="heart" size={18}/>我的收藏</Link><Link to="/history"><Icon name="history" size={18}/>浏览足迹</Link><Link to="/recommendations"><Icon name="sparkles" size={18}/>个性推荐</Link><Link to="/change-password"><Icon name="lock" size={18}/>账号安全</Link></nav>
        </aside>
        <div className="profile-content">
          <div className="profile-welcome"><div><p className="eyebrow">PERSONAL CENTER</p><h1>个人中心</h1><p>管理账户资料，回顾你的旅行探索数据。</p></div><Icon name="compass" size={48}/></div>
          <div className="profile-stats"><Link to="/favorites"><span className="pink"><Icon name="heart" size={21}/></span><div><strong>{stats.favorites}</strong><small>收藏景点</small></div><Icon name="chevron" size={16}/></Link><Link to="/history"><span className="blue"><Icon name="history" size={21}/></span><div><strong>{stats.history}</strong><small>浏览足迹</small></div><Icon name="chevron" size={16}/></Link><Link to="/recommendations"><span className="amber"><Icon name="star" size={21}/></span><div><strong>{stats.ratings}</strong><small>我的评分</small></div><Icon name="chevron" size={16}/></Link></div>
          <div className="content-card profile-form-card">
            <div className="card-section-head"><div><h2>基本资料</h2><p>完善联系方式，便于管理个人账户。</p></div><span><Icon name="edit" size={18}/>可编辑</span></div>
            {loading ? <div className="profile-form-loading"><span className="loader"/></div> : <form onSubmit={submit}>
              <div className="profile-readonly"><label>用户名<div><Icon name="user" size={18}/><input value={user?.username || ''} disabled/></div></label><label>账号角色<div><Icon name="shield" size={18}/><input value={roleName} disabled/></div></label></div>
              <div className="profile-editable"><label>电子邮箱<div className={errors.email ? 'input-wrap error' : 'input-wrap'}><Icon name="mail" size={18}/><input type="email" value={form.email} onChange={(event) => setForm({ ...form, email: event.target.value })} placeholder="请输入邮箱地址"/></div>{errors.email && <small className="field-error">{errors.email}</small>}</label><label>手机号码<div className={errors.phone ? 'input-wrap error' : 'input-wrap'}><Icon name="phone" size={18}/><input value={form.phone} onChange={(event) => setForm({ ...form, phone: event.target.value })} placeholder="请输入手机号码"/></div>{errors.phone && <small className="field-error">{errors.phone}</small>}</label></div>
              <div className="account-meta"><span>注册时间：{formatDateTime(user?.date_joined || user?.created_at, 'YYYY-MM-DD')}</span><span>最近登录：{formatDateTime(user?.last_login, 'YYYY-MM-DD HH:mm') || '本次登录'}</span></div>
              <div className="profile-form-actions"><Link className="button button-ghost" to="/change-password"><Icon name="lock" size={17}/>修改密码</Link><button className="button button-primary" disabled={saving}>{saving ? '保存中…' : '保存修改'}</button></div>
            </form>}
          </div>
        </div>
      </div>
    </section>
  )
}
