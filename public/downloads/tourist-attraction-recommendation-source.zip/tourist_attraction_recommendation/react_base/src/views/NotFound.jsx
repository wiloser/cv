import { Link } from 'react-router-dom'
import Icon from '../components/Icon'

export default function NotFound() {
  return (
    <section className="not-found"><div className="not-found-visual"><span>4</span><div><Icon name="compass" size={70}/></div><span>4</span></div><h1>这条旅行路线还未开放</h1><p>你访问的页面可能已移动，返回首页继续发现美好风景吧。</p><div className="empty-actions"><Link className="button button-primary" to="/"><Icon name="home" size={17}/>返回首页</Link><Link className="button button-ghost" to="/attractions">浏览景点</Link></div></section>
  )
}
