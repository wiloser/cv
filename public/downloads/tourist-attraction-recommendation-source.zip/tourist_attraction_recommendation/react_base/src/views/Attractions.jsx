import { useEffect, useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import travelApi from '../api/travel'
import { unwrapData, unwrapList } from '../utils/attraction'
import AttractionCard from '../components/AttractionCard'
import Icon from '../components/Icon'
import { EmptyState, Loading, PageIntro } from '../components/Feedback'

const provinces = [
  { value: '北京市', label: '北京' }, { value: '上海市', label: '上海' },
  { value: '浙江省', label: '浙江' }, { value: '江苏省', label: '江苏' },
  { value: '四川省', label: '四川' }, { value: '云南省', label: '云南' },
  { value: '陕西省', label: '陕西' }, { value: '福建省', label: '福建' },
  { value: '广东省', label: '广东' }, { value: '海南省', label: '海南' },
]
const sortOptions = [
  { value: 'popular', label: '人气优先' },
  { value: 'rating', label: '评分最高' },
  { value: 'newest', label: '最新收录' },
]

export default function Attractions() {
  const [searchParams, setSearchParams] = useSearchParams()
  const [keyword, setKeyword] = useState(searchParams.get('search') || '')
  const [items, setItems] = useState([])
  const [categories, setCategories] = useState([])
  const [count, setCount] = useState(0)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const query = useMemo(() => ({
    search: searchParams.get('search') || undefined,
    province: searchParams.get('province') || undefined,
    category: searchParams.get('category') || undefined,
    sort: searchParams.get('sort') || 'popular',
    page: searchParams.get('page') || 1,
    page_size: 12,
  }), [searchParams])

  useEffect(() => {
    let active = true
    setLoading(true)
    setError('')
    travelApi.getAttractions(query).then((response) => {
      if (!active) return
      const data = unwrapData(response)
      const list = unwrapList(response)
      setItems(list)
      setCount(Number(data?.count ?? data?.total ?? list.length))
    }).catch(() => {
      if (!active) return
      setItems([])
      setCount(0)
      setError('景点数据暂时无法加载，请稍后重试。')
    }).finally(() => active && setLoading(false))
    return () => { active = false }
  }, [query])

  useEffect(() => {
    let active = true
    travelApi.getCategories({ page_size: 100 }).then((response) => {
      if (active) setCategories(unwrapList(response))
    }).catch(() => { if (active) setCategories([]) })
    return () => { active = false }
  }, [])

  const updateFilter = (key, value) => {
    const next = new URLSearchParams(searchParams)
    if (value) next.set(key, value)
    else next.delete(key)
    next.delete('page')
    setSearchParams(next)
  }

  const submitSearch = (event) => {
    event.preventDefault()
    updateFilter('search', keyword.trim())
  }

  const reset = () => {
    setKeyword('')
    setSearchParams({ sort: 'popular' })
  }

  const page = Number(query.page || 1)
  const hasNext = count > page * 12 || items.length >= 12

  return (
    <>
      <PageIntro eyebrow="DESTINATION LIBRARY" title="发现理想目的地" description="从自然风光到人文胜迹，按照你的节奏探索祖国大好河山。">
        <div className="intro-stat"><strong>{count}</strong><span>个优质景点</span></div>
      </PageIntro>
      <section className="section listing-section">
        <div className="shell">
          <div className="filter-panel">
            <form className="listing-search" onSubmit={submitSearch}><Icon name="search" size={20}/><input value={keyword} onChange={(event) => setKeyword(event.target.value)} placeholder="搜索景点名称、城市或关键词"/><button>搜索</button></form>
            <div className="filter-row">
              <span className="filter-label"><Icon name="map" size={17}/>目的地区</span>
              <div className="filter-chips"><button className={!query.province ? 'active' : ''} onClick={() => updateFilter('province', '')}>全部</button>{provinces.map((province) => <button className={query.province === province.value ? 'active' : ''} key={province.value} onClick={() => updateFilter('province', province.value)}>{province.label}</button>)}</div>
            </div>
            <div className="filter-row">
              <span className="filter-label"><Icon name="layers" size={17}/>景点类型</span>
              <div className="filter-chips"><button className={!query.category ? 'active' : ''} onClick={() => updateFilter('category', '')}>全部</button>{categories.map((category) => { const value = String(category.id ?? category.value ?? category.name ?? category.title); const label = category.name || category.title || category.label || value; return <button className={query.category === value ? 'active' : ''} key={value} onClick={() => updateFilter('category', value)}>{label}</button> })}</div>
            </div>
          </div>

          <div className="result-bar">
            <p>共找到 <strong>{count}</strong> 个相关景点{query.search && <>，关键词“<b>{query.search}</b>”</>}</p>
            <label><Icon name="filter" size={16}/><span>排序</span><select value={query.sort} onChange={(event) => updateFilter('sort', event.target.value)}>{sortOptions.map((option) => <option value={option.value} key={option.value}>{option.label}</option>)}</select></label>
          </div>

          {loading ? <Loading cards/> : items.length > 0 ? (
            <>
              <div className="card-grid">{items.map((item) => <AttractionCard item={item} key={item.id || item.pk}/>)}</div>
              {(page > 1 || hasNext) && <div className="pagination"><button disabled={page <= 1} onClick={() => updateFilter('page', page - 1)}>上一页</button><span>第 {page} 页</span><button disabled={!hasNext} onClick={() => updateFilter('page', page + 1)}>下一页</button></div>}
            </>
          ) : (
            <EmptyState icon={error ? 'refresh' : 'search'} title={error ? '加载景点失败' : '没有找到匹配的景点'} description={error || '尝试减少筛选条件，或换一个关键词搜索。'} action={<button className="button button-primary" onClick={reset}>{error ? '重新加载' : '清除筛选'}</button>}/>
          )}
        </div>
      </section>
    </>
  )
}
