import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import travelApi from '../../api/travel'
import { normalizeAttraction, unwrapData, unwrapList } from '../../utils/attraction'
import AttractionImage from '../../components/AttractionImage'
import Icon from '../../components/Icon'
import { Loading, PageIntro } from '../../components/Feedback'

export default function Dashboard() {
  const [stats, setStats] = useState({})
  const [popular, setPopular] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    Promise.allSettled([travelApi.getDashboardStats(), travelApi.getAttractions({ sort: 'popular', page_size: 5 })]).then(([statsResult, attractionResult]) => {
      if (statsResult.status === 'fulfilled') setStats(unwrapData(statsResult.value) || {})
      if (attractionResult.status === 'fulfilled') setPopular(unwrapList(attractionResult.value).slice(0, 5))
    }).finally(() => setLoading(false))
  }, [])

  const cards = [
    { label: '注册用户', value: stats.user_count ?? stats.users ?? stats.total_users ?? 0, trend: '平台累计用户', icon: 'users', color: 'teal' },
    { label: '收录景点', value: stats.attraction_count ?? stats.attractions ?? stats.total_attractions ?? 0, trend: '景点资源总量', icon: 'map', color: 'blue' },
    { label: '收藏互动', value: stats.favorite_count ?? stats.favorites ?? stats.total_favorites ?? 0, trend: '用户收藏次数', icon: 'heart', color: 'pink' },
    { label: '评分数据', value: stats.rating_count ?? stats.ratings ?? stats.total_ratings ?? 0, trend: '推荐算法依据', icon: 'star', color: 'amber' },
  ]

  return (
    <><PageIntro eyebrow="ADMIN CONSOLE" title="系统数据概览" description="旅游景点推荐系统运行数据与内容管理。"><Link className="button button-primary" to="/admin/attractions"><Icon name="layers" size={17}/>景点管理</Link></PageIntro><section className="section admin-page"><div className="shell">{loading ? <Loading/> : <><div className="admin-stats">{cards.map((card) => <article key={card.label}><span className={card.color}><Icon name={card.icon} size={23} fill={card.icon === 'star' ? 'currentColor' : 'none'}/></span><div><small>{card.label}</small><strong>{card.value}</strong><p>{card.trend}</p></div></article>)}</div><div className="admin-grid"><div className="content-card"><div className="card-section-head"><div><h2>热门景点排行</h2><p>按近期浏览热度排序</p></div><Link className="text-link" to="/admin/attractions">查看全部 <Icon name="arrow" size={16}/></Link></div><div className="ranking-list">{popular.map((item, index) => { const attraction = normalizeAttraction(item); return <Link to={`/attractions/${attraction.id}`} key={attraction.id || index}><b>{String(index + 1).padStart(2, '0')}</b><AttractionImage src={attraction.cover} alt={attraction.name}/><div><strong>{attraction.name}</strong><small>{attraction.province || '地区待完善'} · {attraction.category || '综合景区'}</small></div><span>{attraction.rating ? attraction.rating.toFixed(1) : '-' } 分</span></Link> })}{popular.length === 0 && <p className="admin-empty">暂无排行数据</p>}</div></div><aside className="content-card admin-quick"><div className="card-section-head"><div><h2>快捷管理</h2><p>常用管理入口</p></div></div><Link to="/admin/attractions"><span><Icon name="map" size={20}/></span><div><strong>景点信息管理</strong><small>查看与维护景点数据</small></div><Icon name="chevron" size={17}/></Link><Link to="/admin/users"><span><Icon name="users" size={20}/></span><div><strong>用户信息管理</strong><small>查看平台注册用户</small></div><Icon name="chevron" size={17}/></Link><div className="system-status"><span/><div><strong>系统服务正常</strong><small>API 与推荐引擎运行中</small></div></div></aside></div></>}</div></section></>
  )
}
