import { useEffect, useState } from 'react'
import travelApi from '../../api/travel'
import { formatPrice, locationOf, normalizeAttraction, unwrapData, unwrapList } from '../../utils/attraction'
import AttractionImage from '../../components/AttractionImage'
import Icon from '../../components/Icon'
import { EmptyState, Loading, PageIntro } from '../../components/Feedback'

export default function AttractionManage() {
  const [keyword, setKeyword] = useState('')
  const [search, setSearch] = useState('')
  const [items, setItems] = useState([])
  const [count, setCount] = useState(0)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let active = true
    setLoading(true)
    travelApi.getAttractions({ search: search || undefined, page_size: 20 }).then((response) => {
      if (!active) return
      const list = unwrapList(response)
      const data = unwrapData(response)
      setItems(list)
      setCount(Number(data?.count ?? data?.total ?? list.length))
    }).catch(() => active && setItems([])).finally(() => active && setLoading(false))
    return () => { active = false }
  }, [search])

  return (
    <><PageIntro eyebrow="CONTENT MANAGEMENT" title="景点信息管理" description="查看系统已收录的景点资源及核心数据。"/><section className="section admin-page"><div className="shell"><div className="admin-toolbar"><form onSubmit={(event) => { event.preventDefault(); setSearch(keyword.trim()) }}><Icon name="search" size={18}/><input value={keyword} onChange={(event) => setKeyword(event.target.value)} placeholder="搜索景点名称"/><button>查询</button></form><span>共 {count} 条景点数据</span></div>{loading ? <Loading/> : items.length > 0 ? <div className="content-card table-card"><div className="admin-table-wrap"><table className="admin-table"><thead><tr><th>景点信息</th><th>地区</th><th>类型 / 等级</th><th>门票</th><th>评分</th><th>浏览量</th><th>状态</th></tr></thead><tbody>{items.map((item, index) => { const attraction = normalizeAttraction(item); return <tr key={attraction.id || index}><td><div className="table-attraction"><AttractionImage src={attraction.cover} alt={attraction.name}/><div><strong>{attraction.name}</strong><small>ID: {attraction.id}</small></div></div></td><td>{locationOf(attraction)}</td><td><span className="table-category">{attraction.category || '综合景区'}</span><small>{attraction.level || '未评级'}</small></td><td>{formatPrice(attraction.price)}</td><td><span className="table-rating"><Icon name="star" size={14} fill="currentColor"/>{attraction.rating ? attraction.rating.toFixed(1) : '-'}</span></td><td>{attraction.viewCount}</td><td><span className="status-badge">正常展示</span></td></tr> })}</tbody></table></div></div> : <EmptyState icon="search" title="没有找到景点数据" description="请尝试更换搜索关键词。"/>}</div></section></>
  )
}
