import { useEffect, useState } from 'react'
import { useUserStore } from '../../stores/userStore'
import { formatDateTime } from '../../utils/helpers'
import Icon from '../../components/Icon'
import { EmptyState, Loading, PageIntro } from '../../components/Feedback'

export default function UserList() {
  const fetchUserList = useUserStore((state) => state.fetchUserList)
  const [users, setUsers] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchUserList({ page_size: 100 }).then((result) => {
      if (result.success) setUsers(Array.isArray(result.data) ? result.data : result.data?.results || [])
    }).finally(() => setLoading(false))
  }, [fetchUserList])

  return (
    <><PageIntro eyebrow="USER MANAGEMENT" title="用户信息管理" description="查看平台注册用户与账号状态。"/><section className="section admin-page"><div className="shell">{loading ? <Loading/> : users.length > 0 ? <div className="content-card table-card"><div className="admin-table-wrap"><table className="admin-table"><thead><tr><th>用户</th><th>联系方式</th><th>角色</th><th>注册时间</th><th>最近登录</th><th>状态</th></tr></thead><tbody>{users.map((user) => <tr key={user.id}><td><div className="table-user"><span>{(user.username || '用')[0].toUpperCase()}</span><div><strong>{user.username}</strong><small>ID: {user.id}</small></div></div></td><td><div className="contact-cell"><span>{user.email || '未填写邮箱'}</span><small>{user.phone || '未填写手机'}</small></div></td><td><span className={`role-badge ${user.role === 'admin' || user.is_staff ? 'admin' : ''}`}><Icon name={user.role === 'admin' || user.is_staff ? 'shield' : 'user'} size={14}/>{user.role === 'admin' || user.is_staff ? '管理员' : '普通用户'}</span></td><td>{formatDateTime(user.date_joined || user.created_at, 'YYYY-MM-DD')}</td><td>{formatDateTime(user.last_login, 'YYYY-MM-DD HH:mm') || '暂无记录'}</td><td><span className="status-badge">正常</span></td></tr>)}</tbody></table></div></div> : <EmptyState icon="users" title="暂无用户数据" description="系统中还没有可展示的用户。"/>}</div></section></>
  )
}
