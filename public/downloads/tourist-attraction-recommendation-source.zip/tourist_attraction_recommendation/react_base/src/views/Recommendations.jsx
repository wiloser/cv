import { useCallback, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import travelApi from '../api/travel'
import { normalizeAttraction, unwrapList } from '../utils/attraction'
import AttractionCard from '../components/AttractionCard'
import Icon from '../components/Icon'
import { EmptyState, Loading, PageIntro } from '../components/Feedback'

export default function Recommendations() {
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const load = useCallback(async () => {
    setLoading(true)
    setError('')
    try {
      const response = await travelApi.getRecommendations({ limit: 12 })
      setItems(unwrapList(response))
    } catch {
      setItems([])
      setError('暂时无法生成推荐结果，请稍后重试。')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { load() }, [load])

  return (
    <>
      <PageIntro eyebrow="JUST FOR YOU" title="为你精选的旅行灵感" description="根据你的评分、收藏与相似用户偏好实时生成，每一次互动都会让推荐更懂你。">
        <div className="algorithm-pill"><Icon name="sparkles" size={18}/><span><small>推荐引擎</small><strong>协同过滤算法</strong></span></div>
      </PageIntro>
      <section className="section recommendation-page">
        <div className="shell">
          <div className="recommendation-note"><span><Icon name="shield" size={22}/></span><div><strong>本次推荐如何生成？</strong><p>系统寻找与你兴趣相近的旅行者，并从他们喜爱的景点中筛选出适合你的目的地。所有行为数据仅用于改善推荐体验。</p></div></div>
          <div className="result-bar"><p>本次为你匹配 <strong>{items.length}</strong> 个目的地</p><button className="refresh-button" onClick={load} disabled={loading}><Icon name="refresh" size={17}/>换一批灵感</button></div>
          {loading ? <Loading cards/> : items.length > 0 ? (
            <div className="card-grid">{items.map((item, index) => { const normalized = normalizeAttraction(item); return <AttractionCard item={item} key={normalized.id || index} reason={normalized.reason || ['与你收藏的景点风格相似', '相似偏好用户也喜欢', '符合你近期关注的旅行主题'][index % 3]}/> })}</div>
          ) : (
            <EmptyState icon={error ? 'refresh' : 'sparkles'} title={error ? '推荐服务暂时开小差' : '再多了解你一点'} description={error || '浏览、收藏或评价几个感兴趣的景点，我们就能为你生成更精准的推荐。'} action={<div className="empty-actions">{error && <button className="button button-primary" onClick={load}>重新生成</button>}<Link className={`button ${error ? 'button-ghost' : 'button-primary'}`} to="/attractions">去探索景点</Link></div>}/>
          )}
        </div>
      </section>
    </>
  )
}
