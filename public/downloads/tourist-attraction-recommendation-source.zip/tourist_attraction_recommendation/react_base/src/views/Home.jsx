import { useCallback, useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useUserStore } from '../stores/userStore'
import travelApi from '../api/travel'
import { unwrapList } from '../utils/attraction'
import AttractionCard from '../components/AttractionCard'
import Icon from '../components/Icon'
import { EmptyState, Loading } from '../components/Feedback'

const quickPlaces = ['北京', '杭州', '成都', '西安', '厦门']

export default function Home() {
  const navigate = useNavigate()
  const isAuthenticated = useUserStore((state) => state.isAuthenticated)
  const [keyword, setKeyword] = useState('')
  const [featured, setFeatured] = useState([])
  const [loading, setLoading] = useState(true)
  const [loadFailed, setLoadFailed] = useState(false)

  const loadFeatured = useCallback(async () => {
    setLoading(true)
    setLoadFailed(false)
    try {
      const response = await travelApi.getFeatured()
      setFeatured(unwrapList(response).slice(0, 4))
    } catch {
      setFeatured([])
      setLoadFailed(true)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { loadFeatured() }, [loadFeatured])

  const search = (event) => {
    event?.preventDefault()
    navigate(keyword.trim() ? `/attractions?search=${encodeURIComponent(keyword.trim())}` : '/attractions')
  }

  return (
    <>
      <section className="hero-section">
        <div className="hero-orb hero-orb-one"/><div className="hero-orb hero-orb-two"/>
        <div className="shell hero-grid">
          <div className="hero-copy">
            <div className="hero-kicker"><Icon name="sparkles" size={16}/>基于兴趣偏好的智慧推荐</div>
            <h1>下一站，去遇见<br/><em>更懂你的风景</em></h1>
            <p>从山川湖海到人文古迹，云游迹结合协同过滤算法，为你发现契合偏好的旅行目的地。</p>
            <form className="hero-search" onSubmit={search}>
              <Icon name="search" size={21}/>
              <input value={keyword} onChange={(event) => setKeyword(event.target.value)} placeholder="搜索景点、城市或旅行灵感" aria-label="搜索景点"/>
              <button type="submit">探索目的地</button>
            </form>
            <div className="quick-search"><span>热门搜索</span>{quickPlaces.map((place) => <button key={place} onClick={() => navigate(`/attractions?search=${place}`)}>{place}</button>)}</div>
            <div className="hero-points">
              <span><Icon name="check" size={15}/>海量景点信息</span><span><Icon name="check" size={15}/>猜你喜欢</span><span><Icon name="check" size={15}/>真实评分参考</span>
            </div>
          </div>
          <div className="hero-visual" aria-hidden="true">
            <div className="visual-card visual-main">
              <div className="scenic-sky"><span className="sun"/><span className="cloud cloud-a"/><span className="cloud cloud-b"/><i className="mountain m-one"/><i className="mountain m-two"/><i className="mountain m-three"/><span className="river"/></div>
              <div className="visual-caption"><div><small>今日灵感</small><strong>奔赴山海之间</strong></div><span><Icon name="star" size={15} fill="currentColor"/>4.9</span></div>
            </div>
            <div className="floating-card floating-top"><span><Icon name="sparkles" size={19}/></span><div><small>智能匹配</small><strong>偏好契合度 96%</strong></div></div>
            <div className="floating-card floating-bottom"><div className="mini-avatars"><i>云</i><i>游</i><i>迹</i></div><div><strong>12,680+</strong><small>旅行者正在探索</small></div></div>
            <div className="route-dots"><i/><i/><i/><i/></div>
          </div>
        </div>
      </section>

      <section className="section featured-section">
        <div className="shell">
          <div className="section-heading">
            <div><p className="eyebrow">POPULAR DESTINATIONS</p><h2>本季精选目的地</h2><p>高评分与高人气兼具，开启你的下一段旅程</p></div>
            <Link className="text-link" to="/attractions">查看全部 <Icon name="arrow" size={17}/></Link>
          </div>
          {loading ? <Loading cards/> : featured.length > 0 ? (
            <div className="card-grid">{featured.map((item) => <AttractionCard item={item} key={item.id || item.pk}/>)}</div>
          ) : (
            <EmptyState title={loadFailed ? '精选内容暂未连接' : '精选景点正在整理中'} description={loadFailed ? '服务暂时不可用，你仍可前往景点库继续浏览。' : '稍后将为你呈现更多热门目的地。'} action={<div className="empty-actions"><Link className="button button-primary" to="/attractions">浏览景点库</Link>{loadFailed && <button className="button button-ghost" onClick={loadFeatured}><Icon name="refresh" size={17}/>重新加载</button>}</div>}/>
          )}
        </div>
      </section>

      <section className="section features-section">
        <div className="shell">
          <div className="section-heading centered"><div><p className="eyebrow">WHY CLOUD JOURNEY</p><h2>懂你的旅行推荐助手</h2><p>从发现、决策到收藏，让每一步都简单而从容</p></div></div>
          <div className="feature-grid">
            <article><span className="feature-icon teal"><Icon name="sparkles" size={27}/></span><div><small>01</small><h3>千人千面的推荐</h3><p>分析用户评分与收藏行为，通过协同过滤发现你可能喜欢的景点。</p></div></article>
            <article><span className="feature-icon amber"><Icon name="compass" size={27}/></span><div><small>02</small><h3>多维探索与筛选</h3><p>按地区、类别、热度与评分快速筛选，轻松锁定心仪目的地。</p></div></article>
            <article><span className="feature-icon blue"><Icon name="history" size={27}/></span><div><small>03</small><h3>记录每一次心动</h3><p>收藏喜欢的景点、保存浏览足迹，让旅行灵感不再转瞬即逝。</p></div></article>
          </div>
        </div>
      </section>

      <section className="section workflow-section">
        <div className="shell workflow-card">
          <div><p className="eyebrow">HOW IT WORKS</p><h2>三步开启个性化探索</h2><p>你的每一次浏览、收藏和评分，都让推荐结果更贴近真实偏好。</p></div>
          <ol><li><span>1</span><div><strong>创建账号</strong><small>开启专属旅行档案</small></div></li><li><span>2</span><div><strong>探索并评分</strong><small>告诉系统你的偏好</small></div></li><li><span>3</span><div><strong>收获专属推荐</strong><small>发现更多心仪风景</small></div></li></ol>
          <Link className="button button-light" to={isAuthenticated ? '/recommendations' : '/register'}>{isAuthenticated ? '查看我的推荐' : '立即开始探索'}<Icon name="arrow" size={18}/></Link>
        </div>
      </section>
    </>
  )
}
