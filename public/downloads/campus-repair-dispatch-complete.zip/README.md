# RepairOps 校园报修智能派单系统

针对传统校园报修依赖人工转派、响应效率不稳定、维修负载不透明的问题，构建集工单分级、
维修资源管理、可解释智能匹配与派单看板于一体的轻量平台。源码采用 React + Go/Gin + SQLite，
可在资源受限的云主机上独立运行。

本项目采用统一的本科毕业设计交付结构：

```text
campus-repair-dispatch/
├── code/    # 可独立运行、测试和复现的完整源码
├── docs/    # 只保存最终毕业论文（DOCX，或 DOCX + PDF）
└── ppt/     # 只保存最终答辩 PPT（PPTX，可附 PDF 导出稿）
```

开发和运行请进入 `code/`，首次配置执行 `./manage.sh setup`。回到项目根目录后，最终交付前执行：

```bash
./code/manage.sh delivery-check --complete
```

`docs/` 不得放入开题报告、任务书、初稿、查重稿、设计说明、截图、Draw.io 图源或其他过程材料；
这些内容属于开发过程，不属于最终论文目录。`ppt/` 只保留最终答辩演示文稿及其 PDF 导出稿。
