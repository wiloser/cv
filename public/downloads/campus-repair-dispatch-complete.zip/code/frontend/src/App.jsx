import { useEffect, useState } from 'react'

const API = import.meta.env.VITE_API_BASE_URL || ''
const call = async (path, options) => {
  const response = await fetch(`${API}${path}`, { headers: { 'Content-Type': 'application/json' }, ...options })
  const payload = await response.json()
  if (!response.ok) throw new Error(payload.msg || '请求失败')
  return payload.data
}

const since = (value) => {
  const minutes = Math.max(1, Math.round((Date.now() - new Date(value).getTime()) / 60000))
  if (minutes < 60) return `${minutes} 分钟前`
  return `${Math.floor(minutes / 60)} 小时前`
}

const priorityClass = (value) => ({ 紧急: 'danger', 高: 'high', 普通: 'normal' }[value])
const statusClass = (value) => ({ 待派单: 'pending', 已派单: 'assigned', 处理中: 'working', 已完成: 'done' }[value])

function App() {
  const [tickets, setTickets] = useState([])
  const [technicians, setTechnicians] = useState([])
  const [dashboard, setDashboard] = useState({})
  const [activeFilter, setActiveFilter] = useState('全部工单')
  const [dispatching, setDispatching] = useState(null)
  const [dispatchResult, setDispatchResult] = useState(null)
  const [message, setMessage] = useState('')

  const load = async () => {
    try {
      const [ticketData, technicianData, dashboardData] = await Promise.all([
        call('/api/repairs/'), call('/api/technicians/'), call('/api/dashboard/'),
      ])
      setTickets(ticketData)
      setTechnicians(technicianData)
      setDashboard(dashboardData)
      setMessage('')
    } catch (error) {
      setMessage(`${error.message}，请确认 Go 服务已启动`)
    }
  }

  useEffect(() => {
    const timer = window.setTimeout(load, 0)
    return () => window.clearTimeout(timer)
  }, [])

  const dispatch = async (ticket) => {
    setDispatching(ticket.id)
    try {
      const data = await call('/api/repairs/dispatch/', { method: 'POST', body: JSON.stringify({ ticket_id: ticket.id }) })
      setDispatchResult(data)
      await load()
    } catch (error) {
      setMessage(error.message)
    } finally {
      setDispatching(null)
    }
  }

  const filters = ['全部工单', '待派单', '处理中', '已完成']
  const visibleTickets = activeFilter === '全部工单' ? tickets : tickets.filter((ticket) => ticket.status === activeFilter || (activeFilter === '处理中' && ticket.status === '已派单'))

  return (
    <div className="app-shell">
      <aside className="rail">
        <div className="logo">R</div>
        <button className="rail-active">▦<span>工作台</span></button>
        <button>▤<span>工单</span></button>
        <button>♙<span>人员</span></button>
        <button>⌁<span>分析</span></button>
        <div className="rail-bottom"><button>⚙</button><div className="avatar">值</div></div>
      </aside>

      <div className="workspace">
        <header className="topbar"><div className="brand"><b>RepairOps</b><span>校园后勤智能调度中心</span></div><div className="top-actions"><div className="health"><i />调度引擎在线</div><button className="search">⌕ 搜索工单</button><button className="bell">♧<em>3</em></button><div className="user"><div className="avatar">值</div><span><b>张值班</b><small>调度管理员</small></span><i>⌄</i></div></div></header>

        <main>
          <section className="welcome"><div><small>2026 / 秋季学期 · 后勤服务中心</small><h1>早上好，调度员</h1><p>当前有 <b>{dashboard.pending ?? '—'} 个待派工单</b>，智能调度引擎已为紧急事项预计算最优人选。</p></div><button>＋ 新建报修单</button></section>
          {message && <div className="message">{message}<button onClick={() => setMessage('')}>×</button></div>}

          <section className="metrics">
            <article><div className="metric-top"><span className="metric-icon orange">⌁</span><em className="trend up">↑ 8.2%</em></div><strong>{dashboard.pending ?? '—'}</strong><p>待派工单</p><small>其中 1 个紧急工单</small></article>
            <article><div className="metric-top"><span className="metric-icon blue">◷</span><em className="trend">实时</em></div><strong>{dashboard.processing ?? '—'}</strong><p>处理中的工单</p><small>平均响应 {dashboard.average_response_minutes ?? '—'} 分钟</small></article>
            <article><div className="metric-top"><span className="metric-icon green">✓</span><em className="trend up">↑ 5.4%</em></div><strong>{dashboard.completed_today ?? '—'}</strong><p>今日已完成</p><small>SLA 达成率 {dashboard.sla_rate ?? '—'}%</small></article>
            <article><div className="metric-top"><span className="metric-icon violet">♙</span><em className="trend online">在线</em></div><strong>{dashboard.online_technicians ?? '—'}</strong><p>在线维修人员</p><small>覆盖 4 个校园片区</small></article>
          </section>

          <div className="dashboard-grid">
            <section className="card ticket-card">
              <div className="card-head"><div><h2>工单调度队列</h2><p>按优先级和报修时间自动排序</p></div><button>查看全部 →</button></div>
              <div className="filters">{filters.map((filter) => <button key={filter} className={activeFilter === filter ? 'active' : ''} onClick={() => setActiveFilter(filter)}>{filter}<span>{filter === '全部工单' ? tickets.length : tickets.filter((ticket) => ticket.status === filter).length}</span></button>)}</div>
              <div className="ticket-list">
                {visibleTickets.map((ticket) => <article className="ticket" key={ticket.id}>
                  <div className={`priority-line ${priorityClass(ticket.priority)}`} />
                  <div className="ticket-main"><div className="ticket-title"><span className={`priority ${priorityClass(ticket.priority)}`}>{ticket.priority}</span><b>{ticket.title}</b><small>{ticket.ticket_no}</small></div><div className="ticket-meta"><span>⌖ {ticket.building}</span><span>▱ {ticket.category}</span><span>◷ {since(ticket.created_at)}</span></div></div>
                  <div className="assignee">{ticket.assigned_technician ? <><div className="mini-avatar">{ticket.assigned_technician.name.slice(0, 1)}</div><span><b>{ticket.assigned_technician.name}</b><small>匹配度 {ticket.match_score}%</small></span></> : <span className="unassigned">尚未分配人员</span>}</div>
                  <span className={`ticket-status ${statusClass(ticket.status)}`}>{ticket.status}</span>
                  {ticket.status === '待派单' ? <button className="dispatch" disabled={dispatching === ticket.id} onClick={() => dispatch(ticket)}>{dispatching === ticket.id ? '计算中…' : '✦ 智能派单'}</button> : <button className="detail">详情</button>}
                </article>)}
              </div>
            </section>

            <aside className="right-column">
              <section className="card team-card"><div className="card-head"><div><h2>维修团队</h2><p>实时负载与服务状态</p></div><button>管理</button></div><div className="team-list">{technicians.slice(0, 5).map((person) => <div className="person" key={person.id}><div className={`person-avatar ${person.status === '在线' ? 'available' : ''}`}>{person.name.slice(0, 1)}</div><div><b>{person.name}</b><small>{person.trade} · {person.zone}</small></div><span><b>{person.active_load}</b><small>在办</small></span></div>)}</div><footer><i /> 当前 {dashboard.online_technicians ?? '—'} 人可接受新工单</footer></section>
              <section className="engine-card"><div className="engine-icon">✦</div><div><small>SMART DISPATCH</small><h3>智能派单引擎</h3><p>综合工种、片区、实时负载与历史评分，为每张工单提供可解释的匹配结果。</p></div><div className="engine-bars"><span>工种匹配 <i style={{ width: '92%' }} /></span><span>负载均衡 <i style={{ width: '78%' }} /></span><span>片区响应 <i style={{ width: '86%' }} /></span></div></section>
            </aside>
          </div>
        </main>
      </div>

      {dispatchResult && <div className="modal-backdrop" onClick={() => setDispatchResult(null)}><div className="modal" onClick={(event) => event.stopPropagation()}><button className="modal-close" onClick={() => setDispatchResult(null)}>×</button><span className="success-icon">✓</span><small>SMART DISPATCH COMPLETED</small><h2>已完成智能派单</h2><p>{dispatchResult.ticket.ticket_no} 已分配给最优维修人员</p><div className="selected-person"><div className="big-avatar">{dispatchResult.selected.technician.name.slice(0, 1)}</div><div><h3>{dispatchResult.selected.technician.name}</h3><p>{dispatchResult.selected.technician.trade} · {dispatchResult.selected.technician.zone}</p><div className="reason-tags">{dispatchResult.selected.reasons.map((reason) => <span key={reason}>{reason}</span>)}</div></div><strong>{dispatchResult.selected.score}<small>匹配分</small></strong></div><button className="confirm" onClick={() => setDispatchResult(null)}>返回调度队列</button></div></div>}
    </div>
  )
}

export default App
