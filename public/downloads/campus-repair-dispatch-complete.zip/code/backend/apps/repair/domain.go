package repair

import (
	"fmt"
	"sort"
	"strings"
	"time"

	"gin_base/core"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

type Technician struct {
	ID         uint      `gorm:"primaryKey" json:"id"`
	Name       string    `gorm:"size:40;not null" json:"name"`
	Trade      string    `gorm:"size:40;index;not null" json:"trade"`
	Zone       string    `gorm:"size:40;index;not null" json:"zone"`
	Phone      string    `gorm:"size:20;not null" json:"phone"`
	Status     string    `gorm:"size:20;index;not null" json:"status"`
	ActiveLoad int       `gorm:"not null;default:0" json:"active_load"`
	Rating     float64   `gorm:"not null;default:5" json:"rating"`
	Completed  int       `gorm:"not null;default:0" json:"completed"`
	CreatedAt  time.Time `json:"created_at"`
}

type RepairTicket struct {
	ID                   uint        `gorm:"primaryKey" json:"id"`
	TicketNo             string      `gorm:"size:30;uniqueIndex;not null" json:"ticket_no"`
	Title                string      `gorm:"size:120;not null" json:"title"`
	Category             string      `gorm:"size:40;index;not null" json:"category"`
	Building             string      `gorm:"size:80;not null" json:"building"`
	Zone                 string      `gorm:"size:40;index;not null" json:"zone"`
	Priority             string      `gorm:"size:20;index;not null" json:"priority"`
	Status               string      `gorm:"size:20;index;not null" json:"status"`
	Description          string      `gorm:"size:500" json:"description"`
	Reporter             string      `gorm:"size:40;not null" json:"reporter"`
	AssignedTechnicianID *uint       `gorm:"index" json:"assigned_technician_id"`
	AssignedTechnician   *Technician `json:"assigned_technician,omitempty"`
	MatchScore           int         `gorm:"not null;default:0" json:"match_score"`
	DueAt                time.Time   `json:"due_at"`
	CreatedAt            time.Time   `json:"created_at"`
}

type DispatchRequest struct {
	TicketID uint `json:"ticket_id" binding:"required"`
}

type CreateTicketRequest struct {
	Title       string `json:"title" binding:"required"`
	Category    string `json:"category" binding:"required"`
	Building    string `json:"building" binding:"required"`
	Zone        string `json:"zone" binding:"required"`
	Priority    string `json:"priority" binding:"required"`
	Description string `json:"description"`
	Reporter    string `json:"reporter" binding:"required"`
}

type Candidate struct {
	Technician Technician `json:"technician"`
	Score      int        `json:"score"`
	Reasons    []string   `json:"reasons"`
}

func expectedTrade(category string) string {
	trades := map[string]string{
		"水电": "水电维修", "网络": "网络运维", "空调": "暖通设备",
		"门窗": "综合维修", "照明": "水电维修", "电梯": "特种设备",
	}
	if trade, ok := trades[category]; ok {
		return trade
	}
	return "综合维修"
}

// CalculateDispatchScore weights professional fit, service zone, current load
// and historical rating. It is deterministic and can be explained to users.
func CalculateDispatchScore(ticket RepairTicket, technician Technician) (int, []string) {
	score := 0
	reasons := make([]string, 0, 4)
	if technician.Trade == expectedTrade(ticket.Category) {
		score += 48
		reasons = append(reasons, "工种匹配")
	} else if technician.Trade == "综合维修" {
		score += 20
		reasons = append(reasons, "具备综合维修能力")
	}
	if technician.Zone == ticket.Zone {
		score += 22
		reasons = append(reasons, "同片区响应")
	} else {
		score += 6
	}
	loadScore := 18 - technician.ActiveLoad*4
	if loadScore < 0 {
		loadScore = 0
	}
	score += loadScore
	if technician.ActiveLoad <= 2 {
		reasons = append(reasons, "当前负载较低")
	}
	ratingScore := int((technician.Rating - 3.5) * 8)
	if ratingScore < 0 {
		ratingScore = 0
	}
	if ratingScore > 12 {
		ratingScore = 12
	}
	score += ratingScore
	if technician.Rating >= 4.8 {
		reasons = append(reasons, "服务评价优秀")
	}
	if ticket.Priority == "紧急" && technician.Zone == ticket.Zone {
		score += 5
	}
	if score > 100 {
		score = 100
	}
	return score, reasons
}

func rankCandidates(db *gorm.DB, ticket RepairTicket) ([]Candidate, error) {
	var technicians []Technician
	if err := db.Where("status = ?", "在线").Find(&technicians).Error; err != nil {
		return nil, err
	}
	candidates := make([]Candidate, 0, len(technicians))
	for _, technician := range technicians {
		score, reasons := CalculateDispatchScore(ticket, technician)
		candidates = append(candidates, Candidate{Technician: technician, Score: score, Reasons: reasons})
	}
	sort.SliceStable(candidates, func(i, j int) bool {
		if candidates[i].Score == candidates[j].Score {
			return candidates[i].Technician.ActiveLoad < candidates[j].Technician.ActiveLoad
		}
		return candidates[i].Score > candidates[j].Score
	})
	if len(candidates) > 3 {
		candidates = candidates[:3]
	}
	return candidates, nil
}

func SeedDemoData() error {
	db := core.GetDB()
	var technicianCount int64
	if err := db.Model(&Technician{}).Count(&technicianCount).Error; err != nil {
		return err
	}
	if technicianCount == 0 {
		technicians := []Technician{
			{Name: "陈志远", Trade: "水电维修", Zone: "东区", Phone: "138****1208", Status: "在线", ActiveLoad: 1, Rating: 4.9, Completed: 286},
			{Name: "刘海峰", Trade: "网络运维", Zone: "东区", Phone: "136****2716", Status: "在线", ActiveLoad: 2, Rating: 4.8, Completed: 198},
			{Name: "周明辉", Trade: "暖通设备", Zone: "西区", Phone: "139****0522", Status: "在线", ActiveLoad: 1, Rating: 4.7, Completed: 164},
			{Name: "赵师傅", Trade: "综合维修", Zone: "北区", Phone: "137****4309", Status: "在线", ActiveLoad: 3, Rating: 4.9, Completed: 342},
			{Name: "王建国", Trade: "特种设备", Zone: "西区", Phone: "135****8810", Status: "忙碌", ActiveLoad: 4, Rating: 4.8, Completed: 221},
			{Name: "孙晓东", Trade: "水电维修", Zone: "南区", Phone: "188****1935", Status: "在线", ActiveLoad: 2, Rating: 4.6, Completed: 177},
		}
		if err := db.Create(&technicians).Error; err != nil {
			return err
		}
	}

	var ticketCount int64
	if err := db.Model(&RepairTicket{}).Count(&ticketCount).Error; err != nil || ticketCount > 0 {
		return err
	}
	var technicians []Technician
	if err := db.Order("id").Find(&technicians).Error; err != nil {
		return err
	}
	now := time.Now()
	assignedOne, assignedTwo, assignedThree := technicians[0].ID, technicians[1].ID, technicians[2].ID
	tickets := []RepairTicket{
		{TicketNo: "BX-2026-0811", Title: "教学楼三层走廊灯具闪烁", Category: "照明", Building: "博学楼 A3", Zone: "东区", Priority: "紧急", Status: "待派单", Description: "靠近 305 教室位置，晚间影响通行。", Reporter: "张老师", DueAt: now.Add(2 * time.Hour), CreatedAt: now.Add(-18 * time.Minute)},
		{TicketNo: "BX-2026-0810", Title: "实验室校园网无法接入", Category: "网络", Building: "格物楼 502", Zone: "东区", Priority: "高", Status: "处理中", Description: "交换机端口指示灯异常。", Reporter: "李同学", AssignedTechnicianID: &assignedTwo, MatchScore: 92, DueAt: now.Add(3 * time.Hour), CreatedAt: now.Add(-47 * time.Minute)},
		{TicketNo: "BX-2026-0809", Title: "空调室内机持续滴水", Category: "空调", Building: "知行苑 2 栋", Zone: "西区", Priority: "普通", Status: "已派单", Description: "靠窗侧空调排水疑似堵塞。", Reporter: "宿管中心", AssignedTechnicianID: &assignedThree, MatchScore: 88, DueAt: now.Add(5 * time.Hour), CreatedAt: now.Add(-76 * time.Minute)},
		{TicketNo: "BX-2026-0808", Title: "洗手池下水管接口漏水", Category: "水电", Building: "明德楼 1F", Zone: "东区", Priority: "高", Status: "处理中", Description: "已临时关闭角阀。", Reporter: "物业巡检", AssignedTechnicianID: &assignedOne, MatchScore: 96, DueAt: now.Add(90 * time.Minute), CreatedAt: now.Add(-2 * time.Hour)},
		{TicketNo: "BX-2026-0807", Title: "宿舍门锁无法正常反锁", Category: "门窗", Building: "知行苑 5 栋", Zone: "北区", Priority: "普通", Status: "待派单", Description: "门锁锁舌回弹不顺畅。", Reporter: "林同学", DueAt: now.Add(8 * time.Hour), CreatedAt: now.Add(-3 * time.Hour)},
		{TicketNo: "BX-2026-0806", Title: "会议室投影网络中断", Category: "网络", Building: "行政楼 208", Zone: "南区", Priority: "普通", Status: "已完成", Description: "无线投屏设备未获取地址。", Reporter: "校办", AssignedTechnicianID: &assignedTwo, MatchScore: 78, DueAt: now.Add(-time.Hour), CreatedAt: now.Add(-6 * time.Hour)},
	}
	return db.Create(&tickets).Error
}

func RegisterRoutes(router *gin.Engine) {
	api := router.Group("/api")
	{
		api.GET("/technicians/", listTechnicians)
		api.GET("/repairs/", listTickets)
		api.GET("/dashboard/", dashboard)
		api.POST("/repairs/", createTicket)
		api.POST("/repairs/dispatch/", dispatchTicket)
	}
}

func listTechnicians(c *gin.Context) {
	var technicians []Technician
	if err := core.GetDB().Order("CASE status WHEN '在线' THEN 0 ELSE 1 END, active_load, rating DESC").Find(&technicians).Error; err != nil {
		core.InternalServerError(c, "维修人员读取失败")
		return
	}
	core.Success(c, technicians)
}

func listTickets(c *gin.Context) {
	var tickets []RepairTicket
	query := core.GetDB().Preload("AssignedTechnician").Order("CASE priority WHEN '紧急' THEN 0 WHEN '高' THEN 1 ELSE 2 END, created_at DESC")
	if status := strings.TrimSpace(c.Query("status")); status != "" {
		query = query.Where("status = ?", status)
	}
	if err := query.Find(&tickets).Error; err != nil {
		core.InternalServerError(c, "报修工单读取失败")
		return
	}
	core.Success(c, tickets)
}

func dashboard(c *gin.Context) {
	db := core.GetDB()
	var pending, processing, completedToday, onlineTechnicians int64
	db.Model(&RepairTicket{}).Where("status = ?", "待派单").Count(&pending)
	db.Model(&RepairTicket{}).Where("status IN ?", []string{"已派单", "处理中"}).Count(&processing)
	db.Model(&RepairTicket{}).Where("status = ?", "已完成").Count(&completedToday)
	db.Model(&Technician{}).Where("status = ?", "在线").Count(&onlineTechnicians)
	core.Success(c, gin.H{
		"pending": pending, "processing": processing, "completed_today": completedToday,
		"online_technicians": onlineTechnicians, "average_response_minutes": 12, "sla_rate": 96.4,
	})
}

func createTicket(c *gin.Context) {
	var input CreateTicketRequest
	if err := c.ShouldBindJSON(&input); err != nil {
		core.BadRequest(c, "请完整填写报修信息")
		return
	}
	now := time.Now()
	priorityHours := map[string]time.Duration{"紧急": 2, "高": 4, "普通": 12}
	hours, ok := priorityHours[input.Priority]
	if !ok {
		core.BadRequest(c, "优先级必须为紧急、高或普通")
		return
	}
	var count int64
	core.GetDB().Model(&RepairTicket{}).Count(&count)
	ticket := RepairTicket{
		TicketNo: fmt.Sprintf("BX-%s-%04d", now.Format("20060102"), count+1),
		Title:    strings.TrimSpace(input.Title), Category: input.Category, Building: input.Building,
		Zone: input.Zone, Priority: input.Priority, Status: "待派单",
		Description: strings.TrimSpace(input.Description), Reporter: strings.TrimSpace(input.Reporter), DueAt: now.Add(hours * time.Hour),
	}
	if err := core.GetDB().Create(&ticket).Error; err != nil {
		core.InternalServerError(c, "报修工单创建失败")
		return
	}
	core.Created(c, "报修工单已创建", ticket)
}

func dispatchTicket(c *gin.Context) {
	var input DispatchRequest
	if err := c.ShouldBindJSON(&input); err != nil {
		core.BadRequest(c, "请选择待派单工单")
		return
	}
	db := core.GetDB()
	var ticket RepairTicket
	if err := db.First(&ticket, input.TicketID).Error; err != nil {
		core.NotFound(c, "工单不存在")
		return
	}
	if ticket.Status != "待派单" {
		core.BadRequest(c, "该工单已完成派单")
		return
	}
	candidates, err := rankCandidates(db, ticket)
	if err != nil || len(candidates) == 0 {
		core.InternalServerError(c, "当前没有可用维修人员")
		return
	}
	best := candidates[0]
	ticket.AssignedTechnicianID = &best.Technician.ID
	ticket.MatchScore = best.Score
	ticket.Status = "已派单"
	if err := db.Transaction(func(tx *gorm.DB) error {
		if err := tx.Save(&ticket).Error; err != nil {
			return err
		}
		return tx.Model(&Technician{}).Where("id = ?", best.Technician.ID).UpdateColumn("active_load", gorm.Expr("active_load + 1")).Error
	}); err != nil {
		core.InternalServerError(c, "自动派单失败")
		return
	}
	db.Preload("AssignedTechnician").First(&ticket, ticket.ID)
	core.SuccessWithMessage(c, "智能派单完成", gin.H{"ticket": ticket, "selected": best, "candidates": candidates})
}
