package repair

import "testing"

func TestCalculateDispatchScorePrefersTradeAndZone(t *testing.T) {
	ticket := RepairTicket{Category: "网络", Zone: "东区", Priority: "紧急"}
	matched := Technician{Trade: "网络运维", Zone: "东区", ActiveLoad: 1, Rating: 4.8}
	unmatched := Technician{Trade: "暖通设备", Zone: "西区", ActiveLoad: 0, Rating: 5.0}
	matchedScore, reasons := CalculateDispatchScore(ticket, matched)
	unmatchedScore, _ := CalculateDispatchScore(ticket, unmatched)
	if matchedScore <= unmatchedScore {
		t.Fatalf("matched technician score %d should exceed unmatched score %d", matchedScore, unmatchedScore)
	}
	if len(reasons) < 2 {
		t.Fatalf("expected explainable reasons, got %v", reasons)
	}
}

func TestCalculateDispatchScorePenalizesLoad(t *testing.T) {
	ticket := RepairTicket{Category: "水电", Zone: "南区", Priority: "普通"}
	idle := Technician{Trade: "水电维修", Zone: "南区", ActiveLoad: 0, Rating: 4.8}
	busy := idle
	busy.ActiveLoad = 5
	idleScore, _ := CalculateDispatchScore(ticket, idle)
	busyScore, _ := CalculateDispatchScore(ticket, busy)
	if idleScore <= busyScore {
		t.Fatalf("idle score %d should exceed busy score %d", idleScore, busyScore)
	}
}

func TestDispatchScoreIsCapped(t *testing.T) {
	ticket := RepairTicket{Category: "水电", Zone: "东区", Priority: "紧急"}
	technician := Technician{Trade: "水电维修", Zone: "东区", ActiveLoad: 0, Rating: 5.0}
	score, _ := CalculateDispatchScore(ticket, technician)
	if score > 100 {
		t.Fatalf("score must not exceed 100, got %d", score)
	}
}
