# EquipFlow 实验室设备预约与冲突调度系统

针对高校共享实验设备预约中“状态不透明、时段易冲突、替代资源难查找”等问题，
实现设备台账、预约日程、冲突检测、风险评分和替代设备推荐的一体化管理平台。
源码采用 React + Go/Gin + SQLite，适合资源受限的云主机部署。

本项目采用统一的本科毕业设计交付结构：

```text
lab-equipment-booking/
├── code/    # 可独立运行、测试和复现的完整源码
├── docs/    # 只保存最终毕业论文（DOCX，或 DOCX + PDF）
└── ppt/     # 只保存最终答辩 PPT（PPTX，可附 PDF 导出稿）
```

开发和运行请进入 `code/`，首次配置执行 `./manage.sh setup`。回到项目根目录后，最终交付前执行：

```bash
./code/manage.sh delivery-check --complete
```

`docs/` 不得放入开题报告、任务书、初稿、查重稿、设计说明、截图、Draw.io 图源或其他过程材料；
这些内容属于开发过程，不属于最终论文目录。`ppt/` 只保留最终答辩演示文稿及其 PDF 导出稿。
