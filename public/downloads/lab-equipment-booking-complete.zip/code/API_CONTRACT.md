# 前后端统一接口契约

本仓库中的 React、Vue 前端可以与 Django、Flask、Gin、Spring Boot 后端任意组合。
所有后端必须遵守本文约定，避免在前端增加针对某个框架的兼容分支。

## 基础约定

- 开发环境后端端口：`8181`
- API 前缀：`/api`
- JSON 字段：`snake_case`
- 鉴权头：`Authorization: Bearer <access_token>`
- 分页参数：`page`（从 1 开始）、`page_size`
- HTTP 状态码与响应体 `code` 保持一致

## 统一响应

```json
{
  "code": 200,
  "msg": "success",
  "data": null
}
```

分页数据固定为：

```json
{
  "count": 1,
  "next": null,
  "previous": null,
  "results": []
}
```

## 用户接口

| 方法 | 路径 | 鉴权 | 说明 |
| --- | --- | --- | --- |
| POST | `/api/users/register/` | 否 | 注册，成功返回 201 |
| POST | `/api/users/login/` | 否 | 登录 |
| POST | `/api/users/token/refresh/` | 否 | 刷新 access token |
| POST | `/api/users/logout/` | 是 | 登出 |
| GET | `/api/users/profile/` | 是 | 获取个人信息 |
| PUT | `/api/users/profile/` | 是 | 更新邮箱、手机号 |
| POST | `/api/users/password/change/` | 是 | 修改密码 |
| GET | `/api/users/list/` | 管理员 | 分页用户列表 |

注册字段为 `username`、`email`、`phone`、`password`、`password_confirm`；修改密码字段为
`old_password`、`new_password`、`new_password_confirm`；刷新和登出请求字段为 `refresh`。
