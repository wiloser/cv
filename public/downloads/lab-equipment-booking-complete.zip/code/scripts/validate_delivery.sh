#!/usr/bin/env bash

# 校验统一的毕设交付结构：code / docs / ppt。
set -euo pipefail

if (( BASH_VERSINFO[0] < 3 || (BASH_VERSINFO[0] == 3 && BASH_VERSINFO[1] < 2) )); then
  printf '错误：本脚本需要 Bash 3.2 或更高版本\n' >&2
  exit 2
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
ROOT="$(cd "$SCRIPT_DIR/.." && pwd -P)"
COMPLETE=0

usage() {
  cat <<'EOF'
用法：validate_delivery.sh [--root <完整项目目录>] [--complete]

默认检查目录边界和文件类型；--complete 额外要求 docs 中已有最终论文，
ppt 中已有最终答辩 PPT。
EOF
}

die() {
  printf '错误：%s\n' "$*" >&2
  exit 2
}

while (( $# > 0 )); do
  case "$1" in
    --root)
      (( $# >= 2 )) || die "--root 缺少参数"
      ROOT="$2"
      shift 2
      ;;
    --root=*)
      ROOT="${1#*=}"
      [[ -n "$ROOT" ]] || die "--root= 缺少参数"
      shift
      ;;
    --complete)
      COMPLETE=1
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *) die "未知参数：$1" ;;
  esac
done

[[ -d "$ROOT" && ! -L "$ROOT" ]] || die "完整项目目录必须是普通目录：$ROOT"
ROOT="$(cd "$ROOT" && pwd -P)"

for directory in code docs ppt; do
  [[ -d "$ROOT/$directory" && ! -L "$ROOT/$directory" ]] || \
    die "缺少普通目录：$directory"
done

for entry in "$ROOT/code/frontend" "$ROOT/code/backend" "$ROOT/code/scripts"; do
  [[ -d "$entry" && ! -L "$entry" ]] || die "code 缺少普通目录：${entry#"$ROOT/code/"}"
done

for entry in .bishe-project.json .env.example .gitignore API_CONTRACT.md README.md manage.sh; do
  [[ -f "$ROOT/code/$entry" && ! -L "$ROOT/code/$entry" ]] || \
    die "code 缺少普通文件：$entry"
done
[[ -x "$ROOT/code/manage.sh" ]] || die "code/manage.sh 必须可执行"

while IFS= read -r -d '' entry; do
  name="$(basename "$entry")"
  [[ ! -L "$entry" ]] || die "项目顶层不允许符号链接：$name"
  case "$name" in
    .git|.gitignore|README.md|code|docs|ppt) ;;
    *) die "项目顶层只能包含 code、docs、ppt 及必要的 Git/说明文件：$name" ;;
  esac
done < <(find "$ROOT" -mindepth 1 -maxdepth 1 -print0)

thesis_count=0
while IFS= read -r -d '' entry; do
  name="$(basename "$entry")"
  [[ ! -L "$entry" ]] || die "docs 不允许符号链接：$name"
  [[ -f "$entry" ]] || die "docs 只允许最终论文文件，不能包含子目录：$name"
  case "$name" in
    .gitkeep) continue ;;
    *.docx|*.pdf) ;;
    *) die "docs 只允许最终论文的 .docx 或 .pdf：$name" ;;
  esac
  case "$name" in
    *论文*|*thesis*|*Thesis*) ;;
    *) die "docs 文件名必须明确包含“论文”或 thesis：$name" ;;
  esac
  case "$name" in
    *初稿*|*草稿*|*开题*|*中期*|*任务书*|*过程*|*临时*)
      die "docs 不能保存过程稿或阶段材料：$name"
      ;;
  esac
  thesis_count=$((thesis_count + 1))
done < <(find "$ROOT/docs" -mindepth 1 -maxdepth 1 -print0)
(( thesis_count <= 2 )) || die "docs 最多保存最终论文的 DOCX 与 PDF 两种格式"

ppt_count=0
while IFS= read -r -d '' entry; do
  name="$(basename "$entry")"
  [[ ! -L "$entry" ]] || die "ppt 不允许符号链接：$name"
  [[ -f "$entry" ]] || die "ppt 不允许子目录：$name"
  case "$name" in
    .gitkeep) continue ;;
    *.pptx) ppt_count=$((ppt_count + 1)) ;;
    *.pdf) ;;
    *) die "ppt 只允许最终答辩 .pptx 及其 PDF 导出稿：$name" ;;
  esac
  case "$name" in
    *初稿*|*草稿*|*临时*) die "ppt 不能保存过程稿：$name" ;;
  esac
done < <(find "$ROOT/ppt" -mindepth 1 -maxdepth 1 -print0)

if (( COMPLETE == 1 )); then
  (( thesis_count >= 1 )) || die "完整交付的 docs 必须包含最终论文"
  (( ppt_count == 1 )) || die "完整交付的 ppt 必须且只能包含一份最终 .pptx"
fi

printf 'PASS 交付结构符合 code / docs / ppt 规范\n'
if (( COMPLETE == 1 )); then
  printf 'PASS 最终论文与答辩 PPT 已齐备\n'
fi
