#!/usr/bin/env bash

# 离线运行时仓库与项目工具链打包器。仅依赖 Bash 3.2 和系统基础命令。
set -euo pipefail

if (( BASH_VERSINFO[0] < 3 || (BASH_VERSINFO[0] == 3 && BASH_VERSINFO[1] < 2) )); then
  printf '错误：本脚本需要 Bash 3.2 或更高版本\n' >&2
  exit 2
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd -P)"
TAB=$'\t'
WORK_DIR=""
SECOND_WORK=""
STAGED_TOOLCHAIN=""
STAGED_VENDOR=""
INSTALLED_VENDOR=""
INSTALLED_TOOLCHAIN=""
INSTALLED_ARCHIVE=""

STORE_TARGET=""
STORE_NAMES=()
STORE_PATHS=()
STORE_DIGESTS=()
BUNDLE_TARGET=""
BUNDLE_ID=""
BUNDLE_FRONTEND=""
BUNDLE_BACKEND=""
BUNDLE_NAMES=()
BUNDLE_PATHS=()
BUNDLE_DIGESTS=()
REQUIRED_COMPONENTS=()

die() {
  printf '错误：%s\n' "$*" >&2
  exit 2
}

safe_remove() {
  local path="$1"
  [[ -e "$path" || -L "$path" ]] || return 0
  if [[ -d "$path" && ! -L "$path" ]]; then
    find "$path" -type d -exec chmod u+w {} + 2>/dev/null || true
    rm -rf -- "$path"
  else
    rm -f -- "$path"
  fi
}

cleanup() {
  [[ -z "$WORK_DIR" ]] || safe_remove "$WORK_DIR"
  [[ -z "$SECOND_WORK" ]] || safe_remove "$SECOND_WORK"
  [[ -z "$STAGED_TOOLCHAIN" ]] || safe_remove "$STAGED_TOOLCHAIN"
  [[ -z "$STAGED_VENDOR" ]] || safe_remove "$STAGED_VENDOR"
  [[ -z "$INSTALLED_VENDOR" ]] || safe_remove "$INSTALLED_VENDOR"
  [[ -z "$INSTALLED_TOOLCHAIN" ]] || safe_remove "$INSTALLED_TOOLCHAIN"
  [[ -z "$INSTALLED_ARCHIVE" ]] || safe_remove "$INSTALLED_ARCHIVE"
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' HUP TERM

usage() {
  cat <<'EOF'
用法：scripts/runtime_bundle.sh <命令> [选项]

命令：
  detect-target
      输出当前平台标识。

  verify-store --store <目录> --frontend <react|vue>
               --backend <django|flask|gin|springboot>
               [--allow-foreign] [--allow-incomplete]
      校验离线仓库的清单、平台、组件内容及 SHA-256。

  write-bundle --root <项目目录> [--store <目录>]
               --frontend <react|vue> --backend <后端>
               --target <平台> --bundle-id <标识>
      将选定运行时原子写入项目的 .toolchain；未指定 store 时使用
      offline-store/<target>。Gin vendor 写入 backend/vendor。

  verify-bundle --root <项目目录> --frontend <react|vue>
                --backend <django|flask|gin|springboot> [--allow-foreign]
      校验项目离线工具链及其完整性。

  archive --project <项目目录> --output <文件.tar.gz>
      校验后打包项目，排除 .env、.runtime、.git，拒绝其他 .env*，
      并写入 .sha256 校验文件。
EOF
}

valid_target() {
  case "$1" in
    darwin-arm64|darwin-x86_64|linux-gnu-arm64|linux-gnu-x86_64) return 0 ;;
    *) return 1 ;;
  esac
}

valid_frontend() {
  [[ "$1" == react || "$1" == vue ]]
}

valid_backend() {
  case "$1" in django|flask|gin|springboot) return 0 ;; *) return 1 ;; esac
}

valid_store_component() {
  case "$1" in
    node|python|go|jdk|maven|npm-cache-react|npm-cache-vue|pip-cache-django|pip-cache-flask|maven-cache|gin-vendor) return 0 ;;
    *) return 1 ;;
  esac
}

valid_bundle_component() {
  case "$1" in
    node|python|go|jdk|maven|npm-cache|pip-cache|maven-cache|gin-vendor) return 0 ;;
    *) return 1 ;;
  esac
}

valid_bundle_id() {
  [[ "$1" =~ ^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$ ]]
}

detect_target() {
  local kernel machine libc
  kernel="$(uname -s)"
  machine="$(uname -m)"
  if [[ "$kernel" == Linux ]]; then
    libc=""
    if command -v getconf >/dev/null 2>&1; then
      libc="$(getconf GNU_LIBC_VERSION 2>/dev/null || true)"
    fi
    if [[ "$libc" != glibc\ * && "$libc" != GNU\ libc\ * ]]; then
      libc="$(ldd --version 2>&1 | sed -n '1p' || true)"
    fi
    case "$libc" in *musl*|*MUSL*|'') die "当前仅支持 GNU/glibc Linux，不支持 musl 或无法识别的 libc" ;; esac
    case "$libc" in *glibc*|*GLIBC*|*GNU\ libc*|*GNU\ C\ Library*) ;; *) die "当前仅支持 GNU/glibc Linux：$libc" ;; esac
  fi
  case "$kernel:$machine" in
    Darwin:arm64|Darwin:aarch64) printf 'darwin-arm64\n' ;;
    Darwin:x86_64|Darwin:amd64) printf 'darwin-x86_64\n' ;;
    Linux:arm64|Linux:aarch64) printf 'linux-gnu-arm64\n' ;;
    Linux:x86_64|Linux:amd64) printf 'linux-gnu-x86_64\n' ;;
    *) die "不支持的平台或架构：$kernel $machine" ;;
  esac
}

sha256_file() {
  local path="$1"
  if command -v shasum >/dev/null 2>&1; then
    shasum -a 256 "$path" | awk '{print $1}'
  elif command -v sha256sum >/dev/null 2>&1; then
    sha256sum "$path" | awk '{print $1}'
  else
    die "缺少 SHA-256 工具：需要系统自带的 shasum 或 sha256sum"
  fi
}

mode_of() {
  local path="$1"
  if [[ "$(uname -s)" == Darwin ]]; then
    stat -f '%Lp' "$path"
  else
    stat -c '%a' "$path"
  fi
}

normalize_abs_path() {
  local value="$1"
  [[ "$value" == /* ]] || value="$PWD/$value"
  LC_ALL=C awk -v path="$value" '
    BEGIN {
      count = split(path, parts, "/")
      top = 0
      for (i = 1; i <= count; i++) {
        if (parts[i] == "" || parts[i] == ".") continue
        if (parts[i] == "..") { if (top > 0) top--; continue }
        stack[++top] = parts[i]
      }
      if (top == 0) { print "/"; exit }
      result = ""
      for (i = 1; i <= top; i++) result = result "/" stack[i]
      print result
    }
  '
}

existing_directory() {
  local value="$1"
  [[ -d "$value" && ! -L "$value" ]] || die "目录不存在或本身是符号链接：$value"
  (cd "$value" && pwd -P)
}

assert_no_control_names() {
  local root="$1" pattern found
  for pattern in $'*\n*' $'*\r*' $'*\t*' '*\*'; do
    found="$(find "$root" -name "$pattern" -print -quit 2>/dev/null || true)"
    [[ -z "$found" ]] || die "路径名含换行、回车或制表符：$found"
  done
}

assert_regular_tree() {
  local root="$1" special
  [[ -d "$root" && ! -L "$root" ]] || die "组件目录无效：$root"
  assert_no_control_names "$root"
  assert_safe_symlinks "$root"
  special="$(find "$root" ! -type d ! -type f ! -type l -print -quit 2>/dev/null || true)"
  [[ -z "$special" ]] || die "离线组件含非常规文件：$special"
}

seal_tree() {
  local root="$1"
  find "$root" \( -type d -o -type f \) -exec chmod a-w {} +
}

assert_read_only_tree() {
  local root="$1" writable
  if [[ "$(uname -s)" == Darwin ]]; then
    writable="$(find "$root" \( -type d -o -type f \) -perm +222 -print -quit 2>/dev/null || true)"
  else
    writable="$(find "$root" \( -type d -o -type f \) -perm /222 -print -quit 2>/dev/null || true)"
  fi
  [[ -z "$writable" ]] || die "离线组件仍有写权限：$writable"
}

assert_safe_symlinks() {
  local root="$1" link target link_dir lexical
  assert_no_control_names "$root"
  while IFS= read -r link; do
    [[ -n "$link" ]] || continue
    target="$(readlink "$link")" || die "无法读取符号链接：$link"
    case "$target" in /*|'') die "符号链接目标不安全：$link -> $target" ;; esac
    [[ "$target" != *$'\n'* && "$target" != *$'\r'* && "$target" != *$'\t'* ]] || \
      die "符号链接目标含控制字符：$link"
    link_dir="$(dirname "$link")"
    lexical="$(normalize_abs_path "$link_dir/$target")"
    case "$lexical" in "$root"|"$root"/*) ;; *) die "符号链接逃逸项目目录：$link -> $target" ;; esac
    [[ -e "$link" ]] || die "符号链接目标不存在：$link -> $target"
  done < <(find "$root" -type l -print)
}

append_file_hash_records() {
  local root="$1" listing="$2" line digest path relative
  while IFS= read -r line; do
    [[ -n "$line" ]] || continue
    digest="${line%% *}"
    [[ "$digest" =~ ^[0-9a-f]{64}$ ]] || die "无法解析文件 SHA-256：$line"
    path="${line#"$digest"}"
    path="${path# }"
    path="${path# }"
    [[ "$path" == /* ]] || die "无法解析 SHA-256 文件路径：$line"
    relative="${path#"$root"/}"
    printf 'F\t%s\t%s\n' "$digest" "$relative" >>"$listing"
  done
}

tree_digest() {
  local root="$1" listing sorted path relative digest target
  assert_regular_tree "$root"
  listing="$(mktemp "${TMPDIR:-/tmp}/bishe-tree.XXXXXX")" || die "无法创建临时文件"
  WORK_DIR="$listing"
  while IFS= read -r path; do
    relative="${path#"$root"/}"
    printf 'D\t-\t%s\n' "$relative" >>"$listing"
  done < <(find "$root" -mindepth 1 -type d -print)
  if command -v shasum >/dev/null 2>&1; then
    append_file_hash_records "$root" "$listing" < <(find "$root" -type f -exec shasum -a 256 {} +)
  else
    command -v sha256sum >/dev/null 2>&1 || die "缺少 SHA-256 工具"
    append_file_hash_records "$root" "$listing" < <(find "$root" -type f -exec sha256sum {} +)
  fi
  while IFS= read -r path; do
    relative="${path#"$root"/}"
    target="$(readlink "$path")"
    printf 'L\t%s\t%s\n' "$target" "$relative" >>"$listing"
  done < <(find "$root" -type l -print)
  sorted="$(mktemp "${TMPDIR:-/tmp}/bishe-tree-sorted.XXXXXX")" || die "无法创建临时文件"
  LC_ALL=C sort "$listing" >"$sorted"
  digest="$(sha256_file "$sorted")"
  rm -f -- "$listing" "$sorted"
  WORK_DIR=""
  printf '%s\n' "$digest"
}

component_destination() {
  case "$1" in
    node) printf '.toolchain/runtimes/node\n' ;;
    python) printf '.toolchain/runtimes/python\n' ;;
    go) printf '.toolchain/runtimes/go\n' ;;
    jdk) printf '.toolchain/runtimes/jdk\n' ;;
    maven) printf '.toolchain/runtimes/maven\n' ;;
    npm-cache) printf '.toolchain/cache/npm\n' ;;
    pip-cache) printf '.toolchain/cache/pip\n' ;;
    maven-cache) printf '.toolchain/cache/maven\n' ;;
    gin-vendor) printf 'backend/vendor\n' ;;
    *) die "未知组件：$1" ;;
  esac
}

set_required_store_components() {
  local frontend="$1" backend="$2"
  valid_frontend "$frontend" || die "无效前端：$frontend"
  valid_backend "$backend" || die "无效后端：$backend"
  REQUIRED_COMPONENTS=(node "npm-cache-$frontend")
  case "$backend" in
    django|flask) REQUIRED_COMPONENTS+=(python "pip-cache-$backend") ;;
    gin) REQUIRED_COMPONENTS+=(go gin-vendor) ;;
    springboot) REQUIRED_COMPONENTS+=(jdk maven maven-cache) ;;
  esac
}

set_required_bundle_components() {
  local frontend="$1" backend="$2"
  valid_frontend "$frontend" || die "无效前端：$frontend"
  valid_backend "$backend" || die "无效后端：$backend"
  REQUIRED_COMPONENTS=(node npm-cache)
  case "$backend" in
    django|flask) REQUIRED_COMPONENTS+=(python pip-cache) ;;
    gin) REQUIRED_COMPONENTS+=(go gin-vendor) ;;
    springboot) REQUIRED_COMPONENTS+=(jdk maven maven-cache) ;;
  esac
}

store_to_bundle_component() {
  case "$1" in
    npm-cache-react|npm-cache-vue) printf 'npm-cache\n' ;;
    pip-cache-django|pip-cache-flask) printf 'pip-cache\n' ;;
    *) printf '%s\n' "$1" ;;
  esac
}

array_contains() {
  local wanted="$1"
  shift
  local item
  for item in "$@"; do
    [[ "$item" == "$wanted" ]] && return 0
  done
  return 1
}

component_index() {
  local wanted="$1"
  shift
  local index=0 item
  for item in "$@"; do
    if [[ "$item" == "$wanted" ]]; then
      printf '%s\n' "$index"
      return 0
    fi
    index=$((index + 1))
  done
  return 1
}

validate_component_content() {
  local name="$1" root="$2" found
  case "$name" in
    node)
      [[ -x "$root/bin/node" ]] || die "Node 组件缺少可执行文件 bin/node"
      [[ -x "$root/bin/npm" ]] || die "Node 组件缺少可执行文件 bin/npm"
      ;;
    python)
      [[ -x "$root/bin/python3" ]] || die "Python 组件缺少可执行文件 bin/python3"
      ;;
    go) [[ -x "$root/bin/go" ]] || die "Go 组件缺少可执行文件 bin/go" ;;
    jdk)
      [[ -x "$root/bin/java" ]] || die "JDK 组件缺少可执行文件 bin/java"
      [[ -x "$root/bin/javac" ]] || die "JDK 组件缺少可执行文件 bin/javac"
      ;;
    maven) [[ -x "$root/bin/mvn" ]] || die "Maven 组件缺少可执行文件 bin/mvn" ;;
    npm-cache|npm-cache-react|npm-cache-vue)
      [[ -d "$root/_cacache" ]] || die "npm 缓存组件缺少 _cacache 目录"
      found="$(find "$root/_cacache" -type f -print -quit 2>/dev/null || true)"
      [[ -n "$found" ]] || die "npm 缓存组件为空"
      ;;
    pip-cache|pip-cache-django|pip-cache-flask)
      found="$(find "$root" -mindepth 1 -maxdepth 1 -type f -name '*.whl' -print -quit 2>/dev/null || true)"
      [[ -n "$found" ]] || die "pip 缓存组件根目录必须直接包含 wheel 文件"
      ;;
    maven-cache)
      found="$(find "$root" -type f \( -name '*.jar' -o -name '*.pom' \) -print -quit 2>/dev/null || true)"
      [[ -n "$found" ]] || die "Maven 缓存组件不含 jar 或 pom"
      ;;
    gin-vendor)
      [[ -f "$root/modules.txt" ]] || die "Gin vendor 组件缺少 modules.txt"
      ;;
  esac
}

assert_store_shape() {
  local store="$1" entry base
  while IFS= read -r entry; do
    base="$(basename "$entry")"
    case "$base" in manifest.tsv|components) ;; *) die "离线仓库含未声明的顶层条目：$base" ;; esac
  done < <(find "$store" -mindepth 1 -maxdepth 1 -print)
  [[ -d "$store/components" && ! -L "$store/components" ]] || die "离线仓库缺少普通目录 components"
  while IFS= read -r entry; do
    base="$(basename "$entry")"
    array_contains "$base" "${STORE_NAMES[@]}" || die "离线仓库含未声明组件目录：$base"
  done < <(find "$store/components" -mindepth 1 -maxdepth 1 -print)
}

assert_bundle_shape() {
  local root="$1" entry base name index expected
  while IFS= read -r entry; do
    base="$(basename "$entry")"
    case "$base" in bundle.manifest|runtimes|cache) ;; *) die "工具链含未声明的顶层条目：$base" ;; esac
  done < <(find "$root/.toolchain" -mindepth 1 -maxdepth 1 -print)
  for entry in "$root/.toolchain/runtimes" "$root/.toolchain/cache"; do
    [[ -e "$entry" ]] || continue
    [[ -d "$entry" && ! -L "$entry" ]] || die "工具链分区不是普通目录：$entry"
    while IFS= read -r base; do
      [[ -n "$base" ]] || continue
      expected=0
      index=0
      for name in "${BUNDLE_NAMES[@]}"; do
        if [[ "$root/${BUNDLE_PATHS[$index]}" == "$entry/$base" ]]; then
          expected=1
          break
        fi
        index=$((index + 1))
      done
      [[ "$expected" == 1 ]] || die "工具链含未声明组件目录：${entry#"$root"/}/$base"
    done < <(find "$entry" -mindepth 1 -maxdepth 1 -exec basename {} \;)
  done
}

parse_store_manifest() {
  local store="$1" manifest line_number=0 f1 f2 f3 f4 f5 schema_count=0 target_count=0
  manifest="$store/manifest.tsv"
  [[ -f "$manifest" && ! -L "$manifest" ]] || die "离线仓库缺少普通文件 manifest.tsv：$store"
  [[ "$(mode_of "$manifest")" == 644 ]] || die "store manifest 权限必须为 0644"
  STORE_TARGET=""
  STORE_NAMES=()
  STORE_PATHS=()
  STORE_DIGESTS=()
  while IFS="$TAB" read -r f1 f2 f3 f4 f5 || [[ -n "${f1:-}${f2:-}${f3:-}${f4:-}${f5:-}" ]]; do
    line_number=$((line_number + 1))
    [[ "$f1$f2$f3$f4$f5" != *$'\r'* ]] || die "store manifest 第 $line_number 行含回车"
    [[ -z "${f5:-}" ]] || die "store manifest 第 $line_number 行字段过多"
    case "$f1" in
      schema_version)
        [[ -n "$f2" && -z "${f3:-}${f4:-}" ]] || die "store manifest schema_version 格式错误"
        schema_count=$((schema_count + 1))
        [[ "$f2" == 1 ]] || die "不支持的 store manifest 版本：$f2"
        ;;
      target)
        [[ -n "$f2" && -z "${f3:-}${f4:-}" ]] || die "store manifest target 格式错误"
        target_count=$((target_count + 1))
        valid_target "$f2" || die "store manifest 平台无效：$f2"
        STORE_TARGET="$f2"
        ;;
      component)
        [[ -n "$f2" && -n "$f3" && -n "$f4" ]] || die "store manifest component 格式错误"
        valid_store_component "$f2" || die "store manifest 组件无效：$f2"
        if (( ${#STORE_NAMES[@]} > 0 )) && array_contains "$f2" "${STORE_NAMES[@]}"; then
          die "store manifest 组件重复：$f2"
        fi
        [[ "$f3" == "components/$f2" ]] || die "store manifest 组件路径必须为 components/$f2"
        [[ "$f4" =~ ^[0-9a-f]{64}$ ]] || die "store manifest SHA-256 无效：$f2"
        STORE_NAMES+=("$f2")
        STORE_PATHS+=("$f3")
        STORE_DIGESTS+=("$f4")
        ;;
      '') die "store manifest 第 $line_number 行为空" ;;
      *) die "store manifest 第 $line_number 行键无效：$f1" ;;
    esac
  done <"$manifest"
  [[ "$schema_count" == 1 && "$target_count" == 1 ]] || \
    die "store manifest 必须各含一个 schema_version 和 target"
  (( ${#STORE_NAMES[@]} > 0 )) || die "store manifest 未声明组件"
  assert_store_shape "$store"
}

verify_store_root() {
  local store="$1" frontend="$2" backend="$3" allow_foreign="${4:-0}" allow_incomplete="${5:-0}"
  local host index name path actual required
  store="$(existing_directory "$store")"
  set_required_store_components "$frontend" "$backend"
  parse_store_manifest "$store"
  host="$(detect_target)"
  if [[ "$allow_foreign" != 1 ]]; then
    [[ "$STORE_TARGET" == "$host" ]] || die "离线仓库平台为 $STORE_TARGET，当前平台为 $host"
  fi
  if [[ "$allow_incomplete" != 1 ]]; then
    for required in "${REQUIRED_COMPONENTS[@]}"; do
      array_contains "$required" "${STORE_NAMES[@]}" || die "离线仓库缺少组件：$required"
    done
  fi
  index=0
  for name in "${STORE_NAMES[@]}"; do
    if [[ "$allow_incomplete" != 1 ]] && ! array_contains "$name" "${REQUIRED_COMPONENTS[@]}"; then
      index=$((index + 1))
      continue
    fi
    path="$store/${STORE_PATHS[$index]}"
    [[ -d "$path" && ! -L "$path" ]] || die "离线仓库组件目录无效：$path"
    validate_component_content "$name" "$path"
    actual="$(tree_digest "$path")"
    [[ "$actual" == "${STORE_DIGESTS[$index]}" ]] || die "离线仓库组件 SHA-256 不匹配：$name"
    assert_read_only_tree "$path"
    index=$((index + 1))
  done
  printf 'PASS 离线仓库校验通过：%s，%s + %s\n' "$STORE_TARGET" "$frontend" "$backend"
}

parse_bundle_manifest() {
  local root="$1" manifest line_number=0 f1 f2 f3 f4 f5
  local schema_count=0 target_count=0 id_count=0 frontend_count=0 backend_count=0
  manifest="$root/.toolchain/bundle.manifest"
  [[ -f "$manifest" && ! -L "$manifest" ]] || die "项目缺少普通文件 .toolchain/bundle.manifest"
  [[ "$(mode_of "$manifest")" == 444 ]] || die "bundle manifest 权限必须为 0444"
  BUNDLE_TARGET=""
  BUNDLE_ID=""
  BUNDLE_FRONTEND=""
  BUNDLE_BACKEND=""
  BUNDLE_NAMES=()
  BUNDLE_PATHS=()
  BUNDLE_DIGESTS=()
  while IFS="$TAB" read -r f1 f2 f3 f4 f5 || [[ -n "${f1:-}${f2:-}${f3:-}${f4:-}${f5:-}" ]]; do
    line_number=$((line_number + 1))
    [[ "$f1$f2$f3$f4$f5" != *$'\r'* ]] || die "bundle manifest 第 $line_number 行含回车"
    [[ -z "${f5:-}" ]] || die "bundle manifest 第 $line_number 行字段过多"
    case "$f1" in
      schema_version)
        [[ -n "$f2" && -z "${f3:-}${f4:-}" ]] || die "bundle manifest schema_version 格式错误"
        schema_count=$((schema_count + 1)); [[ "$f2" == 1 ]] || die "不支持的 bundle manifest 版本：$f2"
        ;;
      target)
        [[ -n "$f2" && -z "${f3:-}${f4:-}" ]] || die "bundle manifest target 格式错误"
        target_count=$((target_count + 1)); valid_target "$f2" || die "bundle manifest 平台无效：$f2"; BUNDLE_TARGET="$f2"
        ;;
      bundle_id)
        [[ -n "$f2" && -z "${f3:-}${f4:-}" ]] || die "bundle manifest bundle_id 格式错误"
        id_count=$((id_count + 1)); valid_bundle_id "$f2" || die "bundle_id 无效：$f2"; BUNDLE_ID="$f2"
        ;;
      frontend)
        [[ -n "$f2" && -z "${f3:-}${f4:-}" ]] || die "bundle manifest frontend 格式错误"
        frontend_count=$((frontend_count + 1)); valid_frontend "$f2" || die "bundle manifest 前端无效：$f2"; BUNDLE_FRONTEND="$f2"
        ;;
      backend)
        [[ -n "$f2" && -z "${f3:-}${f4:-}" ]] || die "bundle manifest backend 格式错误"
        backend_count=$((backend_count + 1)); valid_backend "$f2" || die "bundle manifest 后端无效：$f2"; BUNDLE_BACKEND="$f2"
        ;;
      component)
        [[ -n "$f2" && -n "$f3" && -n "$f4" ]] || die "bundle manifest component 格式错误"
        valid_bundle_component "$f2" || die "bundle manifest 组件无效：$f2"
        if (( ${#BUNDLE_NAMES[@]} > 0 )) && array_contains "$f2" "${BUNDLE_NAMES[@]}"; then
          die "bundle manifest 组件重复：$f2"
        fi
        [[ "$f3" == "$(component_destination "$f2")" ]] || die "bundle manifest 组件路径错误：$f2"
        [[ "$f4" =~ ^[0-9a-f]{64}$ ]] || die "bundle manifest SHA-256 无效：$f2"
        BUNDLE_NAMES+=("$f2"); BUNDLE_PATHS+=("$f3"); BUNDLE_DIGESTS+=("$f4")
        ;;
      '') die "bundle manifest 第 $line_number 行为空" ;;
      *) die "bundle manifest 第 $line_number 行键无效：$f1" ;;
    esac
  done <"$manifest"
  [[ "$schema_count" == 1 && "$target_count" == 1 && "$id_count" == 1 && \
     "$frontend_count" == 1 && "$backend_count" == 1 ]] || \
    die "bundle manifest 的固定字段必须各出现一次"
  (( ${#BUNDLE_NAMES[@]} > 0 )) || die "bundle manifest 未声明组件"
  assert_bundle_shape "$root"
}

verify_bundle_root() {
  local root="$1" frontend="$2" backend="$3" allow_foreign="${4:-0}"
  local host required name index path actual
  root="$(existing_directory "$root")"
  [[ -d "$root/.toolchain" && ! -L "$root/.toolchain" ]] || die "项目缺少普通目录 .toolchain"
  parse_bundle_manifest "$root"
  [[ "$BUNDLE_FRONTEND" == "$frontend" ]] || die "工具链前端为 $BUNDLE_FRONTEND，项目要求 $frontend"
  [[ "$BUNDLE_BACKEND" == "$backend" ]] || die "工具链后端为 $BUNDLE_BACKEND，项目要求 $backend"
  host="$(detect_target)"
  if [[ "$allow_foreign" != 1 ]]; then
    [[ "$BUNDLE_TARGET" == "$host" ]] || die "工具链平台为 $BUNDLE_TARGET，当前平台为 $host"
  fi
  set_required_bundle_components "$frontend" "$backend"
  (( ${#BUNDLE_NAMES[@]} == ${#REQUIRED_COMPONENTS[@]} )) || die "bundle manifest 组件数量不符"
  for required in "${REQUIRED_COMPONENTS[@]}"; do
    array_contains "$required" "${BUNDLE_NAMES[@]}" || die "工具链缺少组件：$required"
  done
  index=0
  for name in "${BUNDLE_NAMES[@]}"; do
    path="$root/${BUNDLE_PATHS[$index]}"
    [[ -d "$path" && ! -L "$path" ]] || die "工具链组件目录无效：${BUNDLE_PATHS[$index]}"
    validate_component_content "$name" "$path"
    actual="$(tree_digest "$path")"
    [[ "$actual" == "${BUNDLE_DIGESTS[$index]}" ]] || die "工具链组件 SHA-256 不匹配：$name"
    assert_read_only_tree "$path"
    index=$((index + 1))
  done
  assert_read_only_tree "$root/.toolchain"
  printf 'PASS 项目离线工具链校验通过：%s，bundle %s\n' "$BUNDLE_TARGET" "$BUNDLE_ID"
}

write_bundle() {
  local root="$1" store="$2" frontend="$3" backend="$4" target="$5" bundle_id="$6"
  local name bundle_name index source destination staged_destination digest manifest
  root="$(existing_directory "$root")"
  valid_target "$target" || die "无效平台：$target"
  valid_bundle_id "$bundle_id" || die "bundle-id 仅允许安全字母、数字、点、下划线和连字符，最长 128 字符"
  store="$(existing_directory "$store")"
  verify_store_root "$store" "$frontend" "$backend" 1 0 >/dev/null
  [[ "$STORE_TARGET" == "$target" ]] || die "离线仓库平台与请求平台不一致"
  [[ ! -e "$root/.toolchain" && ! -L "$root/.toolchain" ]] || die "项目已存在 .toolchain，不会覆盖"
  if array_contains gin-vendor "${REQUIRED_COMPONENTS[@]}"; then
    [[ -d "$root/backend" && ! -L "$root/backend" ]] || die "Gin 项目缺少普通目录 backend"
    [[ ! -e "$root/backend/vendor" && ! -L "$root/backend/vendor" ]] || die "backend/vendor 已存在，不会覆盖"
  fi
  STAGED_TOOLCHAIN="$root/.toolchain.stage.$$"
  [[ ! -e "$STAGED_TOOLCHAIN" ]] || die "暂存目录已存在：$STAGED_TOOLCHAIN"
  mkdir -p "$STAGED_TOOLCHAIN"
  manifest="$STAGED_TOOLCHAIN/bundle.manifest"
  {
    printf 'schema_version\t1\n'
    printf 'target\t%s\n' "$target"
    printf 'bundle_id\t%s\n' "$bundle_id"
    printf 'frontend\t%s\n' "$frontend"
    printf 'backend\t%s\n' "$backend"
  } >"$manifest"
  set_required_store_components "$frontend" "$backend"
  for name in "${REQUIRED_COMPONENTS[@]}"; do
    index="$(component_index "$name" "${STORE_NAMES[@]}")" || die "离线仓库缺少组件：$name"
    source="$store/${STORE_PATHS[$index]}"
    bundle_name="$(store_to_bundle_component "$name")"
    destination="$(component_destination "$bundle_name")"
    if [[ "$bundle_name" == gin-vendor ]]; then
      STAGED_VENDOR="$root/backend/.vendor.stage.$$"
      staged_destination="$STAGED_VENDOR"
    else
      staged_destination="$STAGED_TOOLCHAIN/${destination#.toolchain/}"
    fi
    mkdir -p "$staged_destination"
    cp -R "$source"/. "$staged_destination"/
    assert_regular_tree "$staged_destination"
    seal_tree "$staged_destination"
    validate_component_content "$bundle_name" "$staged_destination"
    digest="$(tree_digest "$staged_destination")"
    [[ "$digest" == "${STORE_DIGESTS[$index]}" ]] || die "复制后组件 SHA-256 不匹配：$name"
    printf 'component\t%s\t%s\t%s\n' "$bundle_name" "$destination" "$digest" >>"$manifest"
  done
  chmod 0444 "$manifest"
  seal_tree "$STAGED_TOOLCHAIN"
  if [[ -n "$STAGED_VENDOR" ]]; then
    mv "$STAGED_VENDOR" "$root/backend/vendor"
    STAGED_VENDOR=""
    INSTALLED_VENDOR="$root/backend/vendor"
  fi
  mv "$STAGED_TOOLCHAIN" "$root/.toolchain"
  STAGED_TOOLCHAIN=""
  INSTALLED_TOOLCHAIN="$root/.toolchain"
  verify_bundle_root "$root" "$frontend" "$backend" 1 >/dev/null
  INSTALLED_TOOLCHAIN=""
  INSTALLED_VENDOR=""
  printf 'PASS 已写入离线工具链：%s/.toolchain\n' "$root"
}

archive_project() {
  local project="$1" output="$2" runtime_root output_abs output_parent output_base project_parent project_base secret
  local temp_archive temp_sidecar digest
  project="$(existing_directory "$project")"
  [[ "$output" == *.tar.gz ]] || die "归档输出必须以 .tar.gz 结尾"
  output_abs="$(normalize_abs_path "$output")"
  case "$output_abs" in "$project"|"$project"/*) die "归档输出不能位于项目目录内部" ;; esac
  output_parent="$(dirname "$output_abs")"
  [[ -d "$output_parent" ]] || die "归档输出父目录不存在：$output_parent"
  output_parent="$(cd "$output_parent" && pwd -P)"
  output_base="$(basename "$output_abs")"
  output_abs="$output_parent/$output_base"
  case "$output_abs" in "$project"|"$project"/*) die "归档输出物理路径不能位于项目目录内部" ;; esac
  [[ ! -e "$output_abs" && ! -L "$output_abs" ]] || die "归档已存在，不会覆盖：$output_abs"
  [[ ! -e "$output_abs.sha256" && ! -L "$output_abs.sha256" ]] || die "校验文件已存在，不会覆盖：$output_abs.sha256"
  secret="$(find "$project" -name '.env*' ! -name '.env' ! -name '.env.example' -print -quit 2>/dev/null || true)"
  [[ -z "$secret" ]] || die "项目含额外环境秘密文件，归档前请移除：${secret#"$project"/}"
  runtime_root="$project"
  if [[ -d "$project/code" && ! -L "$project/code" && -f "$project/code/.bishe-project.json" ]]; then
    runtime_root="$project/code"
  fi
  parse_bundle_manifest "$runtime_root"
  verify_bundle_root "$runtime_root" "$BUNDLE_FRONTEND" "$BUNDLE_BACKEND" 1 >/dev/null
  assert_safe_symlinks "$project"
  project_parent="$(dirname "$project")"
  project_base="$(basename "$project")"
  temp_archive="$output_parent/.${output_base}.tmp.$$"
  temp_sidecar="$output_parent/.${output_base}.sha256.tmp.$$"
  WORK_DIR="$temp_archive"
  SECOND_WORK="$temp_sidecar"
  COPYFILE_DISABLE=1 tar -C "$project_parent" \
    --exclude='.env' --exclude='*/.env' \
    --exclude='.runtime' --exclude='*/.runtime' \
    --exclude='.git' --exclude='*/.git' \
    -czf "$temp_archive" -- "$project_base"
  digest="$(sha256_file "$temp_archive")"
  printf '%s  %s\n' "$digest" "$output_base" >"$temp_sidecar"
  mv "$temp_archive" "$output_abs"
  WORK_DIR=""
  INSTALLED_ARCHIVE="$output_abs"
  mv "$temp_sidecar" "$output_abs.sha256"
  SECOND_WORK=""
  INSTALLED_ARCHIVE=""
  printf 'PASS 项目归档已生成：%s\n' "$output_abs"
  printf 'PASS SHA-256：%s\n' "$digest"
}

require_value() {
  local option="$1" count="$2"
  (( count >= 2 )) || die "$option 缺少参数值"
}

COMMAND="${1:-help}"
(( $# == 0 )) || shift
case "$COMMAND" in
  help|-h|--help)
    (( $# == 0 )) || die "$COMMAND 不接受额外参数"
    usage
    ;;
  detect-target)
    (( $# == 0 )) || die "detect-target 不接受额外参数"
    detect_target
    ;;
  verify-store)
    STORE=""; FRONTEND=""; BACKEND=""; ALLOW_FOREIGN=0; ALLOW_INCOMPLETE=0
    while (( $# > 0 )); do
      case "$1" in
        --store) require_value "$1" "$#"; STORE="$2"; shift 2 ;;
        --frontend) require_value "$1" "$#"; FRONTEND="$2"; shift 2 ;;
        --backend) require_value "$1" "$#"; BACKEND="$2"; shift 2 ;;
        --allow-foreign) ALLOW_FOREIGN=1; shift ;;
        --allow-incomplete) ALLOW_INCOMPLETE=1; shift ;;
        *) die "verify-store 未知参数：$1" ;;
      esac
    done
    [[ -n "$STORE" && -n "$FRONTEND" && -n "$BACKEND" ]] || die "verify-store 必须指定 --store、--frontend 和 --backend"
    verify_store_root "$STORE" "$FRONTEND" "$BACKEND" "$ALLOW_FOREIGN" "$ALLOW_INCOMPLETE"
    ;;
  write-bundle)
    ROOT=""; STORE=""; FRONTEND=""; BACKEND=""; TARGET=""; BUNDLE=""
    while (( $# > 0 )); do
      case "$1" in
        --root) require_value "$1" "$#"; ROOT="$2"; shift 2 ;;
        --store) require_value "$1" "$#"; STORE="$2"; shift 2 ;;
        --frontend) require_value "$1" "$#"; FRONTEND="$2"; shift 2 ;;
        --backend) require_value "$1" "$#"; BACKEND="$2"; shift 2 ;;
        --target) require_value "$1" "$#"; TARGET="$2"; shift 2 ;;
        --bundle-id) require_value "$1" "$#"; BUNDLE="$2"; shift 2 ;;
        *) die "write-bundle 未知参数：$1" ;;
      esac
    done
    [[ -n "$ROOT" && -n "$FRONTEND" && -n "$BACKEND" && -n "$TARGET" && -n "$BUNDLE" ]] || \
      die "write-bundle 必须指定 --root、--frontend、--backend、--target 和 --bundle-id"
    [[ -n "$STORE" ]] || STORE="$REPO_ROOT/offline-store/$TARGET"
    write_bundle "$ROOT" "$STORE" "$FRONTEND" "$BACKEND" "$TARGET" "$BUNDLE"
    ;;
  verify-bundle)
    ROOT=""; FRONTEND=""; BACKEND=""; ALLOW_FOREIGN=0
    while (( $# > 0 )); do
      case "$1" in
        --root) require_value "$1" "$#"; ROOT="$2"; shift 2 ;;
        --frontend) require_value "$1" "$#"; FRONTEND="$2"; shift 2 ;;
        --backend) require_value "$1" "$#"; BACKEND="$2"; shift 2 ;;
        --allow-foreign) ALLOW_FOREIGN=1; shift ;;
        *) die "verify-bundle 未知参数：$1" ;;
      esac
    done
    [[ -n "$ROOT" && -n "$FRONTEND" && -n "$BACKEND" ]] || die "verify-bundle 必须指定 --root、--frontend 和 --backend"
    verify_bundle_root "$ROOT" "$FRONTEND" "$BACKEND" "$ALLOW_FOREIGN"
    ;;
  archive)
    PROJECT=""; OUTPUT=""
    while (( $# > 0 )); do
      case "$1" in
        --project) require_value "$1" "$#"; PROJECT="$2"; shift 2 ;;
        --output) require_value "$1" "$#"; OUTPUT="$2"; shift 2 ;;
        *) die "archive 未知参数：$1" ;;
      esac
    done
    [[ -n "$PROJECT" && -n "$OUTPUT" ]] || die "archive 必须指定 --project 和 --output"
    archive_project "$PROJECT" "$OUTPUT"
    ;;
  *)
    die "未知命令：$COMMAND；执行 scripts/runtime_bundle.sh --help 查看帮助"
    ;;
esac
