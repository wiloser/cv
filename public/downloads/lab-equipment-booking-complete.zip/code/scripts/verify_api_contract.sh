#!/usr/bin/env bash

# 使用 curl 执行统一用户 API 冒烟测试。JSON 解析仅依赖 POSIX awk，
# 不使用 jq、Python 或 Node.js，也不通过正则表达式猜测字段层级。
set -euo pipefail

if (( BASH_VERSINFO[0] < 3 || (BASH_VERSINFO[0] == 3 && BASH_VERSINFO[1] < 2) )); then
  printf 'FAIL 本脚本需要 Bash 3.2 或更高版本\n' >&2
  exit 2
fi

BASE_URL="http://127.0.0.1:8181"
CONNECT_TIMEOUT=3
MAX_TIME=15
ORIGIN="http://localhost:5173"
RESPONSE_BODY=""
RESPONSE_EXPECTED=""
RESPONSE_FILE=""
RESPONSE_VALUE_FILE=""
RESPONSE_STRING_VALUE=""

CONTROL_BYTE_PATTERN='(^|[[:space:]])(0[0-9A-Fa-f]|1[0-9A-Fa-f]|7[Ff])([[:space:]]|$)'

die() {
  printf 'FAIL %s\n' "$*" >&2
  exit 1
}

file_has_control_byte() {
  LC_ALL=C od -A n -t x1 -v "$1" |
    LC_ALL=C grep -Eq "$CONTROL_BYTE_PATTERN"
}

file_has_nul_byte() {
  LC_ALL=C od -A n -t x1 -v "$1" |
    LC_ALL=C grep -Eq '(^|[[:space:]])00([[:space:]]|$)'
}

value_has_control_byte() {
  LC_ALL=C printf '%s' "$1" |
    LC_ALL=C od -A n -t x1 -v |
    LC_ALL=C grep -Eq "$CONTROL_BYTE_PATTERN"
}

cleanup() {
  if [[ -n "$RESPONSE_FILE" && -f "$RESPONSE_FILE" ]]; then
    rm -f -- "$RESPONSE_FILE"
  fi
  if [[ -n "$RESPONSE_VALUE_FILE" && -f "$RESPONSE_VALUE_FILE" ]]; then
    rm -f -- "$RESPONSE_VALUE_FILE"
  fi
}

trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' HUP TERM

usage() {
  cat <<'EOF'
用法：./scripts/verify_api_contract.sh [基础地址] [选项]

  --base-url <http(s)://地址>  后端基础地址，默认 http://127.0.0.1:8181
  --connect-timeout <秒>       连接超时，默认 3
  --timeout <秒>               单次请求总超时，默认 15
  --origin <http(s)://地址>    跨域请求来源，默认 http://localhost:5173
  -h, --help                   显示帮助

为兼容既有用法，可将基础地址作为唯一位置参数。
EOF
}

positional_seen=0
while (( $# > 0 )); do
  case "$1" in
    --base-url)
      (( $# >= 2 )) || die "--base-url 缺少参数"
      BASE_URL="$2"; shift 2 ;;
    --base-url=*) BASE_URL="${1#*=}"; shift ;;
    --connect-timeout)
      (( $# >= 2 )) || die "--connect-timeout 缺少参数"
      CONNECT_TIMEOUT="$2"; shift 2 ;;
    --connect-timeout=*) CONNECT_TIMEOUT="${1#*=}"; shift ;;
    --timeout)
      (( $# >= 2 )) || die "--timeout 缺少参数"
      MAX_TIME="$2"; shift 2 ;;
    --timeout=*) MAX_TIME="${1#*=}"; shift ;;
    --origin)
      (( $# >= 2 )) || die "--origin 缺少参数"
      ORIGIN="$2"; shift 2 ;;
    --origin=*) ORIGIN="${1#*=}"; shift ;;
    -h|--help) usage; exit 0 ;;
    -*) die "未知选项：$1" ;;
    *)
      (( positional_seen == 0 )) || die "只能指定一个基础地址"
      BASE_URL="$1"
      positional_seen=1
      shift ;;
  esac
done

command -v curl >/dev/null 2>&1 || die "缺少 curl"
command -v awk >/dev/null 2>&1 || die "缺少 awk"
command -v od >/dev/null 2>&1 || die "缺少 od"
command -v grep >/dev/null 2>&1 || die "缺少 grep"

value_has_control_byte "$BASE_URL" && die "基础地址含控制字符"
value_has_control_byte "$ORIGIN" && die "Origin 含控制字符"
BASE_URL="${BASE_URL%/}"
case "$BASE_URL" in http://?*|https://?*) ;; *) die "基础地址必须使用 http:// 或 https://" ;; esac
case "$ORIGIN" in http://?*|https://?*) ;; *) die "Origin 必须使用 http:// 或 https://" ;; esac
[[ "$CONNECT_TIMEOUT" =~ ^[0-9]+$ && "$CONNECT_TIMEOUT" -ge 1 && "$CONNECT_TIMEOUT" -le 300 ]] || die "连接超时必须为 1—300 秒"
[[ "$MAX_TIME" =~ ^[0-9]+$ && "$MAX_TIME" -ge 1 && "$MAX_TIME" -le 600 ]] || die "请求超时必须为 1—600 秒"

# 从标准输入读取一个 JSON 文档并执行结构化操作。
#
# mode=validate：校验统一响应信封。
# mode=require ：校验 JSON Pointer 指向的节点存在且类型符合要求。
# mode=get     ：提取 JSON Pointer 指向的字符串值。
#
# 解析器是递归下降解析器；对象成员按解码后的键名保存，因而不会把嵌套
# 同名键误认为顶层键，也不会被 Unicode 转义键或重复键绕过。
json_tool() {
  local mode="$1" expected="$2" data_type="${3:-any}" query="${4:-}" value_type="${5:-any}"

  LC_ALL=C awk \
    -v mode="$mode" \
    -v expected="$expected" \
    -v expected_data_type="$data_type" \
    -v query="$query" \
    -v expected_value_type="$value_type" '
    function fail(message) {
      print "JSON 解析失败：" message > "/dev/stderr"
      exit 2
    }

    function skip_ws(    ch) {
      while (pos <= input_length) {
        ch = substr(input, pos, 1)
        if (ch != " " && ch != "\t" && ch != "\r" && ch != "\n") {
          break
        }
        pos++
      }
    }

    function byte_hex(value,    digits) {
      digits = "0123456789ABCDEF"
      return substr(digits, int(value / 16) + 1, 1) substr(digits, (value % 16) + 1, 1)
    }

    function text_canon(text,    result,i,ch,value) {
      result = ""
      for (i = 1; i <= length(text); i++) {
        ch = substr(text, i, 1)
        value = byte_value[ch]
        if (value == "") {
          fail("内部字符串含无法编码的字节")
        }
        result = result byte_hex(value)
      }
      return result
    }

    function hex_value(text,    result,i,ch,digit) {
      result = 0
      for (i = 1; i <= length(text); i++) {
        ch = substr(text, i, 1)
        if (ch >= "0" && ch <= "9") {
          digit = ch + 0
        } else if (ch >= "A" && ch <= "F") {
          digit = index("ABCDEF", ch) + 9
        } else {
          digit = index("abcdef", ch) + 9
        }
        result = result * 16 + digit
      }
      return result
    }

    function unicode_bytes(codepoint,    first,second,third,fourth) {
      if (codepoint == 0) {
        return ""
      }
      if (codepoint <= 127) {
        return sprintf("%c", codepoint)
      }
      if (codepoint <= 2047) {
        first = 192 + int(codepoint / 64)
        second = 128 + (codepoint % 64)
        return sprintf("%c%c", first, second)
      }
      if (codepoint <= 65535) {
        first = 224 + int(codepoint / 4096)
        second = 128 + (int(codepoint / 64) % 64)
        third = 128 + (codepoint % 64)
        return sprintf("%c%c%c", first, second, third)
      }
      first = 240 + int(codepoint / 262144)
      second = 128 + (int(codepoint / 4096) % 64)
      third = 128 + (int(codepoint / 64) % 64)
      fourth = 128 + (codepoint % 64)
      return sprintf("%c%c%c%c", first, second, third, fourth)
    }

    function codepoint_canon(codepoint,    bytes,result,i) {
      if (codepoint == 0) {
        return "00"
      }
      bytes = unicode_bytes(codepoint)
      result = ""
      for (i = 1; i <= length(bytes); i++) {
        result = result byte_hex(byte_value[substr(bytes, i, 1)])
      }
      return result
    }

    function scan_string(    ch,escape,hex,codepoint,low_hex,low_codepoint,bytes_count,b1,b2,b3,b4,i,raw) {
      if (substr(input, pos, 1) != "\"") {
        fail("字符串缺少起始引号")
      }
      pos++
      parsed_string = ""
      parsed_canon = ""
      parsed_has_nul = 0

      while (pos <= input_length) {
        ch = substr(input, pos, 1)
        if (ch == "\"") {
          pos++
          return
        }

        if (ch == "\\") {
          escape = substr(input, pos + 1, 1)
          if (escape == "\"" || escape == "\\" || escape == "/") {
            if (escape == "\"") {
              codepoint = 34
            } else if (escape == "\\") {
              codepoint = 92
            } else {
              codepoint = 47
            }
            parsed_string = parsed_string unicode_bytes(codepoint)
            parsed_canon = parsed_canon codepoint_canon(codepoint)
            pos += 2
            continue
          }
          if (escape == "b" || escape == "f" || escape == "n" || escape == "r" || escape == "t") {
            if (escape == "b") {
              codepoint = 8
            } else if (escape == "f") {
              codepoint = 12
            } else if (escape == "n") {
              codepoint = 10
            } else if (escape == "r") {
              codepoint = 13
            } else {
              codepoint = 9
            }
            parsed_string = parsed_string unicode_bytes(codepoint)
            parsed_canon = parsed_canon codepoint_canon(codepoint)
            pos += 2
            continue
          }
          if (escape != "u") {
            fail("字符串含非法转义")
          }

          hex = substr(input, pos + 2, 4)
          if (length(hex) != 4 || hex ~ /[^0-9A-Fa-f]/) {
            fail("Unicode 转义必须包含四位十六进制数")
          }
          codepoint = hex_value(hex)
          pos += 6

          if (codepoint >= 55296 && codepoint <= 56319) {
            if (substr(input, pos, 2) != "\\u") {
              fail("高代理项后缺少低代理项")
            }
            low_hex = substr(input, pos + 2, 4)
            if (length(low_hex) != 4 || low_hex ~ /[^0-9A-Fa-f]/) {
              fail("低代理项格式错误")
            }
            low_codepoint = hex_value(low_hex)
            if (low_codepoint < 56320 || low_codepoint > 57343) {
              fail("高代理项后不是有效低代理项")
            }
            codepoint = 65536 + (codepoint - 55296) * 1024 + (low_codepoint - 56320)
            pos += 6
          } else if (codepoint >= 56320 && codepoint <= 57343) {
            fail("出现孤立低代理项")
          }

          if (codepoint == 0) {
            parsed_has_nul = 1
          }
          parsed_string = parsed_string unicode_bytes(codepoint)
          parsed_canon = parsed_canon codepoint_canon(codepoint)
          continue
        }

        b1 = byte_value[ch]
        if (b1 == "") {
          fail("字符串含 NUL 或无法识别的字节")
        }
        if (b1 < 32) {
          fail("字符串含未转义控制字符")
        }
        if (b1 < 128) {
          parsed_string = parsed_string ch
          parsed_canon = parsed_canon byte_hex(b1)
          pos++
          continue
        }

        if (b1 >= 194 && b1 <= 223) {
          bytes_count = 2
          b2 = byte_value[substr(input, pos + 1, 1)]
          if (b2 < 128 || b2 > 191) {
            fail("字符串含非法 UTF-8 二字节序列")
          }
        } else if (b1 >= 224 && b1 <= 239) {
          bytes_count = 3
          b2 = byte_value[substr(input, pos + 1, 1)]
          b3 = byte_value[substr(input, pos + 2, 1)]
          if (b3 < 128 || b3 > 191 ||
              (b1 == 224 && (b2 < 160 || b2 > 191)) ||
              (b1 == 237 && (b2 < 128 || b2 > 159)) ||
              (b1 != 224 && b1 != 237 && (b2 < 128 || b2 > 191))) {
            fail("字符串含非法 UTF-8 三字节序列")
          }
        } else if (b1 >= 240 && b1 <= 244) {
          bytes_count = 4
          b2 = byte_value[substr(input, pos + 1, 1)]
          b3 = byte_value[substr(input, pos + 2, 1)]
          b4 = byte_value[substr(input, pos + 3, 1)]
          if (b3 < 128 || b3 > 191 || b4 < 128 || b4 > 191 ||
              (b1 == 240 && (b2 < 144 || b2 > 191)) ||
              (b1 == 244 && (b2 < 128 || b2 > 143)) ||
              (b1 != 240 && b1 != 244 && (b2 < 128 || b2 > 191))) {
            fail("字符串含非法 UTF-8 四字节序列")
          }
        } else {
          fail("字符串含非法 UTF-8 起始字节")
        }

        raw = substr(input, pos, bytes_count)
        parsed_string = parsed_string raw
        for (i = 0; i < bytes_count; i++) {
          parsed_canon = parsed_canon byte_hex(byte_value[substr(input, pos + i, 1)])
        }
        pos += bytes_count
      }
      fail("字符串缺少结束引号")
    }

    function new_node(type) {
      node_count++
      node_type[node_count] = type
      return node_count
    }

    function parse_number(    id,start,ch) {
      start = pos
      if (substr(input, pos, 1) == "-") {
        pos++
      }
      ch = substr(input, pos, 1)
      if (ch == "0") {
        pos++
        if (substr(input, pos, 1) ~ /[0-9]/) {
          fail("数字含非法前导零")
        }
      } else if (ch ~ /[1-9]/) {
        while (substr(input, pos, 1) ~ /[0-9]/) {
          pos++
        }
      } else {
        fail("数字整数部分格式错误")
      }
      if (substr(input, pos, 1) == ".") {
        pos++
        if (substr(input, pos, 1) !~ /[0-9]/) {
          fail("数字小数部分为空")
        }
        while (substr(input, pos, 1) ~ /[0-9]/) {
          pos++
        }
      }
      ch = substr(input, pos, 1)
      if (ch == "e" || ch == "E") {
        pos++
        ch = substr(input, pos, 1)
        if (ch == "+" || ch == "-") {
          pos++
        }
        if (substr(input, pos, 1) !~ /[0-9]/) {
          fail("数字指数部分为空")
        }
        while (substr(input, pos, 1) ~ /[0-9]/) {
          pos++
        }
      }
      id = new_node("number")
      node_value[id] = substr(input, start, pos - start)
      return id
    }

    function parse_object(    id,key_canon,value_id,ch,index_key) {
      id = new_node("object")
      pos++
      skip_ws()
      if (substr(input, pos, 1) == "}") {
        pos++
        return id
      }
      while (1) {
        if (substr(input, pos, 1) != "\"") {
          fail("对象成员名必须是字符串")
        }
        scan_string()
        key_canon = parsed_canon
        index_key = id SUBSEP key_canon
        if (index_key in member_seen) {
          fail("对象含重复成员名")
        }
        member_seen[index_key] = 1
        skip_ws()
        if (substr(input, pos, 1) != ":") {
          fail("对象成员名后缺少冒号")
        }
        pos++
        value_id = parse_value()
        object_size[id]++
        object_key[id SUBSEP object_size[id]] = key_canon
        object_value[id SUBSEP object_size[id]] = value_id
        skip_ws()
        ch = substr(input, pos, 1)
        if (ch == "}") {
          pos++
          return id
        }
        if (ch != ",") {
          fail("对象成员之间缺少逗号")
        }
        pos++
        skip_ws()
        if (substr(input, pos, 1) == "}") {
          fail("对象末尾不允许多余逗号")
        }
      }
    }

    function parse_array(    id,value_id,ch) {
      id = new_node("array")
      pos++
      skip_ws()
      if (substr(input, pos, 1) == "]") {
        pos++
        return id
      }
      while (1) {
        value_id = parse_value()
        array_size[id]++
        array_value[id SUBSEP array_size[id]] = value_id
        skip_ws()
        ch = substr(input, pos, 1)
        if (ch == "]") {
          pos++
          return id
        }
        if (ch != ",") {
          fail("数组元素之间缺少逗号")
        }
        pos++
        skip_ws()
        if (substr(input, pos, 1) == "]") {
          fail("数组末尾不允许多余逗号")
        }
      }
    }

    function parse_value(    ch,id) {
      skip_ws()
      ch = substr(input, pos, 1)
      if (ch == "{") {
        return parse_object()
      }
      if (ch == "[") {
        return parse_array()
      }
      if (ch == "\"") {
        scan_string()
        id = new_node("string")
        node_value[id] = parsed_string
        node_string_canon[id] = parsed_canon
        node_has_nul[id] = parsed_has_nul
        return id
      }
      if (ch == "-" || ch ~ /[0-9]/) {
        return parse_number()
      }
      if (substr(input, pos, 4) == "true") {
        pos += 4
        id = new_node("boolean")
        node_value[id] = "true"
        return id
      }
      if (substr(input, pos, 5) == "false") {
        pos += 5
        id = new_node("boolean")
        node_value[id] = "false"
        return id
      }
      if (substr(input, pos, 4) == "null") {
        pos += 4
        return new_node("null")
      }
      if (pos > input_length) {
        fail("JSON 文档为空或值不完整")
      }
      fail("无法识别的 JSON 值")
    }

    function find_member(object_id,key_canon,    i) {
      if (node_type[object_id] != "object") {
        return 0
      }
      for (i = 1; i <= object_size[object_id]; i++) {
        if (object_key[object_id SUBSEP i] == key_canon) {
          return object_value[object_id SUBSEP i]
        }
      }
      return 0
    }

    function validate_envelope(root,    code_key,msg_key,data_key,code_id,msg_id,data_id) {
      if (node_type[root] != "object") {
        fail("响应顶层必须是对象")
      }
      if (object_size[root] != 3) {
        fail("响应顶层必须且只能包含 code、msg、data 三个成员")
      }
      code_key = text_canon("code")
      msg_key = text_canon("msg")
      data_key = text_canon("data")
      code_id = find_member(root, code_key)
      msg_id = find_member(root, msg_key)
      data_id = find_member(root, data_key)
      if (!code_id || !msg_id || !data_id) {
        fail("响应顶层必须且只能包含 code、msg、data 三个成员")
      }
      if (node_type[code_id] != "number" || node_value[code_id] !~ /^-?(0|[1-9][0-9]*)$/) {
        fail("code 必须是 JSON 整数")
      }
      if (node_value[code_id] != expected) {
        fail("code 与预期 HTTP 状态不一致")
      }
      if (node_type[msg_id] != "string") {
        fail("msg 必须是字符串")
      }
      if (expected_data_type != "any" && node_type[data_id] != expected_data_type) {
        fail("data 类型不符合当前调用场景")
      }
      return data_id
    }

    function pointer_component(component,    result) {
      result = component
      if (result ~ /~([^01]|$)/) {
        fail("JSON Pointer 含非法转义")
      }
      gsub(/~1/, "/", result)
      gsub(/~0/, "~", result)
      return result
    }

    function resolve_pointer(root,pointer,    parts,count,current,i,part,index_value) {
      if (pointer == "") {
        return root
      }
      if (substr(pointer, 1, 1) != "/") {
        fail("JSON Pointer 必须以斜杠开头")
      }
      count = split(pointer, parts, "/")
      current = root
      for (i = 2; i <= count; i++) {
        part = pointer_component(parts[i])
        if (node_type[current] == "object") {
          current = find_member(current, text_canon(part))
          if (!current) {
            fail("所需字段不存在")
          }
        } else if (node_type[current] == "array") {
          if (part !~ /^(0|[1-9][0-9]*)$/) {
            fail("数组下标格式错误")
          }
          index_value = part + 1
          if (index_value < 1 || index_value > array_size[current]) {
            fail("数组下标越界")
          }
          current = array_value[current SUBSEP index_value]
        } else {
          fail("JSON Pointer 穿过了非容器节点")
        }
      }
      return current
    }

    {
      input = input $0 "\n"
    }

    END {
      for (i = 1; i <= 255; i++) {
        byte_value[sprintf("%c", i)] = i
      }
      input_length = length(input)
      pos = 1
      root = parse_value()
      skip_ws()
      if (pos <= input_length) {
        fail("顶层值之后仍有多余内容")
      }
      validate_envelope(root)

      if (mode == "validate") {
        exit 0
      }
      target = resolve_pointer(root, query)
      if (expected_value_type != "any" && node_type[target] != expected_value_type) {
        fail("所需字段类型不符合预期")
      }
      if (mode == "require") {
        exit 0
      }
      if (mode != "get") {
        fail("未知 JSON 操作")
      }
      if (node_type[target] != "string") {
        fail("仅允许提取字符串字段")
      }
      if (node_has_nul[target]) {
        # get 的输出只会先写入临时文件。POSIX awk 以实际 NUL 标记该值，
        # 由 Bash 赋值前的 od 字节扫描统一拒绝，绝不进入 shell 变量。
        printf "%c", 0
        exit 0
      }
      printf "%s", node_value[target]
    }
  '
}

response_string() {
  local pointer="$1" label="${2:-$1}"
  RESPONSE_STRING_VALUE=""
  RESPONSE_VALUE_FILE="$(mktemp "${TMPDIR:-/tmp}/bishe-api-value.XXXXXX")" || die "无法创建字符串临时文件"

  if ! printf '%s' "$RESPONSE_BODY" |
    json_tool get "$RESPONSE_EXPECTED" any "$pointer" string >"$RESPONSE_VALUE_FILE"; then
    rm -f -- "$RESPONSE_VALUE_FILE"
    RESPONSE_VALUE_FILE=""
    return 1
  fi
  if file_has_nul_byte "$RESPONSE_VALUE_FILE"; then
    printf 'JSON 字符串字段 %s 含 NUL 控制字符，拒绝进入 Bash 变量\n' "$label" >&2
    rm -f -- "$RESPONSE_VALUE_FILE"
    RESPONSE_VALUE_FILE=""
    return 1
  fi
  if file_has_control_byte "$RESPONSE_VALUE_FILE"; then
    printf 'JSON 字符串字段 %s 含控制字符，拒绝进入 Bash 变量\n' "$label" >&2
    rm -f -- "$RESPONSE_VALUE_FILE"
    RESPONSE_VALUE_FILE=""
    return 1
  fi

  # 文件已经通过控制字节扫描，因此只可能是一行且不含 NUL；read 即使在
  # 文件末尾没有换行时返回非零，也会保留读到的完整值。
  IFS= read -r RESPONSE_STRING_VALUE <"$RESPONSE_VALUE_FILE" || :
  rm -f -- "$RESPONSE_VALUE_FILE"
  RESPONSE_VALUE_FILE=""
}

require_safe_token() {
  local value="$1" label="$2"
  [[ -n "$value" ]] || die "$label 为空"
  if value_has_control_byte "$value"; then
    die "$label 含控制字符，拒绝用于请求"
  fi
}

refresh_token_payload() {
  local value="$1" escaped
  require_safe_token "$value" "refresh token"
  escaped="${value//\\/\\\\}"
  escaped="${escaped//\"/\\\"}"
  printf '{"refresh":"%s"}' "$escaped"
}

require_response_field() {
  local pointer="$1" value_type="${2:-any}"
  printf '%s' "$RESPONSE_BODY" | json_tool require "$RESPONSE_EXPECTED" any "$pointer" "$value_type"
}

request() {
  local method="$1" path="$2" expected="$3" data_type="$4" payload="${5:-}" token="${6:-}"
  local status body args
  args=(--silent --show-error --connect-timeout "$CONNECT_TIMEOUT" --max-time "$MAX_TIME" -X "$method" -H 'Accept: application/json' -H 'Content-Type: application/json' -H "Origin: $ORIGIN")
  if [[ -n "$token" ]]; then
    require_safe_token "$token" "access token"
    args+=(-H "Authorization: Bearer $token")
  fi
  [[ -z "$payload" ]] || args+=(--data "$payload")

  RESPONSE_FILE="$(mktemp "${TMPDIR:-/tmp}/bishe-api-contract.XXXXXX")" || die "无法创建响应临时文件"
  if ! status="$(curl "${args[@]}" --output "$RESPONSE_FILE" --write-out '%{http_code}' -- "$BASE_URL$path")"; then
    cleanup
    RESPONSE_FILE=""
    die "无法连接后端 $BASE_URL"
  fi
  [[ "$status" == "$expected" ]] || {
    cleanup
    RESPONSE_FILE=""
    die "$method $path 期望 HTTP ${expected}，实际 $status"
  }
  # macOS 自带 awk 会在原始 NUL 处截断记录，先以 POSIX od 做字节级防护，
  # 防止“合法 JSON + NUL + 垃圾内容”被截断后误判为合法。
  if LC_ALL=C od -A n -t x1 -v "$RESPONSE_FILE" | grep -Eq '(^|[[:space:]])00([[:space:]]|$)'; then
    cleanup
    RESPONSE_FILE=""
    die "$method $path 响应 JSON 含非法 NUL 字节"
  fi
  if ! json_tool validate "$expected" "$data_type" <"$RESPONSE_FILE"; then
    cleanup
    RESPONSE_FILE=""
    die "$method $path 响应 JSON 契约不合法"
  fi

  body="$(<"$RESPONSE_FILE")"
  cleanup
  RESPONSE_FILE=""
  RESPONSE_BODY="$body"
  RESPONSE_EXPECTED="$expected"
}

suffix="$(date +%s)$$"
suffix="${suffix: -10}"
username="contract_$suffix"
password='ContractA1Pass'
new_password='ContractB2Pass'

request GET /api/health/ 200 any
request GET /api/users/profile/ 401 any

request POST /api/users/register/ 201 object \
  "{\"username\":\"$username\",\"email\":\"$username@example.com\",\"phone\":\"139${suffix: -8}\",\"password\":\"$password\",\"password_confirm\":\"$password\"}"
registered_username=""
if ! response_string /data/username "注册响应的 data.username"; then
  die "注册响应缺少字符串字段 data.username"
fi
registered_username="$RESPONSE_STRING_VALUE"
[[ "$registered_username" == "$username" ]] || die "注册响应用户与请求不一致"

request POST /api/users/login/ 200 object "{\"username\":\"$username\",\"password\":\"$password\"}"
access=""
refresh=""
if ! response_string /data/access "登录响应的 access token"; then
  die "登录响应缺少字符串字段 data.access 或 data.refresh"
fi
access="$RESPONSE_STRING_VALUE"
if ! response_string /data/refresh "登录响应的 refresh token"; then
  die "登录响应缺少字符串字段 data.access 或 data.refresh"
fi
refresh="$RESPONSE_STRING_VALUE"
require_safe_token "$access" "登录响应的 access token"
require_safe_token "$refresh" "登录响应的 refresh token"

request GET /api/users/profile/ 200 object '' "$access"
for field in id username email phone role created_at last_login; do
  require_response_field "/data/$field" any || die "资料响应缺少字段 data.$field"
done

updated_email="updated_$username@example.com"
request PUT /api/users/profile/ 200 object \
  "{\"email\":\"$updated_email\",\"phone\":\"138${suffix: -8}\"}" "$access"
actual_email=""
if ! response_string /data/email "资料更新响应的 data.email"; then
  die "资料更新响应缺少字符串字段 data.email"
fi
actual_email="$RESPONSE_STRING_VALUE"
[[ "$actual_email" == "$updated_email" ]] || die "资料更新未生效"

refresh_payload="$(refresh_token_payload "$refresh")"
request POST /api/users/token/refresh/ 200 object "$refresh_payload"
if ! response_string /data/access "刷新响应的 access token"; then
  die "刷新响应缺少字符串字段 data.access"
fi
access="$RESPONSE_STRING_VALUE"
require_safe_token "$access" "刷新响应的 access token"

request POST /api/users/password/change/ 200 any \
  "{\"old_password\":\"$password\",\"new_password\":\"$new_password\",\"new_password_confirm\":\"$new_password\"}" "$access"
request POST /api/users/login/ 200 object "{\"username\":\"$username\",\"password\":\"$new_password\"}"
if ! response_string /data/access "新密码登录响应的 access token"; then
  die "新密码登录响应缺少字符串字段 data.access 或 data.refresh"
fi
access="$RESPONSE_STRING_VALUE"
if ! response_string /data/refresh "新密码登录响应的 refresh token"; then
  die "新密码登录响应缺少字符串字段 data.access 或 data.refresh"
fi
refresh="$RESPONSE_STRING_VALUE"
require_safe_token "$access" "新密码登录响应的 access token"
require_safe_token "$refresh" "新密码登录响应的 refresh token"
refresh_payload="$(refresh_token_payload "$refresh")"
request POST /api/users/logout/ 200 any "$refresh_payload" "$access"

printf 'PASS %s：用户 API 契约验证通过\n' "$BASE_URL"
