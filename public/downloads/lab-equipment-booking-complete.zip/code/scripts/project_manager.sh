#!/usr/bin/env bash

# 派生项目本地管理器。管理逻辑使用 Bash；所选后端仍需其自身运行时。
set -euo pipefail

if (( BASH_VERSINFO[0] < 3 || (BASH_VERSINFO[0] == 3 && BASH_VERSINFO[1] < 2) )); then
  printf '错误：本脚本需要 Bash 3.2 或更高版本\n' >&2
  exit 2
fi

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
FRONTEND_DIR="$ROOT/frontend"
BACKEND_DIR="$ROOT/backend"
RUNTIME_DIR="$ROOT/.runtime"
LOG_DIR="$RUNTIME_DIR/logs"
DATA_DIR="$RUNTIME_DIR/data"
BIN_DIR="$RUNTIME_DIR/bin"
VENV_DIR="$RUNTIME_DIR/venv"
TOOLCHAIN_DIR="$ROOT/.toolchain"
RUNTIME_BUNDLE_SCRIPT="$ROOT/scripts/runtime_bundle.sh"
LOCK_DIR="$RUNTIME_DIR/manager.lock.d"
RECLAIM_DIR="$RUNTIME_DIR/manager.lock.reclaim.d"
STATE_FILE="$RUNTIME_DIR/init-state"
LOCK_TOKEN=""
LOCK_OWNED=0
RECLAIM_TOKEN=""
RECLAIM_OWNED=0
LOCK_INCOMPLETE_GRACE_SECONDS=30
LOCK_PUBLISH_ROOT=""
STARTUP_ACTIVE=0
STARTED_BACKEND=0
STARTED_FRONTEND=0
PENDING_NAME=""
PENDING_PID=""
PENDING_STARTED=""
PENDING_COMMAND=""
PROCESS_PID=""
PROCESS_STARTED=""
PROCESS_COMMAND=""
RUNTIME_MODE="system"
OFFLINE_MODE=0
BUNDLE_TARGET="none"
BUNDLE_ID="none"
BUNDLE_SIGNATURE="none"
NODE_BIN="node"
NPM_BIN="npm"
PYTHON_RUNTIME_BIN="python3"
GO_BIN="go"
JAVA_BIN="java"
MAVEN_BIN="mvn"
NPM_CACHE_DIR=""
PIP_CACHE_DIR=""
MAVEN_CACHE_DIR=""
NPM_CACHE_SEED=""
MAVEN_CACHE_SEED=""

die() {
  printf '错误：%s\n' "$*" >&2
  exit 1
}

run_in() {
  local directory="$1"
  shift
  printf '+ (cd %s &&' "$directory"
  printf ' %q' "$@"
  printf ')\n'
  (cd "$directory" && "$@")
}

require_command() {
  command -v "$1" >/dev/null 2>&1 || die "缺少命令 $1：$2"
}

require_executable() {
  [[ -x "$1" && ! -d "$1" ]] || die "随包环境缺少可执行文件：${1#$ROOT/}"
}

require_system_network_permission() {
  [[ "$RUNTIME_MODE" == "system" ]] || return 0
  [[ "${BISHE_ALLOW_NETWORK:-0}" == 1 ]] || \
    die "源码模式不会隐式联网；初始化、启动或构建前请显式设置 BISHE_ALLOW_NETWORK=1，严格离线请重新生成 --with-env 项目"
}

usage() {
  cat <<'EOF'
用法：./manage.sh <命令>

  setup      首次配置项目（生成 .env、校验环境、初始化并启动）
  doctor     检查配置、端口和运行时命令
  init       安装依赖、迁移数据库并构建后端
  start      后台启动，必要时自动初始化
  stop       仅停止本项目记录且指纹匹配的进程
  restart    重启项目
  status     查看前后端进程状态
  logs       持续显示前后端日志，按 Ctrl-C 退出
  test       验证运行中的后端是否符合统一 API 契约
  check      执行前端构建和后端检查或测试
  runtime-info   显示系统或随包环境信息（不要求 .env）
  runtime-verify 校验随包环境完整性（不要求 .env）
  delivery-check [--complete] 校验 code/docs/ppt 交付结构
  docs-check                 delivery-check 的兼容别名

首次使用执行 ./manage.sh setup；之后使用 start、stop、status、logs 等日常命令。
EOF
}

COMMAND="${1:-help}"
if (( $# > 0 )); then
  shift
fi
case "$COMMAND" in
  help|-h|--help)
    (( $# == 0 )) || die "$COMMAND 不接受额外参数"
    usage
    exit 0
    ;;
  docs-check|delivery-check)
    [[ -x "$ROOT/scripts/validate_delivery.sh" ]] || die "缺少可执行脚本 scripts/validate_delivery.sh"
    exec "$ROOT/scripts/validate_delivery.sh" --root "$(dirname "$ROOT")" "$@"
    ;;
  doctor|setup|init|start|stop|restart|status|logs|test|check|runtime-info|runtime-verify)
    (( $# == 0 )) || die "$COMMAND 不接受额外参数：$*"
    ;;
  *)
    die "未知命令：${COMMAND}；执行 ./manage.sh --help 查看帮助"
    ;;
esac

manifest_string_value() {
  local key="$1"
  LC_ALL=C awk -v key="$key" '
    $0 ~ "^[[:space:]]*\\\"" key "\\\"[[:space:]]*:" {
      count++
      line = $0
      sub("^[[:space:]]*\\\"" key "\\\"[[:space:]]*:[[:space:]]*\\\"", "", line)
      if (line !~ /\"[[:space:]]*,?[[:space:]]*$/) exit 41
      sub(/\"[[:space:]]*,?[[:space:]]*$/, "", line)
      value = line
    }
    END {
      if (count != 1) exit 42
      print value
    }
  ' "$ROOT/.bishe-project.json"
}

manifest_integer_value() {
  local key="$1"
  LC_ALL=C awk -v key="$key" '
    $0 ~ "^[[:space:]]*\\\"" key "\\\"[[:space:]]*:" {
      count++
      line = $0
      sub("^[[:space:]]*\\\"" key "\\\"[[:space:]]*:[[:space:]]*", "", line)
      sub(/[[:space:]]*,?[[:space:]]*$/, "", line)
      if (line !~ /^(0|[1-9][0-9]*)$/) exit 41
      value = line
    }
    END {
      if (count != 1) exit 42
      print value
    }
  ' "$ROOT/.bishe-project.json"
}

load_env() {
  local line key value
  [[ -f "$ROOT/.env" ]] || die "缺少 .env；请从 .env.example 复制并配置"
  while IFS= read -r line || [[ -n "$line" ]]; do
    line="${line%$'\r'}"
    [[ -z "$line" || "$line" == \#* || "$line" != *=* ]] && continue
    key="${line%%=*}"
    value="${line#*=}"
    case "$key" in
      PROJECT_NAME|FRONTEND_PORT|BACKEND_PORT|APP_SECRET|JWT_SECRET)
        if [[ -z "${!key+x}" ]]; then
          printf -v "$key" '%s' "$value"
        fi
        ;;
    esac
  done <"$ROOT/.env"
  : "${PROJECT_NAME:?PROJECT_NAME 未配置}"
  : "${FRONTEND_PORT:?FRONTEND_PORT 未配置}"
  : "${BACKEND_PORT:?BACKEND_PORT 未配置}"
  : "${APP_SECRET:?APP_SECRET 未配置}"
  : "${JWT_SECRET:?JWT_SECRET 未配置}"
  [[ "$FRONTEND_PORT" =~ ^[0-9]+$ && "$BACKEND_PORT" =~ ^[0-9]+$ ]] || die "端口必须为整数"
}

random_hex() {
  od -An -N "$1" -tx1 /dev/urandom | tr -d ' \n'
}

create_env_if_missing() {
  local temporary app_secret jwt_secret
  [[ ! -L "$ROOT/.env" ]] || die ".env 不能是符号链接"
  if [[ -e "$ROOT/.env" ]]; then
    [[ -f "$ROOT/.env" ]] || die ".env 必须是普通文件"
    printf '沿用现有 .env 配置。\n'
    return 0
  fi
  [[ -f "$ROOT/.env.example" && ! -L "$ROOT/.env.example" ]] || die "缺少可信的 .env.example"
  app_secret="$(random_hex 32)"
  jwt_secret="$(random_hex 48)"
  temporary="$ROOT/.env.setup.$$"
  umask 077
  trap 'rm -f "$temporary"' EXIT HUP INT TERM
  awk -v app_secret="$app_secret" -v jwt_secret="$jwt_secret" '
    /^APP_SECRET=/ { print "APP_SECRET=" app_secret; next }
    /^JWT_SECRET=/ { print "JWT_SECRET=" jwt_secret; next }
    { print }
  ' "$ROOT/.env.example" >"$temporary"
  chmod 600 "$temporary"
  mv -f "$temporary" "$ROOT/.env"
  trap - EXIT HUP INT TERM
  printf '已生成本机 .env 与随机密钥。\n'
}

normalise_port() {
  local variable="$1" label="$2" value number
  value="${!variable}"
  [[ "$value" =~ ^[0-9]+$ && ${#value} -le 5 ]] || die "$label 端口必须为 1—65535 的整数"
  number=$((10#$value))
  (( number >= 1 && number <= 65535 )) || die "$label 端口必须为 1—65535 的整数"
  printf -v "$variable" '%d' "$number"
}

bundle_manifest_value() {
  local key="$1"
  LC_ALL=C awk -F '\t' -v key="$key" '
    $1 == key {
      count++
      if (NF != 2 || $2 == "") exit 41
      value = $2
    }
    END {
      if (count != 1) exit 42
      print value
    }
  ' "$TOOLCHAIN_DIR/bundle.manifest"
}

verify_embedded_bundle() {
  [[ -f "$RUNTIME_BUNDLE_SCRIPT" && ! -L "$RUNTIME_BUNDLE_SCRIPT" ]] || die "检测到 .toolchain，但缺少项目校验器 scripts/runtime_bundle.sh"
  [[ -x "$RUNTIME_BUNDLE_SCRIPT" ]] || die "随包环境校验器不可执行：scripts/runtime_bundle.sh"
  "$RUNTIME_BUNDLE_SCRIPT" verify-bundle \
    --root "$ROOT" \
    --frontend "$FRONTEND_KIND" \
    --backend "$BACKEND_KIND"
}

configure_runtime() {
  local manifest_signature checksum_signature
  if [[ ! -e "$TOOLCHAIN_DIR" && ! -L "$TOOLCHAIN_DIR" ]]; then
    return 0
  fi

  [[ -d "$TOOLCHAIN_DIR" && ! -L "$TOOLCHAIN_DIR" ]] || die ".toolchain 必须是项目内的真实目录"
  verify_embedded_bundle >/dev/null
  RUNTIME_MODE="embedded"
  OFFLINE_MODE=1
  if ! BUNDLE_TARGET="$(bundle_manifest_value target)"; then
    die "随包环境清单缺少唯一且有效的 target"
  fi
  if ! BUNDLE_ID="$(bundle_manifest_value bundle_id)"; then
    die "随包环境清单缺少唯一且有效的 bundle_id"
  fi
  manifest_signature="$(cksum "$TOOLCHAIN_DIR/bundle.manifest" | awk '{print $1 ":" $2}')"
  if [[ -f "$TOOLCHAIN_DIR/files.sha256" ]]; then
    checksum_signature="$(cksum "$TOOLCHAIN_DIR/files.sha256" | awk '{print $1 ":" $2}')"
  else
    checksum_signature="verified-tree"
  fi
  BUNDLE_SIGNATURE="$BUNDLE_ID@$BUNDLE_TARGET:$manifest_signature:$checksum_signature"

  NODE_BIN="$TOOLCHAIN_DIR/runtimes/node/bin/node"
  NPM_BIN="$TOOLCHAIN_DIR/runtimes/node/bin/npm"
  NPM_CACHE_SEED="$TOOLCHAIN_DIR/cache/npm"
  NPM_CACHE_DIR="$RUNTIME_DIR/cache/npm"
  require_executable "$NODE_BIN"
  require_executable "$NPM_BIN"
  [[ -d "$NPM_CACHE_SEED" ]] || die "随包环境缺少前端离线缓存：.toolchain/cache/npm"

  case "$BACKEND_KIND" in
    django|flask)
      PYTHON_RUNTIME_BIN="$TOOLCHAIN_DIR/runtimes/python/bin/python3"
      PIP_CACHE_DIR="$TOOLCHAIN_DIR/cache/pip"
      require_executable "$PYTHON_RUNTIME_BIN"
      [[ -d "$PIP_CACHE_DIR" ]] || die "随包环境缺少 Python 离线缓存：.toolchain/cache/pip"
      ;;
    gin)
      GO_BIN="$TOOLCHAIN_DIR/runtimes/go/bin/go"
      require_executable "$GO_BIN"
      [[ -d "$BACKEND_DIR/vendor" ]] || die "Gin 随包环境缺少 backend/vendor"
      ;;
    springboot)
      JAVA_BIN="$TOOLCHAIN_DIR/runtimes/jdk/bin/java"
      MAVEN_BIN="$TOOLCHAIN_DIR/runtimes/maven/bin/mvn"
      MAVEN_CACHE_SEED="$TOOLCHAIN_DIR/cache/maven"
      MAVEN_CACHE_DIR="$RUNTIME_DIR/cache/maven"
      require_executable "$JAVA_BIN"
      require_executable "$MAVEN_BIN"
      [[ -d "$MAVEN_CACHE_SEED" ]] || die "随包环境缺少 Maven 离线仓库：.toolchain/cache/maven"
      export JAVA_HOME="$TOOLCHAIN_DIR/runtimes/jdk"
      export MAVEN_HOME="$TOOLCHAIN_DIR/runtimes/maven"
      ;;
  esac

  PATH="$TOOLCHAIN_DIR/runtimes/node/bin:$TOOLCHAIN_DIR/runtimes/python/bin:$TOOLCHAIN_DIR/runtimes/go/bin:$TOOLCHAIN_DIR/runtimes/jdk/bin:$TOOLCHAIN_DIR/runtimes/maven/bin:$PATH"
  export PATH
  export npm_config_offline=true
  export npm_config_audit=false
  export npm_config_fund=false
  export npm_config_update_notifier=false
  export npm_config_cache="$NPM_CACHE_DIR"
  export npm_config_userconfig="$RUNTIME_DIR/home/.npmrc"
  export PIP_NO_INDEX=1
  export PIP_NO_CACHE_DIR=1
  export PIP_CONFIG_FILE=/dev/null
  export PIP_DISABLE_PIP_VERSION_CHECK=1
  [[ -z "$PIP_CACHE_DIR" ]] || export PIP_FIND_LINKS="$PIP_CACHE_DIR"
  export GOTOOLCHAIN=local
  export GOPROXY=off
  export GOSUMDB=off
  export GOFLAGS=-mod=vendor
  export GOCACHE="$RUNTIME_DIR/cache/go-build"
  export GOMODCACHE="$RUNTIME_DIR/cache/go-mod"
  export CGO_ENABLED=0
}

print_command_path() {
  local label="$1" executable="$2" path
  if [[ "$executable" == /* ]]; then
    path="$executable"
  else
    path="$(command -v "$executable" 2>/dev/null || true)"
  fi
  if [[ -n "$path" && -x "$path" ]]; then
    printf 'PASS %-12s %s\n' "$label" "$path"
  else
    printf 'MISS %-12s %s\n' "$label" "$executable"
    return 1
  fi
}

runtime_info() {
  printf '运行模式：%s\n' "$RUNTIME_MODE"
  if [[ "$RUNTIME_MODE" == "embedded" ]]; then
    printf '离线约束：已启用（禁止 npm、pip、Go、Maven 访问网络）\n'
    printf '环境标识：%s\n目标平台：%s\n' "$BUNDLE_ID" "$BUNDLE_TARGET"
  else
    printf '离线约束：未启用（使用系统运行时）\n'
  fi
  print_command_path node "$NODE_BIN" || true
  print_command_path npm "$NPM_BIN" || true
  case "$BACKEND_KIND" in
    django|flask) print_command_path python "$PYTHON_RUNTIME_BIN" || true ;;
    gin) print_command_path go "$GO_BIN" || true ;;
    springboot)
      print_command_path java "$JAVA_BIN" || true
      print_command_path maven "$MAVEN_BIN" || true
      ;;
  esac
  if [[ "$RUNTIME_MODE" == "embedded" ]]; then
    printf 'npm 缓存：%s\n' "$NPM_CACHE_DIR"
    [[ -z "$PIP_CACHE_DIR" ]] || printf 'pip 缓存：%s\n' "$PIP_CACHE_DIR"
    [[ -z "$MAVEN_CACHE_DIR" ]] || printf 'Maven 仓库：%s\n' "$MAVEN_CACHE_DIR"
  fi
}

[[ -f "$ROOT/.bishe-project.json" ]] || die "缺少 .bishe-project.json；请在派生项目根目录使用本脚本"
if ! MANIFEST_SCHEMA="$(manifest_integer_value schema_version)"; then
  die ".bishe-project.json 缺少唯一且有效的 schema_version"
fi
case "$MANIFEST_SCHEMA" in
  2|3) ;;
  *) die "不支持的项目清单版本：$MANIFEST_SCHEMA" ;;
esac
if ! FRONTEND_KIND="$(manifest_string_value frontend)"; then
  die ".bishe-project.json 缺少唯一且有效的 frontend"
fi
if ! BACKEND_KIND="$(manifest_string_value backend)"; then
  die ".bishe-project.json 缺少唯一且有效的 backend"
fi
case "$FRONTEND_KIND" in react|vue) ;; *) die "无法识别前端类型：$FRONTEND_KIND" ;; esac
case "$BACKEND_KIND" in django|flask|gin|springboot) ;; *) die "无法识别后端类型：$BACKEND_KIND" ;; esac
configure_runtime
case "$COMMAND" in
  runtime-info)
    runtime_info
    exit 0
    ;;
  runtime-verify)
    [[ "$RUNTIME_MODE" == "embedded" ]] || die "当前项目没有随包环境 .toolchain"
    verify_embedded_bundle
    printf '随包环境校验通过：%s（%s）\n' "$BUNDLE_ID" "$BUNDLE_TARGET"
    exit 0
    ;;
esac
if [[ "$COMMAND" == "setup" ]]; then
  create_env_if_missing
fi
load_env
normalise_port FRONTEND_PORT "前端"
normalise_port BACKEND_PORT "后端"
[[ "$FRONTEND_PORT" != "$BACKEND_PORT" ]] || die "前后端端口不能相同"

ensure_runtime() {
  mkdir -p "$RUNTIME_DIR" "$LOG_DIR" "$DATA_DIR" "$BIN_DIR"
  if [[ "$RUNTIME_MODE" == "embedded" ]]; then
    mkdir -p "$RUNTIME_DIR/home" "$RUNTIME_DIR/tmp" \
      "$RUNTIME_DIR/cache/go-build" "$RUNTIME_DIR/cache/go-mod"
    chmod 700 "$RUNTIME_DIR/home" "$RUNTIME_DIR/tmp"
    export HOME="$RUNTIME_DIR/home"
    export TMPDIR="$RUNTIME_DIR/tmp"
  fi
}

process_is_zombie() {
  local pid="$1" raw remainder state
  if [[ -r "/proc/$pid/stat" ]]; then
    raw="$(sed -n '1p' "/proc/$pid/stat" 2>/dev/null || true)"
    remainder="${raw##*) }"
    state="${remainder%% *}"
  else
    state="$(ps -p "$pid" -o stat= 2>/dev/null | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]].*$//' || true)"
  fi
  [[ "$state" == Z* ]]
}

process_is_alive() {
  local pid="$1"
  kill -0 "$pid" 2>/dev/null || return 1
  process_is_zombie "$pid" && return 1
  return 0
}

process_fingerprint() {
  local pid="$1" raw remainder started
  if [[ -r "/proc/$pid/stat" ]]; then
    raw="$(sed -n '1p' "/proc/$pid/stat" 2>/dev/null || true)"
    remainder="${raw##*) }"
    started="$(printf '%s\n' "$remainder" | awk '{print $20}')"
    [[ -z "$started" ]] || { printf 'linux:%s\n' "$started"; return 0; }
  fi
  started="$(ps -p "$pid" -o lstart= 2>/dev/null | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//' || true)"
  [[ -z "$started" ]] || printf 'posix:%s\n' "$started"
}

process_command() {
  local pid="$1"
  ps -ww -p "$pid" -o command= 2>/dev/null | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//' || true
}

new_token() {
  printf '%s-%s-' "$$" "$(date +%s)"
  od -An -N 8 -tx1 /dev/urandom | tr -d ' \n'
}

write_lock_owner() {
  local directory="$1" token="$2" temporary started command
  started="$(process_fingerprint "$$")"
  command="$(process_command "$$")"
  if [[ -z "$started" || -z "$command" ]]; then
    # 某些受限环境禁止 ps。令牌指纹仍能证明本命令对锁的所有权；
    # 后续命令只在 PID 已消失时回收此类锁，PID 存活时一律保守拒绝。
    started="token:$token"
    command="manager:$ROOT/scripts/project_manager.sh"
  fi
  temporary="$(mktemp "$directory/.owner.XXXXXX")" || return 1
  if ! {
    printf '%s\n' "$token"
    printf '%s\n' "$$"
    printf '%s\n' "$started"
    printf '%s\n' "$command"
  } >"$temporary"; then
    rm -f -- "$temporary" 2>/dev/null || true
    return 1
  fi
  if ! mv -f "$temporary" "$directory/owner"; then
    rm -f -- "$temporary" 2>/dev/null || true
    return 1
  fi
}

cleanup_lock_publish() {
  if [[ -n "$LOCK_PUBLISH_ROOT" && -d "$LOCK_PUBLISH_ROOT" ]]; then
    rm -rf -- "$LOCK_PUBLISH_ROOT" 2>/dev/null || true
  fi
  LOCK_PUBLISH_ROOT=""
}

# 在私有目录中写完所有者信息，再以同名目录无覆盖发布。这样公开锁路径
# 不会出现“目录已存在但 owner 尚未写完”的正常创建窗口。
publish_owned_lock() {
  local destination="$1" token="$2" write_token_file="$3"
  local candidate destination_parent destination_name
  destination_parent="$(dirname "$destination")"
  destination_name="$(basename "$destination")"
  LOCK_PUBLISH_ROOT="$(mktemp -d "$RUNTIME_DIR/.manager.lock.publish.XXXXXX")" || return 1
  candidate="$LOCK_PUBLISH_ROOT/$destination_name"
  mkdir "$candidate" || { cleanup_lock_publish; return 1; }
  if (( write_token_file )); then
    printf '%s\n' "$token" >"$candidate/token" || { cleanup_lock_publish; return 1; }
  fi
  write_lock_owner "$candidate" "$token" || { cleanup_lock_publish; return 1; }
  if ! read_lock_owner "$candidate" || [[ "$LOCK_READ_TOKEN" != "$token" || "$LOCK_READ_PID" != "$$" ]]; then
    cleanup_lock_publish
    return 1
  fi
  mv -n "$candidate" "$destination_parent/" 2>/dev/null || { cleanup_lock_publish; return 1; }
  if [[ -e "$candidate" || -L "$candidate" ]]; then
    cleanup_lock_publish
    return 1
  fi
  cleanup_lock_publish
  return 0
}

read_lock_owner() {
  local directory="$1"
  LOCK_READ_TOKEN=""
  LOCK_READ_PID=""
  LOCK_READ_STARTED=""
  LOCK_READ_COMMAND=""
  [[ -f "$directory/owner" ]] || return 1
  LOCK_READ_TOKEN="$(sed -n '1p' "$directory/owner" 2>/dev/null || true)"
  LOCK_READ_PID="$(sed -n '2p' "$directory/owner" 2>/dev/null || true)"
  LOCK_READ_STARTED="$(sed -n '3p' "$directory/owner" 2>/dev/null || true)"
  LOCK_READ_COMMAND="$(sed -n '4p' "$directory/owner" 2>/dev/null || true)"
  [[ -n "$LOCK_READ_TOKEN" && "$LOCK_READ_PID" =~ ^[0-9]+$ && -n "$LOCK_READ_STARTED" && -n "$LOCK_READ_COMMAND" ]]
}

directory_snapshot() {
  local directory="$1"
  if stat -f '%d:%i:%m' "$directory" >/dev/null 2>&1; then
    stat -f '%d:%i:%m' "$directory"
  else
    stat -c '%d:%i:%Y' "$directory" 2>/dev/null
  fi
}

incomplete_directory_expired() {
  local directory="$1" snapshot modified now age
  snapshot="$(directory_snapshot "$directory")" || return 1
  modified="${snapshot##*:}"
  [[ "$modified" =~ ^[0-9]+$ ]] || return 1
  now="$(date +%s)"
  [[ "$now" =~ ^[0-9]+$ ]] || return 1
  age=$((now - modified))
  (( age >= LOCK_INCOMPLETE_GRACE_SECONDS ))
}

lock_owner_state() {
  local actual_started actual_command
  process_is_alive "$LOCK_READ_PID" || return 1
  case "$LOCK_READ_STARTED" in
    token:*)
      [[ "$LOCK_READ_STARTED" == "token:$LOCK_READ_TOKEN" && "$LOCK_READ_COMMAND" == "manager:$ROOT/scripts/project_manager.sh" ]] || return 2
      return 2
      ;;
  esac
  actual_started="$(process_fingerprint "$LOCK_READ_PID")"
  actual_command="$(process_command "$LOCK_READ_PID")"
  [[ -n "$actual_started" && -n "$actual_command" ]] || return 2
  [[ "$actual_started" == "$LOCK_READ_STARTED" && "$actual_command" == "$LOCK_READ_COMMAND" ]]
}

recover_abandoned_reclaim_lock() {
  local snapshot state stale_dir
  local snapshot_token="" snapshot_pid="" snapshot_started="" snapshot_command=""
  [[ -d "$RECLAIM_DIR" ]] || return 0
  snapshot="$(directory_snapshot "$RECLAIM_DIR")" || return 1
  if read_lock_owner "$RECLAIM_DIR"; then
    snapshot_token="$LOCK_READ_TOKEN"
    snapshot_pid="$LOCK_READ_PID"
    snapshot_started="$LOCK_READ_STARTED"
    snapshot_command="$LOCK_READ_COMMAND"
    if lock_owner_state; then
      return 1
    else
      state=$?
      (( state != 2 )) || return 1
    fi
  else
    incomplete_directory_expired "$RECLAIM_DIR" || return 1
  fi

  [[ "$(directory_snapshot "$RECLAIM_DIR" 2>/dev/null || true)" == "$snapshot" ]] || return 1
  if [[ -n "$snapshot_token" ]]; then
    read_lock_owner "$RECLAIM_DIR" || return 1
    [[ "$LOCK_READ_TOKEN" == "$snapshot_token" && "$LOCK_READ_PID" == "$snapshot_pid" && "$LOCK_READ_STARTED" == "$snapshot_started" && "$LOCK_READ_COMMAND" == "$snapshot_command" ]] || return 1
  else
    read_lock_owner "$RECLAIM_DIR" && return 1
    incomplete_directory_expired "$RECLAIM_DIR" || return 1
  fi

  stale_dir="$RUNTIME_DIR/.manager.reclaim.stale.$(new_token)" || return 1
  mv "$RECLAIM_DIR" "$stale_dir" 2>/dev/null || return 1
  rm -rf -- "$stale_dir"
}

release_reclaim_lock() {
  local release_dir token=""
  (( RECLAIM_OWNED )) || return 0
  release_dir="$RUNTIME_DIR/.manager.reclaim.release.$RECLAIM_TOKEN"
  if mv "$RECLAIM_DIR" "$release_dir" 2>/dev/null; then
    [[ -f "$release_dir/token" ]] && token="$(sed -n '1p' "$release_dir/token" 2>/dev/null || true)"
    if [[ -z "$token" || "$token" == "$RECLAIM_TOKEN" ]]; then
      rm -rf -- "$release_dir"
    elif [[ ! -e "$RECLAIM_DIR" ]]; then
      mv "$release_dir" "$RECLAIM_DIR" 2>/dev/null || true
    fi
  fi
  RECLAIM_OWNED=0
  RECLAIM_TOKEN=""
}

release_lock() {
  local release_dir token=""
  (( LOCK_OWNED )) || return 0
  release_dir="$RUNTIME_DIR/.manager.lock.release.$LOCK_TOKEN"
  if mv "$LOCK_DIR" "$release_dir" 2>/dev/null; then
    if read_lock_owner "$release_dir"; then
      token="$LOCK_READ_TOKEN"
    fi
    if [[ -z "$token" || "$token" == "$LOCK_TOKEN" ]]; then
      rm -rf -- "$release_dir"
    elif [[ ! -e "$LOCK_DIR" ]]; then
      mv "$release_dir" "$LOCK_DIR" 2>/dev/null || true
    fi
  fi
  LOCK_OWNED=0
  LOCK_TOKEN=""
}

acquire_lock() {
  local attempt=0 state snapshot_token snapshot_pid snapshot_started snapshot_command stale_dir
  local snapshot_identity snapshot_complete
  ensure_runtime
  while (( attempt < 6 )); do
    attempt=$((attempt + 1))
    LOCK_TOKEN="$(new_token)" || die "无法生成项目管理锁令牌"
    [[ -n "$LOCK_TOKEN" ]] || die "无法生成项目管理锁令牌"
    if publish_owned_lock "$LOCK_DIR" "$LOCK_TOKEN" 0; then
      LOCK_OWNED=1
      return 0
    fi
    LOCK_TOKEN=""

    snapshot_identity="$(directory_snapshot "$LOCK_DIR" 2>/dev/null || true)"
    [[ -n "$snapshot_identity" ]] || continue
    snapshot_complete=0
    snapshot_token=""
    snapshot_pid=""
    snapshot_started=""
    snapshot_command=""
    if read_lock_owner "$LOCK_DIR"; then
      snapshot_complete=1
      snapshot_token="$LOCK_READ_TOKEN"
      snapshot_pid="$LOCK_READ_PID"
      snapshot_started="$LOCK_READ_STARTED"
      snapshot_command="$LOCK_READ_COMMAND"
      if lock_owner_state; then
        die "已有项目管理命令正在执行（PID ${snapshot_pid}），请等待其完成"
      else
        state=$?
        (( state != 2 )) || die "无法核验现有项目管理锁（PID ${snapshot_pid}）；为避免并发破坏，本次操作已拒绝"
      fi
    else
      if ! incomplete_directory_expired "$LOCK_DIR"; then
        if (( attempt < 6 )); then
          sleep 0.05
          continue
        fi
        die "项目管理锁正在创建或元数据不完整；为避免并发破坏，本次操作已拒绝"
      fi
    fi

    RECLAIM_TOKEN="$(new_token)" || die "无法生成锁回收令牌"
    [[ -n "$RECLAIM_TOKEN" ]] || die "无法生成锁回收令牌"
    if ! publish_owned_lock "$RECLAIM_DIR" "$RECLAIM_TOKEN" 1; then
      RECLAIM_TOKEN=""
      if recover_abandoned_reclaim_lock; then
        continue
      fi
      die "另一管理命令正在处理陈旧锁，请稍后重试"
    fi
    RECLAIM_OWNED=1

    if [[ "$(directory_snapshot "$LOCK_DIR" 2>/dev/null || true)" != "$snapshot_identity" ]]; then
      release_reclaim_lock
      continue
    fi
    if (( snapshot_complete )); then
      if ! read_lock_owner "$LOCK_DIR"; then
        release_reclaim_lock
        continue
      fi
      if [[ "$LOCK_READ_TOKEN" != "$snapshot_token" || "$LOCK_READ_PID" != "$snapshot_pid" || "$LOCK_READ_STARTED" != "$snapshot_started" || "$LOCK_READ_COMMAND" != "$snapshot_command" ]]; then
        release_reclaim_lock
        continue
      fi
      if lock_owner_state; then
        release_reclaim_lock
        die "已有项目管理命令正在执行（PID ${LOCK_READ_PID}），请等待其完成"
      else
        state=$?
        if (( state == 2 )); then
          release_reclaim_lock
          die "无法核验现有项目管理锁（PID ${LOCK_READ_PID}）；为避免并发破坏，本次操作已拒绝"
        fi
      fi
    else
      if read_lock_owner "$LOCK_DIR" || ! incomplete_directory_expired "$LOCK_DIR"; then
        release_reclaim_lock
        continue
      fi
    fi

    stale_dir="$RUNTIME_DIR/.manager.lock.stale.$RECLAIM_TOKEN"
    if ! mv "$LOCK_DIR" "$stale_dir" 2>/dev/null; then
      release_reclaim_lock
      continue
    fi
    LOCK_TOKEN="$(new_token)" || die "无法生成项目管理锁令牌"
    [[ -n "$LOCK_TOKEN" ]] || die "无法生成项目管理锁令牌"
    if publish_owned_lock "$LOCK_DIR" "$LOCK_TOKEN" 0; then
      LOCK_OWNED=1
      rm -rf -- "$stale_dir"
      release_reclaim_lock
      return 0
    fi
    LOCK_TOKEN=""
    rm -rf -- "$stale_dir"
    release_reclaim_lock
  done
  die "无法安全取得项目管理锁，请稍后重试"
}

file_signature() {
  cksum "$1" | awk '{print $1 ":" $2}'
}

runtime_state_signature() {
  if [[ "$RUNTIME_MODE" == "embedded" ]]; then
    printf '%s\n' "$BUNDLE_SIGNATURE"
  else
    printf 'system\n'
  fi
}

prepare_writable_cache() {
  local source="$1" destination="$2" label="$3" marker staging expected
  [[ -d "$source" && ! -L "$source" ]] || die "随包环境缺少${label}种子：${source#$ROOT/}"
  expected="$(runtime_state_signature)"
  marker="$destination/.bishe-seed"
  if [[ -f "$marker" && "$(sed -n '1p' "$marker" 2>/dev/null || true)" == "$expected" ]]; then
    return 0
  fi
  mkdir -p "$(dirname "$destination")"
  staging="${destination}.stage.$$"
  rm -rf -- "$staging"
  mkdir "$staging"
  cp -R "$source"/. "$staging"/
  chmod -R u+w "$staging"
  printf '%s\n' "$expected" >"$staging/.bishe-seed"
  rm -rf -- "$destination"
  mv "$staging" "$destination"
  printf '已从只读工具链准备%s可写缓存。\n' "$label"
}

prepare_embedded_caches() {
  [[ "$RUNTIME_MODE" == "embedded" ]] || return 0
  prepare_writable_cache "$NPM_CACHE_SEED" "$NPM_CACHE_DIR" "npm"
  if [[ "$BACKEND_KIND" == "springboot" ]]; then
    prepare_writable_cache "$MAVEN_CACHE_SEED" "$MAVEN_CACHE_DIR" "Maven"
  fi
}

run_npm_in() {
  local directory="$1"
  shift
  if [[ "$RUNTIME_MODE" == "embedded" ]]; then
    run_in "$directory" "$NPM_BIN" --offline --no-audit --no-fund --cache "$NPM_CACHE_DIR" "$@"
  else
    run_in "$directory" "$NPM_BIN" "$@"
  fi
}

requirements_use_hashes() {
  grep -Eq '(^|[[:space:]])--hash=' "$1"
}

install_python_requirements() {
  local python_bin="$1" requirements="$2"
  if [[ "$RUNTIME_MODE" == "embedded" ]]; then
    if requirements_use_hashes "$requirements"; then
      run_in "$BACKEND_DIR" "$python_bin" -m pip install --disable-pip-version-check \
        --no-index --find-links "$PIP_CACHE_DIR" --require-hashes -r "$requirements"
    else
      run_in "$BACKEND_DIR" "$python_bin" -m pip install --disable-pip-version-check \
        --no-index --find-links "$PIP_CACHE_DIR" -r "$requirements"
    fi
  else
    run_in "$BACKEND_DIR" "$python_bin" -m pip install --disable-pip-version-check -r "$requirements"
  fi
}

run_go_in() {
  local directory="$1"
  shift
  run_in "$directory" "$GO_BIN" "$@"
}

run_maven_in() {
  local directory="$1"
  shift
  if [[ "$RUNTIME_MODE" == "embedded" ]]; then
    run_in "$directory" "$MAVEN_BIN" -o \
      -Duser.home="$RUNTIME_DIR/home" \
      -Dmaven.repo.local="$MAVEN_CACHE_DIR" "$@"
  else
    run_in "$directory" "$MAVEN_BIN" "$@"
  fi
}

state_get() {
  local key="$1"
  [[ -f "$STATE_FILE" ]] || return 0
  sed -n 's/^'"$key"'=//p' "$STATE_FILE" | sed -n '1p'
}

write_state() {
  local frontend_signature="$1" backend_signature="$2" temporary
  temporary="$(mktemp "$RUNTIME_DIR/.init-state.XXXXXX")"
  {
    printf 'schema_version=2\n'
    printf 'frontend=%s\n' "$FRONTEND_KIND"
    printf 'backend=%s\n' "$BACKEND_KIND"
    printf 'frontend_lock=%s\n' "$frontend_signature"
    printf 'backend_lock=%s\n' "$backend_signature"
    printf 'runtime_mode=%s\n' "$RUNTIME_MODE"
    printf 'runtime_bundle=%s\n' "$(runtime_state_signature)"
    printf 'updated_at=%s\n' "$(date +%s)"
  } >"$temporary"
  mv -f "$temporary" "$STATE_FILE"
}

export_backend_env() {
  export PYTHONUNBUFFERED=1
  export SECRET_KEY="$APP_SECRET"
  export JWT_SECRET_KEY="$JWT_SECRET"
  case "$BACKEND_KIND" in
    django)
      export DJANGO_SETTINGS_MODULE=mysite.settings.development
      export SQLITE_PATH="$DATA_DIR/app.sqlite3"
      ;;
    flask)
      export FLASK_ENV=development
      export DATABASE_URI="sqlite:///$DATA_DIR/app.sqlite3"
      ;;
    gin)
      export SERVER_PORT="$BACKEND_PORT" GIN_MODE=release DB_DRIVER=sqlite
      export SQLITE_PATH="$DATA_DIR/app.sqlite3" JWT_SECRET="$JWT_SECRET"
      ;;
    springboot)
      export SERVER_PORT="$BACKEND_PORT" SPRING_PROFILES_ACTIVE=local
      export SPRING_DATASOURCE_URL="jdbc:h2:file:$DATA_DIR/springboot;MODE=MySQL;DATABASE_TO_LOWER=TRUE;AUTO_SERVER=TRUE"
      export SPRING_DATASOURCE_USERNAME=sa SPRING_DATASOURCE_PASSWORD= JWT_SECRET="$JWT_SECRET"
      ;;
  esac
}

initialise() {
  local frontend_signature backend_signature="none" previous_frontend previous_backend previous_runtime
  local current_runtime python_bin venv_created=0
  require_system_network_permission
  ensure_runtime
  prepare_embedded_caches
  if [[ "$RUNTIME_MODE" == "system" ]]; then
    require_command "$NPM_BIN" "请安装 Node.js 22 LTS"
  fi
  [[ -f "$FRONTEND_DIR/package-lock.json" ]] || die "前端缺少 package-lock.json"
  frontend_signature="$(file_signature "$FRONTEND_DIR/package-lock.json")"
  previous_frontend="$(state_get frontend_lock || true)"
  previous_runtime="$(state_get runtime_bundle || true)"
  current_runtime="$(runtime_state_signature)"
  if [[ "$previous_frontend" != "$frontend_signature" || "$previous_runtime" != "$current_runtime" || ! -d "$FRONTEND_DIR/node_modules" ]]; then
    run_npm_in "$FRONTEND_DIR" ci
  fi

  export_backend_env
  case "$BACKEND_KIND" in
    django|flask)
      if [[ "$RUNTIME_MODE" == "system" ]]; then
        require_command "$PYTHON_RUNTIME_BIN" "所选后端需要 Python 3.10+"
      fi
      [[ -f "$BACKEND_DIR/requirements.txt" ]] || die "后端缺少 requirements.txt"
      backend_signature="$(file_signature "$BACKEND_DIR/requirements.txt")"
      previous_backend="$(state_get backend_lock || true)"
      python_bin="$VENV_DIR/bin/python"
      if [[ "$RUNTIME_MODE" == "embedded" && "$previous_runtime" != "$current_runtime" && -d "$VENV_DIR" ]]; then
        rm -rf -- "$VENV_DIR"
      fi
      if [[ ! -x "$python_bin" ]]; then
        run_in "$ROOT" "$PYTHON_RUNTIME_BIN" -m venv "$VENV_DIR"
        venv_created=1
      fi
      if (( venv_created )) || [[ "$previous_backend" != "$backend_signature" || "$previous_runtime" != "$current_runtime" ]]; then
        install_python_requirements "$python_bin" "$BACKEND_DIR/requirements.txt"
      fi
      if [[ "$BACKEND_KIND" == "django" ]]; then
        mkdir -p "$BACKEND_DIR/logs"
        run_in "$BACKEND_DIR" "$python_bin" manage.py migrate --noinput
      else
        run_in "$BACKEND_DIR" "$python_bin" -m flask --app mysite.app:create_app db upgrade
      fi
      ;;
    gin)
      if [[ "$RUNTIME_MODE" == "system" ]]; then
        require_command "$GO_BIN" "所选后端需要 Go 1.21+"
      fi
      [[ -f "$BACKEND_DIR/go.sum" ]] && backend_signature="$(file_signature "$BACKEND_DIR/go.sum")"
      if [[ "$RUNTIME_MODE" == "system" ]]; then
        run_go_in "$BACKEND_DIR" mod download
      fi
      run_go_in "$BACKEND_DIR" build -o "$BIN_DIR/backend" .
      ;;
    springboot)
      if [[ "$RUNTIME_MODE" == "system" ]]; then
        require_command "$JAVA_BIN" "所选后端需要 JDK 17+"
        require_command "$MAVEN_BIN" "所选后端需要 Maven 3.8+"
      fi
      [[ -f "$BACKEND_DIR/pom.xml" ]] && backend_signature="$(file_signature "$BACKEND_DIR/pom.xml")"
      run_maven_in "$BACKEND_DIR" -q -DskipTests package
      ;;
  esac
  write_state "$frontend_signature" "$backend_signature"
  printf '初始化完成。\n'
}

process_record_path() {
  printf '%s/%s.process\n' "$RUNTIME_DIR" "$1"
}

read_process_metadata() {
  local name="$1" path
  path="$(process_record_path "$name")"
  PROCESS_PID=""
  PROCESS_STARTED=""
  PROCESS_COMMAND=""
  [[ -f "$path" ]] || return 1
  PROCESS_PID="$(sed -n '1p' "$path" 2>/dev/null || true)"
  PROCESS_STARTED="$(sed -n '2p' "$path" 2>/dev/null || true)"
  PROCESS_COMMAND="$(sed -n '3p' "$path" 2>/dev/null || true)"
  [[ "$PROCESS_PID" =~ ^[0-9]+$ && -n "$PROCESS_STARTED" && -n "$PROCESS_COMMAND" ]]
}

process_state() {
  local name="$1" actual_started actual_command
  read_process_metadata "$name" || return 1
  process_is_alive "$PROCESS_PID" || return 1
  actual_started="$(process_fingerprint "$PROCESS_PID")"
  actual_command="$(process_command "$PROCESS_PID")"
  [[ -n "$actual_started" && -n "$actual_command" ]] || return 2
  [[ "$actual_started" == "$PROCESS_STARTED" && "$actual_command" == "$PROCESS_COMMAND" ]]
}

process_matches() {
  process_state "$1"
}

remove_process_metadata() {
  local name="$1"
  rm -f "$(process_record_path "$name")" \
    "$RUNTIME_DIR/$name.pid" "$RUNTIME_DIR/$name.started" "$RUNTIME_DIR/$name.command"
}

pending_process_matches() {
  local actual_started actual_command
  [[ "$PENDING_PID" =~ ^[0-9]+$ ]] || return 1
  process_is_alive "$PENDING_PID" || return 1
  if [[ -n "$PENDING_STARTED" && -n "$PENDING_COMMAND" ]]; then
    actual_started="$(process_fingerprint "$PENDING_PID")"
    actual_command="$(process_command "$PENDING_PID")"
    if [[ -n "$actual_started" && -n "$actual_command" && "$actual_started" == "$PENDING_STARTED" && "$actual_command" == "$PENDING_COMMAND" ]]; then
      return 0
    fi
  fi
  pending_is_running_job
}

pending_is_running_job() {
  local job_pid
  while IFS= read -r job_pid; do
    [[ "$job_pid" == "$PENDING_PID" ]] && return 0
  done < <(jobs -pr 2>/dev/null || true)
  return 1
}

clear_pending_process() {
  PENDING_NAME=""
  PENDING_PID=""
  PENDING_STARTED=""
  PENDING_COMMAND=""
}

terminate_pending_process() {
  local count=0 pid
  if pending_process_matches; then
    pid="$PENDING_PID"
    kill "$pid" 2>/dev/null || true
    while (( count < 40 )) && pending_process_matches; do
      sleep 0.2
      count=$((count + 1))
    done
    if pending_process_matches; then
      kill -9 "$PENDING_PID" 2>/dev/null || true
    fi
  fi
  clear_pending_process
}

record_process() {
  local name="$1" pid="$2" fingerprint command previous_fingerprint="" previous_command="" attempts=0 temporary
  PENDING_NAME="$name"
  PENDING_PID="$pid"
  PENDING_STARTED=""
  PENDING_COMMAND=""
  while (( attempts < 50 )); do
    process_is_alive "$pid" || { clear_pending_process; die "$name 进程启动后立即退出，请查看日志"; }
    fingerprint="$(process_fingerprint "$pid")"
    command="$(process_command "$pid")"
    if [[ -n "$previous_fingerprint" && -n "$fingerprint" && "$fingerprint" != "$previous_fingerprint" ]]; then
      clear_pending_process
      die "$name 进程 PID 在登记期间已被复用，已拒绝记录"
    fi
    if [[ -n "$fingerprint" && -n "$command" && "$fingerprint" == "$previous_fingerprint" && "$command" == "$previous_command" ]]; then
      PENDING_STARTED="$fingerprint"
      PENDING_COMMAND="$command"
      temporary="$(mktemp "$RUNTIME_DIR/.$name.process.XXXXXX")"
      {
        printf '%s\n' "$pid"
        printf '%s\n' "$fingerprint"
        printf '%s\n' "$command"
      } >"$temporary"
      mv -f "$temporary" "$(process_record_path "$name")"
      clear_pending_process
      return 0
    fi
    previous_fingerprint="$fingerprint"
    previous_command="$command"
    PENDING_STARTED="$fingerprint"
    PENDING_COMMAND="$command"
    sleep 0.1
    attempts=$((attempts + 1))
  done
  terminate_pending_process
  die "无法记录 $name 进程的安全启动标识"
}

backend_jar() {
  local jar
  jar="$(find "$BACKEND_DIR/target" -maxdepth 1 -type f -name '*.jar' ! -name '*.jar.original' -print 2>/dev/null | sort | sed -n '1p')"
  [[ -n "$jar" ]] || die "未找到 Spring Boot Jar，请先执行 ./manage.sh init"
  printf '%s\n' "$jar"
}

spawn_backend() {
  local pid python_bin jar
  export_backend_env
  case "$BACKEND_KIND" in
    django)
      python_bin="$VENV_DIR/bin/python"
      (cd "$BACKEND_DIR" && exec nohup "$python_bin" manage.py runserver "127.0.0.1:$BACKEND_PORT" --noreload) </dev/null >>"$LOG_DIR/backend.log" 2>&1 &
      ;;
    flask)
      python_bin="$VENV_DIR/bin/python"
      (cd "$BACKEND_DIR" && exec nohup "$python_bin" -m flask --app mysite.app:create_app run --host=127.0.0.1 --port="$BACKEND_PORT" --no-reload) </dev/null >>"$LOG_DIR/backend.log" 2>&1 &
      ;;
    gin)
      (cd "$BACKEND_DIR" && exec nohup "$BIN_DIR/backend") </dev/null >>"$LOG_DIR/backend.log" 2>&1 &
      ;;
    springboot)
      jar="$(backend_jar)"
      (cd "$BACKEND_DIR" && exec nohup "$JAVA_BIN" -Duser.home="$RUNTIME_DIR/home" -jar "$jar") </dev/null >>"$LOG_DIR/backend.log" 2>&1 &
      ;;
  esac
  pid=$!
  PENDING_NAME=backend PENDING_PID="$pid" PENDING_STARTED="" PENDING_COMMAND=""
  record_process backend "$pid"
  STARTED_BACKEND=1
}

spawn_frontend() {
  local vite="$FRONTEND_DIR/node_modules/.bin/vite" pid
  [[ -x "$vite" ]] || die "未找到 Vite，请先执行 ./manage.sh init"
  (cd "$FRONTEND_DIR" && export VITE_PROXY_TARGET="http://127.0.0.1:$BACKEND_PORT" && exec nohup "$NODE_BIN" "$vite" --host 127.0.0.1 --port "$FRONTEND_PORT" --strictPort) </dev/null >>"$LOG_DIR/frontend.log" 2>&1 &
  pid=$!
  PENDING_NAME=frontend PENDING_PID="$pid" PENDING_STARTED="" PENDING_COMMAND=""
  record_process frontend "$pid"
  STARTED_FRONTEND=1
}

wait_for_url() {
  local url="$1" label="$2" timeout="$3" process_name="$4" waited=0
  while (( waited < timeout )); do
    process_matches "$process_name" || die "$label 进程已退出，请执行 ./manage.sh logs 查看日志"
    if curl -fsS --connect-timeout 1 --max-time 2 -- "$url" >/dev/null 2>&1; then
      process_matches "$process_name" || die "$label 在健康检查后退出，请执行 ./manage.sh logs 查看日志"
      printf '%s健康检查通过：%s\n' "$label" "$url"
      return 0
    fi
    sleep 1
    waited=$((waited + 1))
  done
  die "$label 启动超时，请执行 ./manage.sh logs 查看日志"
}

port_open() {
  local port="$1"
  (exec 9<>/dev/tcp/127.0.0.1/"$port") >/dev/null 2>&1
}

ensure_ports_available() {
  if port_open "$BACKEND_PORT"; then
    die "后端端口 $BACKEND_PORT 已被其他进程占用"
  fi
  if port_open "$FRONTEND_PORT"; then
    die "前端端口 $FRONTEND_PORT 已被其他进程占用"
  fi
}

terminate_process() {
  local name="$1" pid count=0 state
  if process_state "$name"; then
    pid="$PROCESS_PID"
    kill "$pid" 2>/dev/null || true
    while (( count < 40 )) && process_state "$name"; do
      sleep 0.2
      count=$((count + 1))
    done
    if process_state "$name"; then
      kill -9 "$PROCESS_PID" 2>/dev/null || true
      count=0
      while (( count < 20 )) && process_state "$name"; do
        sleep 0.1
        count=$((count + 1))
      done
      if process_state "$name"; then
        printf '错误：%s 进程无法安全终止，已保留进程元数据\n' "$name" >&2
        return 2
      else
        state=$?
        if (( state == 2 )); then
          printf '错误：无法核验 %s 进程是否已经终止，已保留进程元数据\n' "$name" >&2
          return 2
        fi
      fi
    else
      state=$?
      if (( state == 2 )); then
        printf '错误：终止 %s 进程时无法继续核验启动指纹，已保留进程元数据\n' "$name" >&2
        return 2
      fi
    fi
  else
    state=$?
    if (( state == 2 )); then
      printf '错误：无法核验 %s 进程的启动指纹，已拒绝停止并保留元数据\n' "$name" >&2
      return 2
    fi
  fi
  remove_process_metadata "$name"
}

rollback_startup() {
  (( STARTUP_ACTIVE )) || return 0
  STARTUP_ACTIVE=0
  printf '警告：启动未完成，正在回滚本次已启动的进程。\n' >&2
  terminate_pending_process
  terminate_process frontend || printf '警告：前端进程需要人工核验。\n' >&2
  terminate_process backend || printf '警告：后端进程需要人工核验。\n' >&2
  STARTED_FRONTEND=0
  STARTED_BACKEND=0
}

manager_exit() {
  local status=$?
  trap - EXIT
  rollback_startup
  cleanup_lock_publish
  release_reclaim_lock
  release_lock
  exit "$status"
}

stop_services() {
  terminate_process frontend
  terminate_process backend
  printf '项目已停止。\n'
}

start_services() {
  if process_matches backend && process_matches frontend; then
    printf '项目已经在运行。\n'
    show_status
    return 0
  fi
  terminate_process frontend
  terminate_process backend
  ensure_ports_available
  require_command curl "健康检查需要 curl"
  initialise
  ensure_ports_available
  STARTUP_ACTIVE=1
  STARTED_BACKEND=0
  STARTED_FRONTEND=0
  spawn_backend
  wait_for_url "http://127.0.0.1:$BACKEND_PORT/api/health/" "后端" 60 backend
  spawn_frontend
  wait_for_url "http://127.0.0.1:$FRONTEND_PORT/" "前端" 30 frontend
  process_matches backend || die "后端在启动完成前退出"
  process_matches frontend || die "前端在启动完成前退出"
  STARTUP_ACTIVE=0
  printf '启动完成：前端 http://127.0.0.1:%s\n' "$FRONTEND_PORT"
}

show_status() {
  local name state
  for name in backend frontend; do
    if process_state "$name"; then
      printf '%s: 运行中 (PID %s)\n' "$name" "$PROCESS_PID"
    else
      state=$?
      if (( state == 2 )); then
        printf '%s: 无法核验（保留进程元数据）\n' "$name"
      else
        printf '%s: 未运行\n' "$name"
      fi
    fi
  done
}

show_logs() {
  ensure_runtime
  local files=()
  [[ -f "$LOG_DIR/backend.log" ]] && files+=("$LOG_DIR/backend.log")
  [[ -f "$LOG_DIR/frontend.log" ]] && files+=("$LOG_DIR/frontend.log")
  (( ${#files[@]} > 0 )) || { printf '暂无日志。\n'; return 0; }
  tail -n 100 -f "${files[@]}"
}

run_checks() {
  initialise
  if grep -q '"lint"[[:space:]]*:' "$FRONTEND_DIR/package.json"; then
    run_npm_in "$FRONTEND_DIR" run lint
  fi
  run_npm_in "$FRONTEND_DIR" run build
  export_backend_env
  case "$BACKEND_KIND" in
    django) run_in "$BACKEND_DIR" "$VENV_DIR/bin/python" manage.py check ;;
    flask) run_in "$BACKEND_DIR" "$VENV_DIR/bin/python" -m compileall -q . ;;
    gin) run_go_in "$BACKEND_DIR" test ./... ;;
    springboot) run_maven_in "$BACKEND_DIR" -q test ;;
  esac
  printf '检查通过。\n'
}

doctor() {
  local failures=0
  printf '项目：%s\n技术栈：%s + %s\n端口：前端 %s，后端 %s\n' "$PROJECT_NAME" "$FRONTEND_KIND" "$BACKEND_KIND" "$FRONTEND_PORT" "$BACKEND_PORT"
  printf '运行模式：%s\n' "$RUNTIME_MODE"
  if [[ "$RUNTIME_MODE" == "embedded" ]]; then
    printf '离线约束：已启用\n环境标识：%s\n目标平台：%s\n' "$BUNDLE_ID" "$BUNDLE_TARGET"
  else
    printf '离线约束：未启用（使用系统运行时）\n'
  fi
  print_command_path bash bash || failures=$((failures + 1))
  print_command_path curl curl || failures=$((failures + 1))
  print_command_path node "$NODE_BIN" || failures=$((failures + 1))
  print_command_path npm "$NPM_BIN" || failures=$((failures + 1))
  case "$BACKEND_KIND" in
    django|flask)
      print_command_path python "$PYTHON_RUNTIME_BIN" || failures=$((failures + 1))
      ;;
    gin)
      print_command_path go "$GO_BIN" || failures=$((failures + 1))
      ;;
    springboot)
      print_command_path java "$JAVA_BIN" || failures=$((failures + 1))
      print_command_path maven "$MAVEN_BIN" || failures=$((failures + 1))
      ;;
  esac
  if [[ "$RUNTIME_MODE" == "embedded" ]]; then
    printf 'PASS %-12s %s\n' npm-cache "$NPM_CACHE_DIR"
    [[ -z "$PIP_CACHE_DIR" ]] || printf 'PASS %-12s %s\n' pip-cache "$PIP_CACHE_DIR"
    [[ -z "$MAVEN_CACHE_DIR" ]] || printf 'PASS %-12s %s\n' maven-repo "$MAVEN_CACHE_DIR"
  fi
  (( failures == 0 )) || die "环境检查发现 $failures 项缺失依赖"
  printf '环境检查通过。\n'
}

trap manager_exit EXIT
trap 'exit 130' INT
trap 'exit 129' HUP
trap 'exit 143' TERM

case "$COMMAND" in
  doctor) doctor ;;
  setup|start) acquire_lock; start_services ;;
  init) acquire_lock; initialise ;;
  stop) acquire_lock; stop_services ;;
  restart) acquire_lock; stop_services; start_services ;;
  status) show_status ;;
  logs) show_logs ;;
  test)
    acquire_lock
    process_matches backend || die "后端未运行，请先执行 ./manage.sh start"
    "$ROOT/scripts/verify_api_contract.sh" "http://127.0.0.1:$BACKEND_PORT"
    ;;
  check) acquire_lock; run_checks ;;
esac
