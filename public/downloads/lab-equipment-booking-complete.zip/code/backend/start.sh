#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd -P)"
if [[ -x "$PROJECT_ROOT/manage.sh" && -f "$PROJECT_ROOT/.bishe-project.json" ]]; then
    exec "$PROJECT_ROOT/manage.sh" start
fi

# Go Gin Base Project Start Script

echo "Starting Go Gin Base Server..."

# 检查 .env 文件是否存在
if [ ! -f .env ]; then
    echo "Warning: .env file not found. Using .env.example as template."
    echo "Please edit .env, then run this script again."
    cp .env.example .env
    exit 1
fi

# 构建项目
echo "Building project..."
GO_BIN="go"
GO_FLAGS="-mod=mod"
if [ -x "$PROJECT_ROOT/.toolchain/runtimes/go/bin/go" ]; then
    GO_BIN="$PROJECT_ROOT/.toolchain/runtimes/go/bin/go"
fi
if [ -d "$SCRIPT_DIR/vendor" ]; then
    GO_FLAGS="-mod=vendor"
fi
env GOTOOLCHAIN=local GOPROXY=off GOSUMDB=off CGO_ENABLED=0 \
    "$GO_BIN" build "$GO_FLAGS" -o gin_base_server .

# 启动服务
echo "Starting server..."
# 设置 Gin 模式为 release（生产环境），减少日志输出
export GIN_MODE=release
./gin_base_server
