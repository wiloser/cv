package core

import (
	"log"
	"os"

	"github.com/glebarez/sqlite"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

var DB *gorm.DB

func InitDB(config *Config) {
	var err error
	// 默认 Warn 级别，仅记录慢查询和错误，与 Django/Flask 对齐
	logLevel := logger.Warn

	var dialector gorm.Dialector = mysql.Open(config.Database.DSN())
	if config.Database.Driver == "sqlite" {
		dialector = sqlite.Open(config.Database.SQLitePath)
	}

	DB, err = gorm.Open(dialector, &gorm.Config{
		Logger: logger.New(
			log.New(os.Stdout, "\r\n", log.LstdFlags),
			logger.Config{
				LogLevel:                  logLevel,
				IgnoreRecordNotFoundError: true,
			},
		),
	})

	if err != nil {
		log.Fatalf("Failed to connect to database: %v", err)
	}

	log.Println("Database connected successfully")
}

func AutoMigrate(models ...interface{}) {
	// 自动迁移模型
	if len(models) > 0 {
		if err := DB.AutoMigrate(models...); err != nil {
			log.Fatalf("Database auto-migration failed: %v", err)
		}
		log.Println("Database auto-migration completed")
	}
}

func GetDB() *gorm.DB {
	return DB
}
