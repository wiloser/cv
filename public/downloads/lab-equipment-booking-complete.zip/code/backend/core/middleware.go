package core

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

// JWTAuth JWT 认证中间件
func JWTAuth() gin.HandlerFunc {
	return func(c *gin.Context) {
		config, exists := c.Get("config")
		if !exists {
			c.JSON(http.StatusInternalServerError, Response{
				Code:    500,
				Message: "Configuration error",
				Data:    nil,
			})
			c.Abort()
			return
		}

		authHeader := c.GetHeader("Authorization")
		if authHeader == "" {
			c.JSON(http.StatusUnauthorized, Response{
				Code:    401,
				Message: "Missing authorization header",
				Data:    nil,
			})
			c.Abort()
			return
		}

		tokenString := strings.TrimPrefix(authHeader, "Bearer ")
		if tokenString == authHeader {
			c.JSON(http.StatusUnauthorized, Response{
				Code:    401,
				Message: "Invalid authorization format, should be: Bearer <token>",
				Data:    nil,
			})
			c.Abort()
			return
		}

		claims, err := ParseToken(tokenString, config.(*Config))
		if err != nil || claims.TokenType != "access" {
			c.JSON(http.StatusUnauthorized, Response{
				Code:    401,
				Message: "Invalid or expired token",
				Data:    nil,
			})
			c.Abort()
			return
		}

		// 将用户信息存入上下文
		c.Set("user_id", claims.UserID)
		c.Set("username", claims.Username)
		c.Set("role", claims.Role)
		c.Next()
	}
}

// CORS 中间件
func CORS(config *Config) gin.HandlerFunc {
	return func(c *gin.Context) {
		origin := c.GetHeader("Origin")

		// 检查是否在允许的来源列表中
		allowed := false
		for _, allowedOrigin := range config.CORS.AllowOrigins {
			if origin == allowedOrigin {
				allowed = true
				break
			}
		}

		if allowed {
			c.Header("Access-Control-Allow-Origin", origin)
			c.Header("Access-Control-Allow-Credentials", "true")
			c.Header("Access-Control-Allow-Methods", strings.Join(config.CORS.AllowMethods, ","))
			c.Header("Access-Control-Allow-Headers", strings.Join(config.CORS.AllowHeaders, ","))
		}

		// 处理预检请求
		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(http.StatusNoContent)
			return
		}

		c.Next()
	}
}

// Logger 日志中间件
func Logger() gin.HandlerFunc {
	return gin.LoggerWithFormatter(func(param gin.LogFormatterParams) string {
		return "[GIN] " + param.Method + " " + param.Path + " " +
			param.ErrorMessage + "\n"
	})
}

// Recovery 恢复中间件
func Recovery() gin.HandlerFunc {
	return gin.CustomRecovery(func(c *gin.Context, recovered interface{}) {
		c.JSON(http.StatusInternalServerError, Response{
			Code:    500,
			Message: "Internal server error",
			Data:    nil,
		})
	})
}
