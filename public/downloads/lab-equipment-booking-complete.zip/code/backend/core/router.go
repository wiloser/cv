package core

import (
	"github.com/gin-gonic/gin"
)

var config *Config

func SetupRouter() *gin.Engine {
	gin.SetMode(config.Server.Mode)

	router := gin.New()

	// 使用自定义中间件
	router.Use(Recovery())
	router.Use(Logger())
	router.Use(CORS(config))

	// 健康检查
	router.GET("/api/health/", func(c *gin.Context) {
		Success(c, gin.H{"status": "ok"})
	})

	return router
}

func SetConfig(cfg *Config) {
	config = cfg
}
