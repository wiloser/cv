package core

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

// RequireRole 角色验证中间件
func RequireRole(roles ...string) gin.HandlerFunc {
	return func(c *gin.Context) {
		userRole, exists := c.Get("role")
		if !exists {
			c.JSON(http.StatusForbidden, Response{
				Code:    403,
				Message: "Access denied",
				Data:    nil,
			})
			c.Abort()
			return
		}

		// 检查用户角色是否在允许的角色列表中
		allowed := false
		for _, role := range roles {
			if userRole.(string) == role {
				allowed = true
				break
			}
		}

		if !allowed {
			c.JSON(http.StatusForbidden, Response{
				Code:    403,
				Message: "Insufficient permissions",
				Data:    nil,
			})
			c.Abort()
			return
		}

		c.Next()
	}
}

// RequireAdmin 管理员权限中间件
func RequireAdmin() gin.HandlerFunc {
	return RequireRole("admin")
}
