# Gin 后端基础项目

可与仓库中的 React、Vue 前端任意组合。接口以根目录的 `API_CONTRACT.md` 为唯一契约。

## 启动

环境要求：Go 1.21+。开发环境采用纯 Go SQLite 驱动，无需安装 MySQL、SQLite、CGO 或 C 编译器。
派生项目统一在项目根目录运行 `./manage.sh setup`；后端入口会自动转交根目录管理器。

```bash
cp .env.example .env
./start.sh
```

`start.sh` 只使用本地 vendor 或已经存在的 Go 模块缓存，并关闭模块代理；依赖不完整时会直接失败，
不会隐式联网。通过根目录生成器创建随环境项目后，应统一使用项目根目录的 `manage.sh`。

开发服务地址为 `http://127.0.0.1:8181`。启动时由 GORM 自动迁移用户表；生产环境可将
`DB_DRIVER` 改为 `mysql` 并填写对应连接信息。

## 验证

```bash
go test ./...
../scripts/verify_api_contract.sh
```

第二条命令需要后端已启动。
