package users

import (
	"strconv"

	"gin_base/core"

	"github.com/gin-gonic/gin"
)

// Register 用户注册
func Register(c *gin.Context) {
	var req RegisterRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		core.BadRequest(c, "Invalid request: "+err.Error())
		return
	}

	// 验证密码一致性
	if req.Password != req.PasswordConfirm {
		core.BadRequest(c, "两次密码不一致")
		return
	}

	user, err := CreateUser(&req)
	if err != nil {
		if err == ErrUserExists || err == ErrEmailExists || err == ErrPhoneExists {
			core.BadRequest(c, err.Error())
			return
		}
		core.InternalServerError(c, "Failed to create user")
		return
	}

	core.Created(c, "注册成功", user.ToResponse())
}

// Login 用户登录
func Login(c *gin.Context) {
	var req LoginRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		core.BadRequest(c, "Invalid request: "+err.Error())
		return
	}

	user, err := AuthenticateUser(&req)
	if err != nil {
		if err == ErrUserNotFound || err == ErrInvalidPassword {
			core.Unauthorized(c, "用户名或密码错误")
			return
		}
		core.InternalServerError(c, "登录失败")
		return
	}

	// 生成 JWT Token
	config := c.MustGet("config").(*core.Config)
	token, err := core.GenerateToken(user.ID, user.Username, user.Role, config)
	if err != nil {
		core.InternalServerError(c, "Failed to generate token")
		return
	}

	// 生成 Refresh Token
	refreshToken, err := core.GenerateRefreshToken(user.ID, user.Username, user.Role, config)
	if err != nil {
		core.InternalServerError(c, "Failed to generate refresh token")
		return
	}

	response := LoginResponse{
		Access:  token,
		Refresh: refreshToken,
		User:    user.ToResponse(),
	}

	core.SuccessWithMessage(c, "登录成功", response)
}

// GetProfile 获取个人信息
func GetProfile(c *gin.Context) {
	userID := c.MustGet("user_id").(uint)

	user, err := GetUserByID(userID)
	if err != nil {
		core.NotFound(c, "用户不存在")
		return
	}

	core.Success(c, user.ToResponse())
}

// UpdateProfile 更新个人信息
func UpdateProfile(c *gin.Context) {
	userID := c.MustGet("user_id").(uint)

	var req UpdateProfileRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		core.BadRequest(c, "Invalid request: "+err.Error())
		return
	}

	user, err := UpdateUser(userID, &req)
	if err != nil {
		if err == ErrEmailExists || err == ErrPhoneExists {
			core.BadRequest(c, err.Error())
			return
		}
		core.InternalServerError(c, "Failed to update profile")
		return
	}

	core.Success(c, user.ToResponse())
}

// ChangePasswordHandler 修改密码
func ChangePasswordHandler(c *gin.Context) {
	userID := c.MustGet("user_id").(uint)

	var req ChangePasswordRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		core.BadRequest(c, "Invalid request: "+err.Error())
		return
	}

	// 验证新密码一致性
	if req.NewPassword != req.NewPasswordConfirm {
		core.BadRequest(c, "两次密码不一致")
		return
	}

	if err := ChangePassword(userID, &req); err != nil {
		if err == ErrInvalidPassword {
			core.BadRequest(c, "旧密码错误")
			return
		}
		core.InternalServerError(c, "修改密码失败")
		return
	}

	core.SuccessWithMessage(c, "密码修改成功", nil)
}

// ListUsersHandler 获取用户列表（管理员）
func ListUsersHandler(c *gin.Context) {
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	pageSize, _ := strconv.Atoi(c.DefaultQuery("page_size", "10"))
	if page < 1 {
		page = 1
	}
	if pageSize < 1 {
		pageSize = 10
	} else if pageSize > 100 {
		pageSize = 100
	}

	users, total, err := ListUsers(page, pageSize)
	if err != nil {
		core.InternalServerError(c, "Failed to get users")
		return
	}

	userResponses := make([]map[string]interface{}, len(users))
	for i, user := range users {
		userResponses[i] = user.ToResponse()
	}

	core.SuccessPage(c, total, page, pageSize, userResponses)
}

// RefreshToken 刷新 Token
func RefreshToken(c *gin.Context) {
	var req RefreshTokenRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		core.BadRequest(c, "Refresh token 不能为空")
		return
	}

	config := c.MustGet("config").(*core.Config)

	// 解析 refresh token
	claims, err := core.ParseToken(req.Refresh, config)
	if err != nil || claims.TokenType != "refresh" {
		core.Unauthorized(c, "无效的 Refresh Token")
		return
	}

	// 生成新的 access token
	token, err := core.GenerateToken(claims.UserID, claims.Username, claims.Role, config)
	if err != nil {
		core.InternalServerError(c, "Failed to refresh token")
		return
	}

	core.SuccessWithMessage(c, "Token 刷新成功", gin.H{
		"access": token,
	})
}

// Logout 用户退出登录
func Logout(c *gin.Context) {
	// JWT 是无状态的，服务端不做处理，客户端删除 token 即可
	core.SuccessWithMessage(c, "退出成功", nil)
}
