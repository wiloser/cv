package users

// LoginRequest 登录请求
type LoginRequest struct {
	Username string `json:"username" binding:"required"`
	Password string `json:"password" binding:"required"`
}

// RegisterRequest 注册请求
type RegisterRequest struct {
	Username        string `json:"username" binding:"required,min=3,max=50"`
	Email           string `json:"email" binding:"omitempty,email"`
	Password        string `json:"password" binding:"required,min=6"`
	PasswordConfirm string `json:"password_confirm" binding:"required"`
	Phone           string `json:"phone"`
}

// ChangePasswordRequest 修改密码请求
type ChangePasswordRequest struct {
	OldPassword        string `json:"old_password" binding:"required"`
	NewPassword        string `json:"new_password" binding:"required,min=6"`
	NewPasswordConfirm string `json:"new_password_confirm" binding:"required"`
}

// UpdateProfileRequest 更新个人信息请求
type UpdateProfileRequest struct {
	Email *string `json:"email" binding:"omitempty,email"`
	Phone *string `json:"phone"`
}

// RefreshTokenRequest 刷新Token请求
type RefreshTokenRequest struct {
	Refresh string `json:"refresh" binding:"required"`
}

// LoginResponse 登录响应
type LoginResponse struct {
	Access  string                 `json:"access"`
	Refresh string                 `json:"refresh"`
	User    map[string]interface{} `json:"user"`
}
