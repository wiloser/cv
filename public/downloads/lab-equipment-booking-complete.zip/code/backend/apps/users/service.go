package users

import (
	"errors"
	"time"

	"gin_base/core"
)

var (
	ErrUserNotFound    = errors.New("用户不存在")
	ErrUserExists      = errors.New("用户已存在")
	ErrEmailExists     = errors.New("邮箱已被注册")
	ErrPhoneExists     = errors.New("手机号已被注册")
	ErrInvalidPassword = errors.New("密码错误")
	ErrInvalidEmail    = errors.New("邮箱格式不正确")
)

// CreateUser 创建用户
func CreateUser(req *RegisterRequest) (*User, error) {
	db := core.GetDB()

	// 检查用户名是否已存在
	var existingUser User
	if err := db.Where("username = ?", req.Username).First(&existingUser).Error; err == nil {
		return nil, ErrUserExists
	}

	// 检查邮箱是否已存在
	if req.Email != "" {
		if err := db.Where("email = ?", req.Email).First(&existingUser).Error; err == nil {
			return nil, ErrEmailExists
		}
	}

	if req.Phone != "" {
		if err := db.Where("phone = ?", req.Phone).First(&existingUser).Error; err == nil {
			return nil, ErrPhoneExists
		}
	}

	// 创建用户
	user := &User{
		Username: req.Username,
		Email:    optionalString(req.Email),
		Phone:    optionalString(req.Phone),
		Role:     "user",
		IsActive: true,
	}

	// 加密密码
	if err := user.SetPassword(req.Password); err != nil {
		return nil, err
	}

	// 保存到数据库
	if err := db.Create(user).Error; err != nil {
		return nil, err
	}

	return user, nil
}

// AuthenticateUser 用户认证
func AuthenticateUser(req *LoginRequest) (*User, error) {
	db := core.GetDB()

	var user User
	if err := db.Where("username = ?", req.Username).First(&user).Error; err != nil {
		return nil, ErrUserNotFound
	}

	// 验证密码
	if !user.CheckPassword(req.Password) {
		return nil, ErrInvalidPassword
	}

	// 更新最后登录时间
	now := time.Now()
	user.LastLogin = &now
	db.Save(&user)

	return &user, nil
}

// GetUserByID 根据ID获取用户
func GetUserByID(id uint) (*User, error) {
	db := core.GetDB()

	var user User
	if err := db.First(&user, id).Error; err != nil {
		return nil, ErrUserNotFound
	}

	return &user, nil
}

// UpdateUser 更新用户信息
func UpdateUser(id uint, req *UpdateProfileRequest) (*User, error) {
	db := core.GetDB()

	user, err := GetUserByID(id)
	if err != nil {
		return nil, err
	}

	// 更新字段
	if req.Email != nil {
		if *req.Email != "" {
			var count int64
			db.Model(&User{}).Where("email = ? AND id <> ?", *req.Email, id).Count(&count)
			if count > 0 {
				return nil, ErrEmailExists
			}
		}
		user.Email = optionalString(*req.Email)
	}
	if req.Phone != nil {
		if *req.Phone != "" {
			var count int64
			db.Model(&User{}).Where("phone = ? AND id <> ?", *req.Phone, id).Count(&count)
			if count > 0 {
				return nil, ErrPhoneExists
			}
		}
		user.Phone = optionalString(*req.Phone)
	}

	if err := db.Save(user).Error; err != nil {
		return nil, err
	}

	return user, nil
}

func optionalString(value string) *string {
	if value == "" {
		return nil
	}
	return &value
}

// ChangePassword 修改密码
func ChangePassword(id uint, req *ChangePasswordRequest) error {
	db := core.GetDB()

	user, err := GetUserByID(id)
	if err != nil {
		return err
	}

	// 验证旧密码
	if !user.CheckPassword(req.OldPassword) {
		return ErrInvalidPassword
	}

	// 设置新密码
	if err := user.SetPassword(req.NewPassword); err != nil {
		return err
	}

	return db.Save(user).Error
}

// ListUsers 获取用户列表（分页）
func ListUsers(page, pageSize int) ([]User, int64, error) {
	db := core.GetDB()

	var users []User
	var total int64

	// 查询总数
	db.Model(&User{}).Count(&total)

	// 分页查询
	offset := (page - 1) * pageSize
	if err := db.Order("created_at DESC").Offset(offset).Limit(pageSize).Find(&users).Error; err != nil {
		return nil, 0, err
	}

	return users, total, nil
}
