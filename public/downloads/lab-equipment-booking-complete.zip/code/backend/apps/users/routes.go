package users

import (
	"gin_base/core"

	"github.com/gin-gonic/gin"
)

// RegisterRoutes 注册用户相关路由
func RegisterRoutes(router *gin.Engine) {
	// 公开路由（不需要认证）
	publicGroup := router.Group("/api/users")
	{
		publicGroup.POST("/register/", Register)
		publicGroup.POST("/login/", Login)
		publicGroup.POST("/token/refresh/", RefreshToken)
	}

	// 需要认证的路由
	authGroup := router.Group("/api/users")
	authGroup.Use(core.JWTAuth())
	{
		authGroup.GET("/profile/", GetProfile)
		authGroup.PUT("/profile/", UpdateProfile)
		authGroup.POST("/password/change/", ChangePasswordHandler)
		authGroup.POST("/logout/", Logout)

		// 管理员路由
		adminGroup := authGroup.Group("")
		adminGroup.Use(core.RequireAdmin())
		adminGroup.GET("/list/", ListUsersHandler)
	}
}
