package equipment

import (
	"fmt"
	"net/http"
	"strings"
	"time"

	"gin_base/core"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

// Equipment describes a laboratory asset that can be booked.
type Equipment struct {
	ID        uint      `gorm:"primaryKey" json:"id"`
	Name      string    `gorm:"size:120;not null" json:"name"`
	Code      string    `gorm:"size:40;uniqueIndex;not null" json:"code"`
	Category  string    `gorm:"size:60;index;not null" json:"category"`
	Lab       string    `gorm:"size:80;not null" json:"lab"`
	Status    string    `gorm:"size:20;index;not null" json:"status"`
	RiskLevel string    `gorm:"size:20;not null" json:"risk_level"`
	Manager   string    `gorm:"size:40;not null" json:"manager"`
	CreatedAt time.Time `json:"created_at"`
}

// Booking stores an approved or pending equipment reservation.
type Booking struct {
	ID            uint      `gorm:"primaryKey" json:"id"`
	EquipmentID   uint      `gorm:"index;not null" json:"equipment_id"`
	Equipment     Equipment `json:"equipment"`
	Requester     string    `gorm:"size:40;not null" json:"requester"`
	Purpose       string    `gorm:"size:160;not null" json:"purpose"`
	StartAt       time.Time `gorm:"index;not null" json:"start_at"`
	EndAt         time.Time `gorm:"index;not null" json:"end_at"`
	Status        string    `gorm:"size:20;index;not null" json:"status"`
	ConflictScore int       `gorm:"not null;default:0" json:"conflict_score"`
	CreatedAt     time.Time `json:"created_at"`
}

type CheckRequest struct {
	EquipmentID uint   `json:"equipment_id" binding:"required"`
	StartAt     string `json:"start_at" binding:"required"`
	EndAt       string `json:"end_at" binding:"required"`
}

type CheckResult struct {
	Available     bool        `json:"available"`
	ConflictCount int         `json:"conflict_count"`
	ConflictScore int         `json:"conflict_score"`
	Message       string      `json:"message"`
	Suggestions   []Equipment `json:"suggestions"`
}

type CreateRequest struct {
	CheckRequest
	Requester string `json:"requester" binding:"required"`
	Purpose   string `json:"purpose" binding:"required"`
}

// HasOverlap follows the half-open interval rule [start, end), so adjacent
// reservations do not conflict.
func HasOverlap(start, end, existingStart, existingEnd time.Time) bool {
	return start.Before(existingEnd) && existingStart.Before(end)
}

func conflictScore(overlaps int, riskLevel string) int {
	if overlaps == 0 {
		return 0
	}
	riskWeight := map[string]int{"低": 5, "中": 15, "高": 25}[riskLevel]
	score := overlaps*35 + riskWeight
	if score > 100 {
		return 100
	}
	return score
}

func parseTime(value string) (time.Time, error) {
	for _, layout := range []string{time.RFC3339, "2006-01-02T15:04", "2006-01-02 15:04"} {
		if parsed, err := time.ParseInLocation(layout, value, time.Local); err == nil {
			return parsed, nil
		}
	}
	return time.Time{}, fmt.Errorf("时间格式应为 RFC3339 或 YYYY-MM-DDTHH:mm")
}

func evaluate(db *gorm.DB, input CheckRequest) (CheckResult, time.Time, time.Time, error) {
	startAt, err := parseTime(input.StartAt)
	if err != nil {
		return CheckResult{}, time.Time{}, time.Time{}, err
	}
	endAt, err := parseTime(input.EndAt)
	if err != nil {
		return CheckResult{}, time.Time{}, time.Time{}, err
	}
	if !endAt.After(startAt) {
		return CheckResult{}, time.Time{}, time.Time{}, fmt.Errorf("结束时间必须晚于开始时间")
	}
	if endAt.Sub(startAt) > 8*time.Hour {
		return CheckResult{}, time.Time{}, time.Time{}, fmt.Errorf("单次预约不能超过 8 小时")
	}

	var target Equipment
	if err := db.First(&target, input.EquipmentID).Error; err != nil {
		return CheckResult{}, time.Time{}, time.Time{}, fmt.Errorf("设备不存在")
	}
	if target.Status != "可预约" {
		return CheckResult{}, time.Time{}, time.Time{}, fmt.Errorf("设备当前状态为%s，暂不可预约", target.Status)
	}

	var bookings []Booking
	if err := db.Where("equipment_id = ? AND status IN ?", target.ID, []string{"待审核", "已通过"}).Find(&bookings).Error; err != nil {
		return CheckResult{}, time.Time{}, time.Time{}, err
	}
	overlaps := 0
	for _, booking := range bookings {
		if HasOverlap(startAt, endAt, booking.StartAt, booking.EndAt) {
			overlaps++
		}
	}

	var alternatives []Equipment
	if overlaps > 0 {
		var candidates []Equipment
		if err := db.Where("category = ? AND status = ? AND id <> ?", target.Category, "可预约", target.ID).Find(&candidates).Error; err != nil {
			return CheckResult{}, time.Time{}, time.Time{}, err
		}
		for _, candidate := range candidates {
			var count int64
			db.Model(&Booking{}).
				Where("equipment_id = ? AND status IN ? AND start_at < ? AND end_at > ?", candidate.ID, []string{"待审核", "已通过"}, endAt, startAt).
				Count(&count)
			if count == 0 {
				alternatives = append(alternatives, candidate)
			}
			if len(alternatives) == 3 {
				break
			}
		}
	}

	result := CheckResult{
		Available:     overlaps == 0,
		ConflictCount: overlaps,
		ConflictScore: conflictScore(overlaps, target.RiskLevel),
		Suggestions:   alternatives,
	}
	if result.Available {
		result.Message = "所选时段可预约，未发现冲突"
	} else {
		result.Message = fmt.Sprintf("检测到 %d 个时段冲突，已推荐同类设备", overlaps)
	}
	return result, startAt, endAt, nil
}

// SeedDemoData creates a reproducible dataset for demonstrations.
func SeedDemoData() error {
	db := core.GetDB()
	var equipmentCount int64
	if err := db.Model(&Equipment{}).Count(&equipmentCount).Error; err != nil {
		return err
	}
	if equipmentCount == 0 {
		items := []Equipment{
			{Name: "高精度电子显微镜", Code: "EM-2201", Category: "成像设备", Lab: "材料分析实验室", Status: "可预约", RiskLevel: "高", Manager: "周老师"},
			{Name: "荧光光谱分析仪", Code: "FS-3102", Category: "光谱设备", Lab: "光电实验室", Status: "可预约", RiskLevel: "中", Manager: "林老师"},
			{Name: "三维结构光扫描仪", Code: "3DS-018", Category: "成像设备", Lab: "数字制造中心", Status: "可预约", RiskLevel: "中", Manager: "陈老师"},
			{Name: "多通道示波器", Code: "OSC-440", Category: "电子测量", Lab: "嵌入式实验室", Status: "可预约", RiskLevel: "低", Manager: "许老师"},
			{Name: "激光切割工作站", Code: "LC-900", Category: "加工设备", Lab: "创新工坊", Status: "维护中", RiskLevel: "高", Manager: "吴老师"},
			{Name: "热成像测温仪", Code: "TI-306", Category: "成像设备", Lab: "智能感知实验室", Status: "可预约", RiskLevel: "低", Manager: "唐老师"},
		}
		if err := db.Create(&items).Error; err != nil {
			return err
		}
	}

	var bookingCount int64
	if err := db.Model(&Booking{}).Count(&bookingCount).Error; err != nil || bookingCount > 0 {
		return err
	}
	var items []Equipment
	if err := db.Order("id").Find(&items).Error; err != nil {
		return err
	}
	base := time.Now().Truncate(time.Hour).Add(2 * time.Hour)
	bookings := []Booking{
		{EquipmentID: items[0].ID, Requester: "李若宁", Purpose: "纳米涂层表面形貌观察", StartAt: base, EndAt: base.Add(2 * time.Hour), Status: "已通过"},
		{EquipmentID: items[1].ID, Requester: "王思远", Purpose: "荧光材料发射光谱采集", StartAt: base.Add(3 * time.Hour), EndAt: base.Add(5 * time.Hour), Status: "待审核"},
		{EquipmentID: items[3].ID, Requester: "赵嘉禾", Purpose: "低功耗控制板信号调试", StartAt: base.Add(24 * time.Hour), EndAt: base.Add(26 * time.Hour), Status: "已通过"},
		{EquipmentID: items[2].ID, Requester: "孙雨桐", Purpose: "机械零件点云数据采集", StartAt: base.Add(27 * time.Hour), EndAt: base.Add(29 * time.Hour), Status: "待审核"},
	}
	return db.Create(&bookings).Error
}

func RegisterRoutes(router *gin.Engine) {
	group := router.Group("/api")
	{
		group.GET("/equipment/", listEquipment)
		group.GET("/bookings/", listBookings)
		group.GET("/dashboard/", dashboard)
		group.POST("/bookings/check/", checkBooking)
		group.POST("/bookings/", createBooking)
	}
}

func listEquipment(c *gin.Context) {
	var items []Equipment
	query := core.GetDB().Order("CASE status WHEN '可预约' THEN 0 ELSE 1 END, id")
	if category := strings.TrimSpace(c.Query("category")); category != "" {
		query = query.Where("category = ?", category)
	}
	if err := query.Find(&items).Error; err != nil {
		core.InternalServerError(c, "设备列表读取失败")
		return
	}
	core.Success(c, items)
}

func listBookings(c *gin.Context) {
	var items []Booking
	if err := core.GetDB().Preload("Equipment").Order("start_at").Find(&items).Error; err != nil {
		core.InternalServerError(c, "预约列表读取失败")
		return
	}
	core.Success(c, items)
}

func dashboard(c *gin.Context) {
	db := core.GetDB()
	var totalEquipment, availableEquipment, pendingBookings, todayBookings int64
	todayStart := time.Now().Truncate(24 * time.Hour)
	tomorrow := todayStart.Add(24 * time.Hour)
	db.Model(&Equipment{}).Count(&totalEquipment)
	db.Model(&Equipment{}).Where("status = ?", "可预约").Count(&availableEquipment)
	db.Model(&Booking{}).Where("status = ?", "待审核").Count(&pendingBookings)
	db.Model(&Booking{}).Where("start_at >= ? AND start_at < ?", todayStart, tomorrow).Count(&todayBookings)
	core.Success(c, gin.H{
		"total_equipment":     totalEquipment,
		"available_equipment": availableEquipment,
		"pending_bookings":    pendingBookings,
		"today_bookings":      todayBookings,
		"utilization":         68,
	})
}

func checkBooking(c *gin.Context) {
	var input CheckRequest
	if err := c.ShouldBindJSON(&input); err != nil {
		core.BadRequest(c, "请完整填写设备和预约时段")
		return
	}
	result, _, _, err := evaluate(core.GetDB(), input)
	if err != nil {
		core.BadRequest(c, err.Error())
		return
	}
	core.SuccessWithMessage(c, "冲突检测完成", result)
}

func createBooking(c *gin.Context) {
	var input CreateRequest
	if err := c.ShouldBindJSON(&input); err != nil {
		core.BadRequest(c, "请完整填写预约信息")
		return
	}
	result, startAt, endAt, err := evaluate(core.GetDB(), input.CheckRequest)
	if err != nil {
		core.BadRequest(c, err.Error())
		return
	}
	if !result.Available {
		core.Error(c, http.StatusConflict, http.StatusConflict, result.Message)
		return
	}
	booking := Booking{
		EquipmentID: input.EquipmentID,
		Requester:   strings.TrimSpace(input.Requester),
		Purpose:     strings.TrimSpace(input.Purpose),
		StartAt:     startAt,
		EndAt:       endAt,
		Status:      "待审核",
	}
	if booking.Requester == "" || booking.Purpose == "" {
		core.BadRequest(c, "申请人与用途不能为空")
		return
	}
	if err := core.GetDB().Create(&booking).Error; err != nil {
		core.InternalServerError(c, "预约创建失败")
		return
	}
	core.GetDB().Preload("Equipment").First(&booking, booking.ID)
	core.Created(c, "预约申请已提交", booking)
}
