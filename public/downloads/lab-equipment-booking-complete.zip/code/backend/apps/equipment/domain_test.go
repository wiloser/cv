package equipment

import (
	"testing"
	"time"
)

func TestHasOverlap(t *testing.T) {
	base := time.Date(2026, 5, 20, 9, 0, 0, 0, time.Local)
	tests := []struct {
		name     string
		start    time.Time
		end      time.Time
		expected bool
	}{
		{"inside", base.Add(30 * time.Minute), base.Add(90 * time.Minute), true},
		{"contains", base.Add(-time.Hour), base.Add(3 * time.Hour), true},
		{"adjacent before", base.Add(-time.Hour), base, false},
		{"adjacent after", base.Add(2 * time.Hour), base.Add(3 * time.Hour), false},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := HasOverlap(tt.start, tt.end, base, base.Add(2*time.Hour)); got != tt.expected {
				t.Fatalf("HasOverlap() = %v, want %v", got, tt.expected)
			}
		})
	}
}

func TestConflictScore(t *testing.T) {
	if got := conflictScore(0, "高"); got != 0 {
		t.Fatalf("zero overlaps should score 0, got %d", got)
	}
	if got := conflictScore(2, "高"); got != 95 {
		t.Fatalf("two high-risk overlaps should score 95, got %d", got)
	}
	if got := conflictScore(5, "中"); got != 100 {
		t.Fatalf("score should be capped at 100, got %d", got)
	}
}

func TestParseTimeRejectsInvalidValue(t *testing.T) {
	if _, err := parseTime("tomorrow morning"); err == nil {
		t.Fatal("parseTime should reject an invalid value")
	}
}
