import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import App from './App'
import './styles.css'

const bootstrapRoute = () => {
  const basePath = import.meta.env.BASE_URL.replace(/\/$/, '')
  const atProjectRoot = window.location.pathname === basePath || window.location.pathname === `${basePath}/`
  if (!atProjectRoot) return

  const legacySection = window.location.hash.replace(/^#\/?/, '')
  const sections = ['overview', 'equipment', 'bookings', 'analytics']
  const section = sections.includes(legacySection) ? legacySection : 'overview'
  window.history.replaceState(window.history.state, '', `${basePath}/${section}${window.location.search}`)
}

bootstrapRoute()

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter basename={import.meta.env.BASE_URL}>
      <App />
    </BrowserRouter>
  </React.StrictMode>,
)
