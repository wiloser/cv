import { create } from 'zustand'
import { userApi } from '../api/user'
import { getErrorMessage } from '../utils/errorHandler'

export const useUserStore = create((set, get) => ({
  user: JSON.parse(localStorage.getItem('user') || 'null'),
  accessToken: localStorage.getItem('access_token') || null,
  refreshToken: localStorage.getItem('refresh_token') || null,
  isAuthenticated: !!localStorage.getItem('access_token'),

  // 登录
  login: async (loginData) => {
    try {
      const response = await userApi.login(loginData)

      if (response.code === 200 && response.data) {
        const { access, refresh, user } = response.data

        set({
          accessToken: access,
          refreshToken: refresh,
          user,
          isAuthenticated: true,
        })

        localStorage.setItem('access_token', access)
        localStorage.setItem('refresh_token', refresh)
        localStorage.setItem('user', JSON.stringify(user))

        return { success: true, data: response.data }
      } else {
        return { success: false, message: response.msg || '登录失败' }
      }
    } catch (error) {
      return {
        success: false,
        message: getErrorMessage(error, '登录失败，请稍后重试'),
      }
    }
  },

  // 注册
  register: async (registerData) => {
    try {
      const response = await userApi.register(registerData)

      if (response.code === 201 || response.code === 200) {
        return { success: true, data: response.data }
      } else {
        return { success: false, message: response.msg || '注册失败' }
      }
    } catch (error) {
      return {
        success: false,
        message: getErrorMessage(error, '注册失败，请稍后重试'),
      }
    }
  },

  // 登出
  logout: async () => {
    try {
      const { refreshToken } = get()
      if (refreshToken) {
        await userApi.logout({ refresh: refreshToken })
      }
    } catch (error) {
      console.error('登出请求失败:', error)
    } finally {
      get().clearAuth()
    }
  },

  // 清除认证信息
  clearAuth: () => {
    set({
      accessToken: null,
      refreshToken: null,
      user: null,
      isAuthenticated: false,
    })

    localStorage.removeItem('access_token')
    localStorage.removeItem('refresh_token')
    localStorage.removeItem('user')
  },

  // 获取个人信息
  fetchProfile: async () => {
    try {
      const response = await userApi.getProfile()

      if (response.code === 200 && response.data) {
        set({ user: response.data })
        localStorage.setItem('user', JSON.stringify(response.data))
        return { success: true, data: response.data }
      } else {
        return { success: false, message: response.msg || '获取个人信息失败' }
      }
    } catch (error) {
      return {
        success: false,
        message: getErrorMessage(error, '获取个人信息失败'),
      }
    }
  },

  // 更新个人信息
  updateProfile: async (profileData) => {
    try {
      const response = await userApi.updateProfile(profileData)

      if (response.code === 200 && response.data) {
        set({ user: response.data })
        localStorage.setItem('user', JSON.stringify(response.data))
        return { success: true, data: response.data, message: response.msg || '更新成功' }
      } else {
        return { success: false, message: response.msg || '更新失败' }
      }
    } catch (error) {
      return {
        success: false,
        message: getErrorMessage(error, '更新失败，请稍后重试'),
      }
    }
  },

  // 修改密码
  changePassword: async (passwordData) => {
    try {
      const response = await userApi.changePassword(passwordData)

      if (response.code === 200) {
        return { success: true, message: response.msg || '密码修改成功' }
      } else {
        return { success: false, message: response.msg || '密码修改失败' }
      }
    } catch (error) {
      return {
        success: false,
        message: getErrorMessage(error, '密码修改失败，请稍后重试'),
      }
    }
  },

  // 获取用户列表（管理员）
  fetchUserList: async (params = {}) => {
    try {
      const response = await userApi.getUserList(params)

      if (response.code === 200) {
        return { success: true, data: response.data }
      } else {
        return { success: false, message: response.msg || '获取用户列表失败' }
      }
    } catch (error) {
      return {
        success: false,
        message: getErrorMessage(error, '获取用户列表失败'),
      }
    }
  },
}))
