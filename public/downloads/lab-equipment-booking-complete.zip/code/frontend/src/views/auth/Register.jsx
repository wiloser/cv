import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'
import { useUserStore } from '../../stores/userStore'
import { validateEmail, validatePhone, validatePassword } from '../../utils/helpers'
import { getErrorMessage } from '../../utils/errorHandler'

export default function Register() {
  const navigate = useNavigate()
  const register = useUserStore((state) => state.register)

  const [form, setForm] = useState({
    username: '',
    email: '',
    phone: '',
    password: '',
    passwordConfirm: '',
  })
  const [errors, setErrors] = useState({})
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    setErrors({})

    if (!form.username) {
      setErrors({ username: '请输入用户名' })
      return
    }
    if (form.email && !validateEmail(form.email)) {
      setErrors({ email: '邮箱格式不正确' })
      return
    }
    if (form.phone && !validatePhone(form.phone)) {
      setErrors({ phone: '手机号格式不正确' })
      return
    }
    const pwdValidation = validatePassword(form.password)
    if (!pwdValidation.valid) {
      setErrors({ password: pwdValidation.message })
      return
    }
    if (form.password !== form.passwordConfirm) {
      setErrors({ passwordConfirm: '两次输入的密码不一致' })
      return
    }

    setLoading(true)
    try {
      const registerData = {
        username: form.username,
        email: form.email || undefined,
        phone: form.phone || undefined,
        password: form.password,
        password_confirm: form.passwordConfirm,
      }

      const result = await register(registerData)
      if (result.success) {
        toast.success('注册成功！请登录')
        setTimeout(() => navigate('/login'), 800)
      } else {
        toast.error(result.message || '注册失败')
      }
    } catch (error) {
      toast.error(getErrorMessage(error, '注册失败，请稍后重试'))
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900">注册账号</h2>
          <p className="mt-2 text-sm text-gray-600">
            已有账号？
            <Link to="/login" className="text-blue-600 hover:text-blue-800 hover:underline cursor-pointer">
              立即登录
            </Link>
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="username" className="block text-sm font-medium text-gray-700 mb-2">用户名</label>
              <input
                id="username"
                type="text"
                value={form.username}
                onChange={(e) => setForm({ ...form, username: e.target.value })}
                disabled={loading}
                placeholder="请输入用户名"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              />
              {errors.username && <p className="text-red-600 text-sm mt-1">{errors.username}</p>}
            </div>

            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">邮箱（可选）</label>
              <input
                id="email"
                type="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                disabled={loading}
                placeholder="请输入邮箱"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              />
              {errors.email && <p className="text-red-600 text-sm mt-1">{errors.email}</p>}
            </div>

            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-2">手机号（可选）</label>
              <input
                id="phone"
                type="tel"
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
                disabled={loading}
                placeholder="请输入手机号"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              />
              {errors.phone && <p className="text-red-600 text-sm mt-1">{errors.phone}</p>}
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-2">密码</label>
              <input
                id="password"
                type="password"
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
                disabled={loading}
                placeholder="请输入密码（至少8位，包含大小写字母和数字）"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              />
              {errors.password && <p className="text-red-600 text-sm mt-1">{errors.password}</p>}
            </div>

            <div>
              <label htmlFor="passwordConfirm" className="block text-sm font-medium text-gray-700 mb-2">确认密码</label>
              <input
                id="passwordConfirm"
                type="password"
                value={form.passwordConfirm}
                onChange={(e) => setForm({ ...form, passwordConfirm: e.target.value })}
                disabled={loading}
                placeholder="请再次输入密码"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              />
              {errors.passwordConfirm && <p className="text-red-600 text-sm mt-1">{errors.passwordConfirm}</p>}
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? '注册中...' : '注册'}
            </button>
          </form>
        </div>
      </div>
    </div>
  )
}
