import { Link } from 'react-router-dom'
import { useUserStore } from '../stores/userStore'
import Navbar from '../components/Navbar'

export default function Home() {
  const { isAuthenticated } = useUserStore()

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center">
          <h1 className="text-5xl font-bold text-gray-900 mb-4">
            欢迎使用 React 基础项目
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            专业的全栈开发基础框架，支持多种后端服务
          </p>

          <div className="flex justify-center space-x-4 mb-12">
            {!isAuthenticated ? (
              <>
                <Link
                  to="/login"
                  className="bg-blue-600 text-white px-8 py-3 rounded-lg text-lg font-semibold hover:bg-blue-700 transition-colors"
                >
                  立即登录
                </Link>
                <Link
                  to="/register"
                  className="bg-white text-blue-600 px-8 py-3 rounded-lg text-lg font-semibold border-2 border-blue-600 hover:bg-blue-50 transition-colors"
                >
                  免费注册
                </Link>
              </>
            ) : (
              <Link
                to="/profile"
                className="bg-blue-600 text-white px-8 py-3 rounded-lg text-lg font-semibold hover:bg-blue-700 transition-colors"
              >
                查看个人信息
              </Link>
            )}
          </div>
        </div>

        {/* 特性卡片 */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
          <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-xl transition-shadow">
            <div className="text-blue-600 text-4xl mb-4">🔐</div>
            <h3 className="text-xl font-semibold mb-2">JWT 认证</h3>
            <p className="text-gray-600">
              完整的用户认证系统，支持登录、注册、Token刷新等功能
            </p>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-xl transition-shadow">
            <div className="text-green-600 text-4xl mb-4">🎨</div>
            <h3 className="text-xl font-semibold mb-2">Tailwind CSS</h3>
            <p className="text-gray-600">
              使用CDN引入Tailwind CSS，快速构建美观的响应式界面
            </p>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-xl transition-shadow">
            <div className="text-purple-600 text-4xl mb-4">🚀</div>
            <h3 className="text-xl font-semibold mb-2">多后端支持</h3>
            <p className="text-gray-600">
              兼容 Django、Flask、Gin、Spring Boot 四种后端框架
            </p>
          </div>
        </div>

        {/* 技术栈 */}
        <div className="mt-16 bg-white rounded-lg shadow-md p-6">
          <h2 className="text-3xl font-bold text-center mb-8">技术栈</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-3xl mb-2">⚛️</div>
              <div className="font-semibold">React</div>
              <div className="text-sm text-gray-600">Hooks</div>
            </div>
            <div className="text-center">
              <div className="text-3xl mb-2">📦</div>
              <div className="font-semibold">Zustand</div>
              <div className="text-sm text-gray-600">状态管理</div>
            </div>
            <div className="text-center">
              <div className="text-3xl mb-2">🛣️</div>
              <div className="font-semibold">React Router</div>
              <div className="text-sm text-gray-600">路由管理</div>
            </div>
            <div className="text-center">
              <div className="text-3xl mb-2">🌐</div>
              <div className="font-semibold">Axios</div>
              <div className="text-sm text-gray-600">HTTP客户端</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
