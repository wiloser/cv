import axios from 'axios'

const getLoginUrl = () => {
  const basePath = import.meta.env.BASE_URL.replace(/\/$/, '')
  const currentPath = window.location.pathname.startsWith(basePath)
    ? window.location.pathname.slice(basePath.length) || '/'
    : '/'
  const redirect = `${currentPath}${window.location.search}${window.location.hash}`
  return `${basePath}/login?redirect=${encodeURIComponent(redirect)}`
}

const clearAuthAndRedirect = () => {
  localStorage.removeItem('access_token')
  localStorage.removeItem('refresh_token')
  localStorage.removeItem('user')
  window.location.assign(getLoginUrl())
}

// 创建axios实例
const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || '',  // 开发环境走Vite代理
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
})

// 请求拦截器
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('access_token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

let refreshRequest = null

// 响应拦截器
api.interceptors.response.use(
  (response) => response.data,
  async (error) => {
    const originalRequest = error.config

    // 公开接口（登录、注册等）的 401 不走 token 刷新逻辑，直接返回错误给业务层处理
    const publicPaths = ['/api/users/login/', '/api/users/register/', '/api/users/token/refresh/']
    const isPublicRequest = publicPaths.some(path => originalRequest?.url?.includes(path))

    // 如果是401错误且不是公开接口且不是重试请求
    if (error.response?.status === 401 && originalRequest && !isPublicRequest && !originalRequest._retry) {
      originalRequest._retry = true

      try {
        const refreshToken = localStorage.getItem('refresh_token')
        if (!refreshToken) {
          clearAuthAndRedirect()
          return Promise.reject(error)
        }

        // 多个请求同时过期时只发起一次刷新请求
        refreshRequest ??= axios.post(
          `${api.defaults.baseURL}/api/users/token/refresh/`,
          { refresh: refreshToken },
        ).finally(() => {
          refreshRequest = null
        })
        const response = await refreshRequest
        const accessToken = response.data?.data?.access

        if (accessToken) {
          localStorage.setItem('access_token', accessToken)
          originalRequest.headers.Authorization = `Bearer ${accessToken}`
          return api(originalRequest)
        }
        throw new Error('刷新接口未返回 access token')
      } catch (refreshError) {
        clearAuthAndRedirect()
        return Promise.reject(refreshError)
      }
    }

    return Promise.reject(error)
  }
)

export default api
