import api from './index'

// 用户相关API
export const userApi = {
  // 用户注册
  register: (data) => api.post('/api/users/register/', data),

  // 用户登录
  login: (data) => api.post('/api/users/login/', data),

  // 用户登出
  logout: (data) => api.post('/api/users/logout/', data),

  // 获取个人信息
  getProfile: () => api.get('/api/users/profile/'),

  // 更新个人信息
  updateProfile: (data) => api.put('/api/users/profile/', data),

  // 修改密码
  changePassword: (data) => api.post('/api/users/password/change/', data),

  // 获取用户列表（管理员）
  getUserList: (params) => api.get('/api/users/list/', { params }),
}

export default userApi
