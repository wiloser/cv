import { useEffect, useMemo, useState } from 'react'
import { Link, useLocation } from 'react-router-dom'

const API = import.meta.env.VITE_API_BASE_URL || ''

const request = async (path, options) => {
  const response = await fetch(`${API}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  })
  if (!response.headers.get('content-type')?.includes('application/json')) {
    throw new Error(`API 代理返回了非 JSON 响应（HTTP ${response.status}），请检查 ${API || '当前站点'}/api/ 代理`)
  }
  const payload = await response.json()
  if (!response.ok) throw new Error(payload.msg || '服务暂时不可用')
  return payload.data
}

const toLocalInput = (date) => {
  const local = new Date(date.getTime() - date.getTimezoneOffset() * 60000)
  return local.toISOString().slice(0, 16)
}

const formatTime = (value) => new Intl.DateTimeFormat('zh-CN', {
  month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false,
}).format(new Date(value))

const statusClass = (status) => ({ 可预约: 'success', 已通过: 'success', 待审核: 'warning', 维护中: 'muted' }[status] || 'muted')

function App() {
  const location = useLocation()
  const now = useMemo(() => new Date(), [])
  const [equipment, setEquipment] = useState([])
  const [bookings, setBookings] = useState([])
  const [dashboard, setDashboard] = useState({})
  const [selectedId, setSelectedId] = useState('')
  const [startAt, setStartAt] = useState(toLocalInput(new Date(now.getTime() + 2 * 3600000)))
  const [endAt, setEndAt] = useState(toLocalInput(new Date(now.getTime() + 4 * 3600000)))
  const [result, setResult] = useState(null)
  const [notice, setNotice] = useState('')
  const [loading, setLoading] = useState(true)

  const load = async () => {
    setLoading(true)
    try {
      const [equipmentData, bookingData, dashboardData] = await Promise.all([
        request('/api/equipment/'), request('/api/bookings/'), request('/api/dashboard/'),
      ])
      setEquipment(equipmentData)
      setBookings(bookingData)
      setDashboard(dashboardData)
      setSelectedId((current) => current || String(equipmentData.find((item) => item.status === '可预约')?.id || ''))
      setNotice('')
    } catch (error) {
      setNotice(`${error.message}，请检查 API 代理与 Go 服务状态`)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    const timer = window.setTimeout(load, 0)
    return () => window.clearTimeout(timer)
  }, [])

  useEffect(() => {
    const section = location.pathname.split('/').filter(Boolean).at(-1) || 'overview'
    const timer = window.requestAnimationFrame(() => {
      document.getElementById(section)?.scrollIntoView({ behavior: 'smooth', block: 'start' })
    })
    return () => window.cancelAnimationFrame(timer)
  }, [location.pathname])

  const check = async () => {
    setResult(null)
    try {
      const data = await request('/api/bookings/check/', {
        method: 'POST',
        body: JSON.stringify({ equipment_id: Number(selectedId), start_at: startAt, end_at: endAt }),
      })
      setResult(data)
    } catch (error) {
      setResult({ available: false, message: error.message, conflict_score: 0, suggestions: [] })
    }
  }

  const createBooking = async () => {
    try {
      await request('/api/bookings/', {
        method: 'POST',
        body: JSON.stringify({
          equipment_id: Number(selectedId), start_at: startAt, end_at: endAt,
          requester: '演示用户', purpose: '毕业设计实验数据采集',
        }),
      })
      setResult(null)
      setNotice('预约申请已进入审核队列')
      await load()
    } catch (error) {
      setNotice(error.message)
    }
  }

  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="brand"><span className="brand-mark">E</span><div><b>EquipFlow</b><small>实验室资源中心</small></div></div>
        <nav>
          <Link className={location.pathname.endsWith('/overview') || location.pathname === '/' ? 'active' : ''} to="/overview"><span>⌂</span> 总览</Link>
          <Link className={location.pathname.endsWith('/equipment') ? 'active' : ''} to="/equipment"><span>▦</span> 设备资源</Link>
          <Link className={location.pathname.endsWith('/bookings') ? 'active' : ''} to="/bookings"><span>◷</span> 预约记录</Link>
          <Link className={location.pathname.endsWith('/analytics') ? 'active' : ''} to="/analytics"><span>⌁</span> 使用分析</Link>
        </nav>
        <div className="side-card"><span>68%</span><p>本周设备利用率</p><div><i /></div><small>较上周提升 12%</small></div>
        <div className="profile"><span>研</span><div><b>李若宁</b><small>材料工程 · 研究生</small></div><button>•••</button></div>
      </aside>

      <main id="overview">
        <header><div><p className="eyebrow">RESOURCE OVERVIEW</p><h1>实验室设备预约</h1><p>统一查看设备状态，智能检测时段冲突。</p></div><div className="header-actions"><span className="live"><i /> 系统运行正常</span><button className="icon-button">⌕</button><button className="primary" onClick={() => document.querySelector('#booking-panel')?.scrollIntoView({ behavior: 'smooth' })}>＋ 发起预约</button></div></header>

        {notice && <div className="notice">{notice}<button onClick={() => setNotice('')}>×</button></div>}

        <section className="stats" id="analytics">
          <article><span className="stat-icon blue">▦</span><div><small>设备总数</small><strong>{dashboard.total_equipment ?? '—'}</strong><em>台登记设备</em></div></article>
          <article><span className="stat-icon green">✓</span><div><small>当前可预约</small><strong>{dashboard.available_equipment ?? '—'}</strong><em>资源状态正常</em></div></article>
          <article><span className="stat-icon amber">◷</span><div><small>待审核申请</small><strong>{dashboard.pending_bookings ?? '—'}</strong><em>请及时处理</em></div></article>
          <article><span className="stat-icon violet">↗</span><div><small>今日预约</small><strong>{dashboard.today_bookings ?? '—'}</strong><em>个实验时段</em></div></article>
        </section>

        <div className="content-grid">
          <section className="panel equipment-panel" id="equipment">
            <div className="panel-head"><div><h2>设备资源</h2><p>点击卡片选择预约设备</p></div><button>全部设备 <span>→</span></button></div>
            <div className="equipment-grid">
              {loading ? <div className="empty">正在同步设备状态…</div> : equipment.map((item) => (
                <button key={item.id} className={`equipment-card ${String(item.id) === selectedId ? 'selected' : ''}`} onClick={() => { setSelectedId(String(item.id)); setResult(null) }} disabled={item.status !== '可预约'}>
                  <div className={`device-visual visual-${item.category.length % 3}`}><span>{item.code.split('-')[0]}</span><i className={`badge ${statusClass(item.status)}`}>{item.status}</i></div>
                  <div className="device-copy"><small>{item.category}</small><h3>{item.name}</h3><p>⌖ {item.lab}</p><footer><span>{item.code}</span><b>{item.risk_level}风险</b></footer></div>
                </button>
              ))}
            </div>
          </section>

          <aside className="panel booking-panel" id="booking-panel">
            <div className="panel-head"><div><h2>冲突检测</h2><p>选择时段后实时计算</p></div><span className="spark">✦</span></div>
            <label>预约设备<select value={selectedId} onChange={(event) => { setSelectedId(event.target.value); setResult(null) }}><option value="">请选择设备</option>{equipment.filter((item) => item.status === '可预约').map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label>
            <div className="date-row"><label>开始时间<input type="datetime-local" value={startAt} onChange={(event) => setStartAt(event.target.value)} /></label><label>结束时间<input type="datetime-local" value={endAt} onChange={(event) => setEndAt(event.target.value)} /></label></div>
            <button className="check-button" onClick={check} disabled={!selectedId}>✦ 智能检测可用性</button>
            {result ? <div className={`result ${result.available ? 'available' : 'conflict'}`}><div><strong>{result.available ? '时段可预约' : '检测到预约冲突'}</strong><span>{result.conflict_score || 0} 风险分</span></div><p>{result.message}</p>{result.suggestions?.length > 0 && <small>可替代：{result.suggestions.map((item) => item.name).join('、')}</small>}{result.available && <button onClick={createBooking}>提交预约申请</button>}</div> : <div className="hint"><span>i</span><p>系统会对在库预约执行区间重叠检测，并在冲突时推荐同类可用设备。</p></div>}
          </aside>
        </div>

        <section className="panel schedule" id="bookings">
          <div className="panel-head"><div><h2>近期预约安排</h2><p>按实验开始时间排序</p></div><div className="legend"><span><i className="dot green-dot" />已通过</span><span><i className="dot amber-dot" />待审核</span></div></div>
          <div className="table-wrap"><table><thead><tr><th>设备</th><th>申请人 / 用途</th><th>使用时段</th><th>实验室</th><th>状态</th></tr></thead><tbody>{bookings.slice(0, 5).map((item) => <tr key={item.id}><td><b>{item.equipment.name}</b><small>{item.equipment.code}</small></td><td><b>{item.requester}</b><small>{item.purpose}</small></td><td><b>{formatTime(item.start_at)}</b><small>至 {formatTime(item.end_at)}</small></td><td>{item.equipment.lab}</td><td><span className={`pill ${statusClass(item.status)}`}>{item.status}</span></td></tr>)}</tbody></table></div>
        </section>
      </main>
    </div>
  )
}

export default App
