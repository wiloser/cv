# React 前端基础项目

可与仓库中的 Django、Flask、Gin、Spring Boot 后端任意组合，统一接口见根目录
`API_CONTRACT.md`。

```bash
npm ci
npm run dev
```

开发地址为 `http://localhost:5174`。Vite 默认把 `/api` 代理到
`http://127.0.0.1:8181`；部署时也可设置 `VITE_API_BASE_URL` 指向后端地址。
代理目标可通过 `VITE_PROXY_TARGET` 覆盖。

```bash
npm run lint
npm run build
```
